
const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const path = require('path');
const { exec } = require('child_process');
const unzipper = require('unzipper');

const PROJECTS_DIR = './projects';

// تشغيل مشروع
router.post('/run', async (req, res) => {
    try {
        const { filename } = req.body;
        const userDir = path.join('./uploads', req.ip.replace(/[:.]/g, '_'));
        const filePath = path.join(userDir, filename);
        
        if (!fs.existsSync(filePath)) {
            return res.status(404).json({ error: 'ملف غير موجود' });
        }
        
        const ext = path.extname(filename).toLowerCase();
        const projectName = path.basename(filename, ext);
        const projectDir = path.join(PROJECTS_DIR, projectName);
        
        // إنشاء مجلد المشروع
        fs.ensureDirSync(projectDir);
        
        if (ext === '.zip') {
            // فك ضغط المشروع
            await new Promise((resolve, reject) => {
                fs.createReadStream(filePath)
                    .pipe(unzipper.Extract({ path: projectDir }))
                    .on('finish', resolve)
                    .on('error', reject);
            });
        } else {
            // نسخ الملف مباشرة
            fs.copySync(filePath, path.join(projectDir, filename));
        }
        
        // تشغيل المشروع
        const runUrl = `/projects/${projectName}/index.html`;
        res.json({ success: true, url: runUrl });
        
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
