
const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const path = require('path');
const sharp = require('sharp');
const mime = require('mime-types');

module.exports = (upload) => {
    // رفع ملفات
    router.post('/', upload.array('files'), async (req, res) => {
        try {
            const files = req.files.map(f => ({
                name: f.originalname,
                size: f.size,
                path: f.path,
                url: `/uploads/${f.filename}`,
                uploadedAt: new Date(),
                type: mime.lookup(f.originalname) || 'application/octet-stream'
            }));
            
            res.json({ success: true, files });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    });
    
    // رفع مع WebSocket
    router.post('/stream', upload.single('file'), (req, res) => {
        try {
            const file = req.file;
            res.json({
                success: true,
                file: {
                    name: file.originalname,
                    size: file.size,
                    path: file.path,
                    url: `/uploads/${file.filename}`
                }
            });
        } catch (error) {
            res.status(500).json({ error: error.message });
        }
    });
    
    return router;
};
