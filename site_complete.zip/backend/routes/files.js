
const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const path = require('path');
const archiver = require('archiver');
const unzipper = require('unzipper');

const UPLOAD_DIR = './uploads';

// قائمة الملفات
router.get('/', async (req, res) => {
    try {
        const userDir = path.join(UPLOAD_DIR, req.ip.replace(/[:.]/g, '_'));
        if (!fs.existsSync(userDir)) {
            return res.json([]);
        }
        
        const files = fs.readdirSync(userDir).map(f => {
            const stats = fs.statSync(path.join(userDir, f));
            return {
                name: f,
                size: stats.size,
                modified: stats.mtime,
                isDirectory: stats.isDirectory(),
                type: path.extname(f).substring(1) || 'folder'
            };
        });
        
        res.json(files);
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// حذف ملف
router.delete('/:filename', async (req, res) => {
    try {
        const filePath = path.join(UPLOAD_DIR, req.ip.replace(/[:.]/g, '_'), req.params.filename);
        if (fs.existsSync(filePath)) {
            fs.removeSync(filePath);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'ملف غير موجود' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// إعادة تسمية
router.put('/:filename', async (req, res) => {
    try {
        const { newName } = req.body;
        const oldPath = path.join(UPLOAD_DIR, req.ip.replace(/[:.]/g, '_'), req.params.filename);
        const newPath = path.join(UPLOAD_DIR, req.ip.replace(/[:.]/g, '_'), newName);
        
        if (fs.existsSync(oldPath)) {
            fs.renameSync(oldPath, newPath);
            res.json({ success: true });
        } else {
            res.status(404).json({ error: 'ملف غير موجود' });
        }
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// ضغط ملفات
router.post('/zip', async (req, res) => {
    try {
        const { files } = req.body;
        const userDir = path.join(UPLOAD_DIR, req.ip.replace(/[:.]/g, '_'));
        const zipPath = path.join(userDir, 'archive.zip');
        
        const output = fs.createWriteStream(zipPath);
        const archive = archiver('zip', { zlib: { level: 9 } });
        
        archive.pipe(output);
        
        files.forEach(file => {
            const filePath = path.join(userDir, file);
            if (fs.existsSync(filePath)) {
                archive.file(filePath, { name: file });
            }
        });
        
        await archive.finalize();
        res.json({ success: true, path: zipPath });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
