
const express = require('express');
const router = express.Router();
const fs = require('fs-extra');
const os = require('os');
const path = require('path');

// إحصائيات النظام
router.get('/stats', async (req, res) => {
    try {
        const cpus = os.cpus();
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        
        // عدد الملفات
        const uploadsDir = './uploads';
        let totalFiles = 0;
        let totalSize = 0;
        
        if (fs.existsSync(uploadsDir)) {
            const walk = (dir) => {
                const items = fs.readdirSync(dir);
                items.forEach(item => {
                    const itemPath = path.join(dir, item);
                    const stats = fs.statSync(itemPath);
                    if (stats.isDirectory()) {
                        walk(itemPath);
                    } else {
                        totalFiles++;
                        totalSize += stats.size;
                    }
                });
            };
            walk(uploadsDir);
        }
        
        res.json({
            cpu: cpus.length,
            cpuModel: cpus[0]?.model || 'Unknown',
            totalMemory: (totalMem / 1024 / 1024 / 1024).toFixed(2) + ' GB',
            freeMemory: (freeMem / 1024 / 1024 / 1024).toFixed(2) + ' GB',
            totalFiles,
            totalSize: (totalSize / 1024 / 1024 / 1024).toFixed(2) + ' GB',
            uptime: os.uptime(),
            status: 'online'
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

// تنظيف الملفات المؤقتة
router.delete('/cleanup', async (req, res) => {
    try {
        const tempDir = './temp';
        if (fs.existsSync(tempDir)) {
            fs.emptyDirSync(tempDir);
        }
        res.json({ success: true, message: 'تم تنظيف الملفات المؤقتة' });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
});

module.exports = router;
