
const rateLimit = new Map();

module.exports = (req, res, next) => {
    const ip = req.ip;
    const now = Date.now();
    const limit = 100; // طلب في الدقيقة
    
    if (!rateLimit.has(ip)) {
        rateLimit.set(ip, [now]);
        return next();
    }
    
    const requests = rateLimit.get(ip);
    const recent = requests.filter(time => now - time < 60000);
    
    if (recent.length >= limit) {
        return res.status(429).json({ error: 'عدد الطلبات تجاوز الحد المسموح' });
    }
    
    recent.push(now);
    rateLimit.set(ip, recent);
    next();
};
