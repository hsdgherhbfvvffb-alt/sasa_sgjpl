
module.exports = (req, res, next) => {
    // بدون مصادقة - نظام مفتوح
    next();
};
