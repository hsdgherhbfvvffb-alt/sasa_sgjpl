
const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs-extra');
const socketio = require('socket.io');
const compression = require('compression');
const helmet = require('helmet');
const cors = require('cors');
const archiver = require('archiver');
const unzipper = require('unzipper');
const crypto = require('crypto');
const os = require('os');

const app = express();
const server = require('http').createServer(app);
const io = socketio(server, { cors: { origin: '*' } });

// الأمان
app.use(helmet());
app.use(compression());
app.use(cors());
app.use(express.json({ limit: '50gb' }));
app.use(express.urlencoded({ extended: true, limit: '50gb' }));

// المجلدات
const UPLOAD_DIR = './uploads';
const PROJECTS_DIR = './projects';
const TEMP_DIR = './temp';
const LOGS_DIR = './logs';

[UPLOAD_DIR, PROJECTS_DIR, TEMP_DIR, LOGS_DIR].forEach(dir => {
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
});

// إعداد multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const userDir = path.join(UPLOAD_DIR, req.ip.replace(/[:.]/g, '_'));
        if (!fs.existsSync(userDir)) fs.mkdirSync(userDir, { recursive: true });
        cb(null, userDir);
    },
    filename: (req, file, cb) => {
        const unique = crypto.randomBytes(16).toString('hex');
        cb(null, `${Date.now()}-${unique}-${file.originalname}`);
    }
});

const upload = multer({
    storage,
    limits: { fileSize: 50 * 1024 * 1024 * 1024 }
});

// ===== ROUTES =====
const uploadRoutes = require('./routes/upload')(upload);
const fileRoutes = require('./routes/files');
const projectRoutes = require('./routes/projects');
const adminRoutes = require('./routes/admin');

app.use('/api/upload', uploadRoutes);
app.use('/api/files', fileRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/admin', adminRoutes);

// ملفات ثابتة
app.use('/uploads', express.static(UPLOAD_DIR));
app.use('/projects', express.static(PROJECTS_DIR));

// WebSocket
io.on('connection', (socket) => {
    console.log('🟢 مستخدم متصل');
    
    socket.on('upload-progress', (data) => {
        io.emit('progress', data);
    });
    
    socket.on('disconnect', () => {
        console.log('🔴 مستخدم انقطع');
    });
});

// تشغيل الخادم
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
    console.log(`🚀 الخادم يعمل على http://localhost:${PORT}`);
});
