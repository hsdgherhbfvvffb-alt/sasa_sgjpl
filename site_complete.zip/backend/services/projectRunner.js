
const { exec } = require('child_process');
const fs = require('fs-extra');
const path = require('path');

class ProjectRunner {
    constructor(projectsDir) {
        this.projectsDir = projectsDir;
    }
    
    async runProject(projectPath) {
        // تشغيل مشروع ويب
        const indexPath = path.join(projectPath, 'index.html');
        if (fs.existsSync(indexPath)) {
            return { success: true, url: `/projects/${path.basename(projectPath)}/index.html` };
        }
        return { success: false, error: 'لا يوجد index.html' };
    }
}

module.exports = ProjectRunner;
