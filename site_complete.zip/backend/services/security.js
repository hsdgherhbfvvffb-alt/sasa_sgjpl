
const crypto = require('crypto');
const fs = require('fs-extra');
const path = require('path');

class Security {
    static generateHash(data) {
        return crypto.createHash('sha256').update(data).digest('hex');
    }
    
    static scanFile(filePath) {
        // فحص الملفات الضارة (مثال بسيط)
        const dangerousExtensions = ['.exe', '.bat', '.cmd', '.vbs', '.ps1'];
        const ext = path.extname(filePath).toLowerCase();
        return !dangerousExtensions.includes(ext);
    }
    
    static generateSecureId() {
        return crypto.randomBytes(16).toString('hex');
    }
}

module.exports = Security;
