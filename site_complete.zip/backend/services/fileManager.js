
const fs = require('fs-extra');
const path = require('path');

class FileManager {
    constructor(baseDir) {
        this.baseDir = baseDir;
    }
    
    getUserDir(ip) {
        return path.join(this.baseDir, ip.replace(/[:.]/g, '_'));
    }
    
    async listFiles(ip) {
        const dir = this.getUserDir(ip);
        if (!fs.existsSync(dir)) return [];
        
        const items = fs.readdirSync(dir);
        return items.map(item => {
            const stats = fs.statSync(path.join(dir, item));
            return {
                name: item,
                size: stats.size,
                modified: stats.mtime,
                isDirectory: stats.isDirectory()
            };
        });
    }
    
    async deleteFile(ip, filename) {
        const filePath = path.join(this.getUserDir(ip), filename);
        if (fs.existsSync(filePath)) {
            fs.removeSync(filePath);
            return true;
        }
        return false;
    }
    
    async renameFile(ip, oldName, newName) {
        const oldPath = path.join(this.getUserDir(ip), oldName);
        const newPath = path.join(this.getUserDir(ip), newName);
        if (fs.existsSync(oldPath)) {
            fs.renameSync(oldPath, newPath);
            return true;
        }
        return false;
    }
}

module.exports = FileManager;
