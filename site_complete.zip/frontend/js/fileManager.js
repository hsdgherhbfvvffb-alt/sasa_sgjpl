
async function loadFiles() {
    try {
        const response = await fetch('/api/files');
        const files = await response.json();
        renderFiles(files);
    } catch (error) {
        console.error('خطأ في تحميل الملفات:', error);
    }
}

function renderFiles(files) {
    const container = document.getElementById('filesList');
    if (!files || files.length === 0) {
        container.innerHTML = '<p style="text-align:center;opacity:0.5;">لا توجد ملفات</p>';
        return;
    }
    
    container.innerHTML = files.map(file => `
        <div class="file-item">
            <div class="file-name">${file.name}</div>
            <div class="file-size">${formatSize(file.size)}</div>
            <div class="file-actions">
                <button onclick="downloadFile('${file.name}')">📥</button>
                <button onclick="deleteFile('${file.name}')">🗑️</button>
                <button onclick="renameFile('${file.name}')">✏️</button>
            </div>
        </div>
    `).join('');
}

function formatSize(bytes) {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
    return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
}

async function deleteFile(filename) {
    if (!confirm(`حذف ${filename}؟`)) return;
    try {
        await fetch(`/api/files/${filename}`, { method: 'DELETE' });
        loadFiles();
    } catch (error) {
        console.error('خطأ في الحذف:', error);
    }
}

function downloadFile(filename) {
    window.open(`/uploads/${filename}`, '_blank');
}

async function renameFile(filename) {
    const newName = prompt('الاسم الجديد:', filename);
    if (!newName || newName === filename) return;
    try {
        await fetch(`/api/files/${filename}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ newName })
        });
        loadFiles();
    } catch (error) {
        console.error('خطأ في إعادة التسمية:', error);
    }
}

function searchFiles() {
    const query = document.getElementById('searchInput').value.toLowerCase();
    document.querySelectorAll('.file-item').forEach(item => {
        const name = item.querySelector('.file-name').textContent.toLowerCase();
        item.style.display = name.includes(query) ? 'flex' : 'none';
    });
}
