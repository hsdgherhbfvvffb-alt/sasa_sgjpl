
async function loadStats() {
    try {
        const response = await fetch('/api/admin/stats');
        const stats = await response.json();
        
        document.getElementById('stats').innerHTML = `
            <div class="stat-card">
                <div class="stat-value">${stats.totalFiles}</div>
                <div>📄 الملفات</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${stats.totalSize}</div>
                <div>💾 المساحة المستخدمة</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${stats.freeMemory}</div>
                <div>🧠 الرام المتاحة</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${stats.cpu}</div>
                <div>⚡ نوى المعالج</div>
            </div>
            <div class="stat-card">
                <div class="stat-value">${stats.status}</div>
                <div>🟢 حالة الخادم</div>
            </div>
        `;
    } catch (error) {
        console.error('خطأ في تحميل الإحصائيات:', error);
    }
}
