
let currentTheme = 'dark';

function showUpload() {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById('upload-section').classList.add('active');
}

function showFiles() {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById('files-section').classList.add('active');
    loadFiles();
}

function showAdmin() {
    document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
    document.getElementById('admin-section').classList.add('active');
    loadStats();
}

function toggleTheme() {
    currentTheme = currentTheme === 'dark' ? 'light' : 'dark';
    document.body.classList.toggle('light');
    document.querySelector('.nav-links button:last-child').textContent = currentTheme === 'dark' ? '🌙' : '☀️';
}

// WebSocket
const socket = io('http://localhost:3000');

socket.on('progress', (data) => {
    document.getElementById('uploadProgress').innerHTML = `
        <div class="progress-bar">
            <div class="progress-fill" style="width: ${data.percent}%"></div>
        </div>
        <p>${data.percent}% - ${data.filename}</p>
    `;
});
