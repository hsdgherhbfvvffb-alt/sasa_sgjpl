import { useEffect, useRef, useState } from "react";
import {
  Box,
  Camera,
  Circle,
  CircleHelp,
  Cone,
  Copy,
  Cylinder,
  Download,
  Eye,
  EyeOff,
  Flashlight,
  FolderOpen,
  Grid3x3,
  Lightbulb,
  MousePointer2,
  Move3d,
  Pause,
  PersonStanding,
  Play,
  Plus,
  Redo2,
  Rotate3d,
  Save,
  Scaling,
  Square,
  Sun,
  Trash2,
  Undo2,
  Upload,
  Torus,
  Group,
} from "lucide-react";
import { cn } from "@/lib/cn";
import { activeScene } from "@/engine/defaults";
import { parseScript, PRESET_BOB, PRESET_PATROL, PRESET_PLAYER, PRESET_SPIN } from "@/engine/script";
import { useEditor } from "@/engine/store";
import type { LightKind, Prim, SceneNode, Tool } from "@/engine/types";

function trimNum(n: number) {
  if (!Number.isFinite(n)) return "0";
  return String(Math.round(n * 100) / 100);
}

function Num({ value, onChange, label }: { value: number; onChange: (n: number) => void; label: string }) {
  const [text, setText] = useState(() => trimNum(value));
  const [focus, setFocus] = useState(false);
  useEffect(() => {
    if (!focus) setText(trimNum(value));
  }, [value, focus]);
  return (
    <label className="flex min-w-0 flex-col gap-1">
      <span className="text-xs text-muted">{label}</span>
      <input
        className="kiln-field"
        dir="ltr"
        inputMode="decimal"
        value={text}
        onFocus={() => {
          setFocus(true);
          useEditor.getState().beginGesture();
        }}
        onBlur={() => {
          setFocus(false);
          useEditor.getState().endGesture();
          const n = Number(text);
          if (Number.isFinite(n)) onChange(n);
        }}
        onChange={(e) => {
          setText(e.target.value);
          const n = Number(e.target.value);
          if (e.target.value.trim() !== "" && Number.isFinite(n)) onChange(n);
        }}
      />
    </label>
  );
}

function Row3({
  value,
  onChange,
  labels,
}: {
  value: [number, number, number];
  onChange: (next: [number, number, number]) => void;
  labels: [string, string, string];
}) {
  return (
    <div className="grid grid-cols-3 gap-2" dir="ltr">
      {labels.map((label, i) => (
        <Num
          key={label}
          label={label}
          value={value[i]!}
          onChange={(n) => {
            const next: [number, number, number] = [value[0], value[1], value[2]];
            next[i] = n;
            onChange(next);
          }}
        />
      ))}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="flex flex-col gap-2 border-b border-border px-3 py-3">
      <h3 className="text-xs font-medium tracking-wide text-muted">{title}</h3>
      {children}
    </section>
  );
}

const TOOLS: { id: Tool; label: string; icon: typeof MousePointer2; key: string }[] = [
  { id: "select", label: "تحديد", icon: MousePointer2, key: "Q" },
  { id: "translate", label: "تحريك", icon: Move3d, key: "W" },
  { id: "rotate", label: "تدوير", icon: Rotate3d, key: "E" },
  { id: "scale", label: "تحجيم", icon: Scaling, key: "R" },
];

export function AddMenu({ compact = false }: { compact?: boolean }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const close = (e: PointerEvent) => {
      if (!ref.current?.contains(e.target as Node)) setOpen(false);
    };
    window.addEventListener("pointerdown", close);
    return () => window.removeEventListener("pointerdown", close);
  }, [open]);
  const add = useEditor((s) => s.addNode);
  const items: { label: string; icon: typeof Box; run: () => void }[] = [
    { label: "مكعب", icon: Box, run: () => add({ kind: "mesh", primitive: "box", name: "مكعب" }) },
    { label: "كرة", icon: Circle, run: () => add({ kind: "mesh", primitive: "sphere", name: "كرة" }) },
    { label: "أسطوانة", icon: Cylinder, run: () => add({ kind: "mesh", primitive: "cylinder", name: "أسطوانة" }) },
    { label: "مخروط", icon: Cone, run: () => add({ kind: "mesh", primitive: "cone", name: "مخروط" }) },
    { label: "حلقة", icon: Torus, run: () => add({ kind: "mesh", primitive: "torus", name: "حلقة" }) },
    { label: "أرضية", icon: Grid3x3, run: () => add({ kind: "mesh", primitive: "plane", name: "أرضية" }) },
    { label: "شخصية", icon: PersonStanding, run: () => add({ kind: "character" }) },
    { label: "كاميرا", icon: Camera, run: () => add({ kind: "camera" }) },
    { label: "مجموعة", icon: Group, run: () => add({ kind: "group" }) },
    { label: "شمس", icon: Sun, run: () => add({ kind: "light", light: "directional", name: "شمس" }) },
    { label: "ضوء نقطي", icon: Lightbulb, run: () => add({ kind: "light", light: "point", name: "ضوء نقطي" }) },
    { label: "كشاف", icon: Flashlight, run: () => add({ kind: "light", light: "spot", name: "كشاف" }) },
  ];
  return (
    <div className="relative" ref={ref}>
      <button type="button" className="kiln-icon-btn" aria-label="إضافة عنصر" onClick={() => setOpen((v) => !v)}>
        <Plus className="size-4" />
        {compact ? null : <span>إضافة</span>}
      </button>
      {open ? (
        <div className="absolute start-0 top-12 z-40 grid w-56 grid-cols-2 gap-1 rounded-lg border border-border bg-surface p-2 shadow-lg">
          {items.map((item) => (
            <button
              key={item.label}
              type="button"
              className="flex h-11 items-center gap-2 rounded-md px-2 text-xs hover:bg-elevated"
              onClick={() => {
                item.run();
                setOpen(false);
              }}
            >
              <item.icon className="size-4 text-primary" />
              {item.label}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

export function Toolbar() {
  const project = useEditor((s) => s.project);
  const mode = useEditor((s) => s.mode);
  const play = useEditor((s) => s.play);
  const pause = useEditor((s) => s.pause);
  const stop = useEditor((s) => s.stop);
  const undo = useEditor((s) => s.undo);
  const redo = useEditor((s) => s.redo);
  const setScene = useEditor((s) => s.setScene);
  const addScene = useEditor((s) => s.addScene);
  const openHub = useEditor((s) => s.openHub);
  const setHelp = useEditor((s) => s.setHelp);
  const fileRef = useRef<HTMLInputElement>(null);
  const assetRef = useRef<HTMLInputElement>(null);
  if (!project) return null;
  const scene = activeScene(project);
  return (
    <header className="flex h-14 shrink-0 items-center gap-1 overflow-x-auto border-b border-border bg-surface px-2">
      <button type="button" className="kiln-icon-btn shrink-0" onClick={openHub} aria-label="المشاريع">
        <span className="grid size-6 place-items-center rounded bg-primary text-primary-fg">
          <Box className="size-3.5" />
        </span>
        <span className="font-semibold">Kiln</span>
      </button>
      <input
        className="kiln-field h-11 w-36 shrink-0"
        aria-label="اسم المشروع"
        value={project.name}
        onFocus={() => useEditor.getState().beginGesture()}
        onBlur={() => useEditor.getState().endGesture()}
        onChange={(e) => useEditor.getState().renameProject(e.target.value)}
      />
      <select
        className="kiln-field h-11 w-36 shrink-0"
        aria-label="المشهد"
        value={scene.id}
        onChange={(e) => setScene(e.target.value)}
      >
        {project.scenes.map((s) => (
          <option key={s.id} value={s.id}>
            {s.name}
          </option>
        ))}
      </select>
      <button type="button" className="kiln-icon-btn shrink-0" aria-label="مشهد جديد" onClick={addScene}>
        <Plus className="size-4" />
      </button>
      <div className="mx-1 hidden h-6 w-px bg-border sm:block" />
      <button
        type="button"
        className="kiln-icon-btn shrink-0"
        data-active={mode === "play" ? "true" : "false"}
        onClick={play}
        aria-label="تشغيل"
      >
        <Play className="size-4" />
        <span className="hidden sm:inline">تشغيل</span>
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" onClick={pause} aria-label="إيقاف مؤقت" disabled={mode !== "play"}>
        <Pause className="size-4" />
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" onClick={stop} aria-label="إيقاف" disabled={mode === "edit"}>
        <Square className="size-4" />
        <span className="hidden sm:inline">إيقاف</span>
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" onClick={undo} aria-label="تراجع">
        <Undo2 className="size-4" />
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" onClick={redo} aria-label="إعادة">
        <Redo2 className="size-4" />
      </button>
      <AddMenu />
      <button type="button" className="kiln-icon-btn shrink-0" aria-label="حفظ" onClick={() => void useEditor.getState().saveNow()}>
        <Save className="size-4" />
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" aria-label="تصدير" onClick={() => void useEditor.getState().exportProjectFile()}>
        <Download className="size-4" />
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" aria-label="استيراد مجسم" onClick={() => assetRef.current?.click()}>
        <Upload className="size-4" />
      </button>
      <button type="button" className="kiln-icon-btn shrink-0" aria-label="مساعدة" onClick={() => setHelp(true)}>
        <CircleHelp className="size-4" />
      </button>
      <input
        ref={fileRef}
        type="file"
        accept=".json,application/json"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void useEditor.getState().importProjectFile(file);
          e.target.value = "";
        }}
      />
      <input
        ref={assetRef}
        type="file"
        accept=".glb,.gltf,.obj"
        multiple
        className="hidden"
        onChange={(e) => {
          if (e.target.files?.length) void useEditor.getState().importAssets(e.target.files);
          e.target.value = "";
        }}
      />
      <span className="hidden" id="kiln-import-project">
        <button type="button" onClick={() => fileRef.current?.click()}>
          استيراد مشروع
        </button>
      </span>
    </header>
  );
}

function nodeIcon(node: SceneNode) {
  if (node.kind === "character") return PersonStanding;
  if (node.kind === "camera") return Camera;
  if (node.kind === "light") return node.light === "directional" ? Sun : Lightbulb;
  if (node.kind === "group") return Group;
  if (node.kind === "model") return Box;
  const map: Record<Prim, typeof Box> = {
    box: Box,
    sphere: Circle,
    cylinder: Cylinder,
    cone: Cone,
    torus: Torus,
    plane: Grid3x3,
  };
  return node.primitive ? map[node.primitive] : Box;
}

export function Hierarchy() {
  const project = useEditor((s) => s.project);
  const selectedId = useEditor((s) => s.selectedId);
  const select = useEditor((s) => s.select);
  const toggleVisible = useEditor((s) => s.toggleVisible);
  const requestFocus = useEditor((s) => s.requestFocus);
  if (!project) return null;
  const scene = activeScene(project);
  const render = (parentId: string | null, depth: number) =>
    scene.nodes
      .filter((n) => n.parentId === parentId)
      .map((node) => {
        const Icon = nodeIcon(node);
        return (
          <div key={node.id}>
            <div
              className={cn(
                "flex h-11 items-center gap-1 pe-1",
                selectedId === node.id ? "bg-elevated text-primary" : "hover:bg-elevated",
              )}
              style={{ paddingInlineStart: `${8 + depth * 12}px` }}
            >
              <button
                type="button"
                className="flex min-w-0 flex-1 items-center gap-2 text-start text-sm"
                onClick={() => select(node.id)}
                onDoubleClick={() => {
                  select(node.id);
                  requestFocus();
                }}
              >
                <Icon className="size-4 shrink-0" />
                <span className="truncate">{node.name}</span>
              </button>
              <button
                type="button"
                className="grid size-11 place-items-center text-muted"
                aria-label={node.visible ? "إخفاء" : "إظهار"}
                onClick={() => toggleVisible(node.id)}
              >
                {node.visible ? <Eye className="size-4" /> : <EyeOff className="size-4" />}
              </button>
            </div>
            {render(node.id, depth + 1)}
          </div>
        );
      });
  return (
    <div className="flex h-full min-h-0 flex-col bg-surface">
      <div className="flex h-11 items-center justify-between border-b border-border px-3">
        <h2 className="text-sm font-medium">التسلسل</h2>
        <AddMenu compact />
      </div>
      <div className="scroll-thin min-h-0 flex-1 overflow-auto">{render(null, 0)}</div>
    </div>
  );
}

function descendants(nodes: SceneNode[], id: string) {
  const set = new Set<string>();
  let grew = true;
  while (grew) {
    grew = false;
    for (const n of nodes) {
      if (n.parentId && (n.parentId === id || set.has(n.parentId)) && !set.has(n.id)) {
        set.add(n.id);
        grew = true;
      }
    }
  }
  return set;
}

export function Inspector() {
  const project = useEditor((s) => s.project);
  const selectedId = useEditor((s) => s.selectedId);
  const updateNode = useEditor((s) => s.updateNode);
  const updateScene = useEditor((s) => s.updateScene);
  const deleteSelected = useEditor((s) => s.deleteSelected);
  const duplicateSelected = useEditor((s) => s.duplicateSelected);
  const deleteScene = useEditor((s) => s.deleteScene);
  const mode = useEditor((s) => s.mode);
  if (!project) return null;
  const scene = activeScene(project);
  const node = scene.nodes.find((n) => n.id === selectedId) ?? null;
  const locked = mode !== "edit";
  const patch = (p: Partial<SceneNode>) => {
    if (!node) return;
    updateNode(node.id, p, { history: false });
  };
  return (
    <div className="scroll-thin flex h-full min-h-0 flex-col overflow-auto bg-surface">
      <div className="flex h-11 items-center border-b border-border px-3">
        <h2 className="text-sm font-medium">الخصائص</h2>
      </div>
      {locked ? <p className="px-3 py-2 text-xs text-muted">أوقف التشغيل للتعديل. المعاينة تحاكي المشهد الآن.</p> : null}
      {!node ? (
        <SceneFields sceneName={scene.name} sky={scene.sky} gravity={scene.gravity} fog={scene.fog} canDelete={project.scenes.length > 1} onDelete={() => deleteScene(scene.id)} />
      ) : (
        <>
          <Section title="العنصر">
            <input
              className="kiln-field"
              aria-label="الاسم"
              value={node.name}
              disabled={locked}
              onFocus={() => useEditor.getState().beginGesture()}
              onBlur={() => useEditor.getState().endGesture()}
              onChange={(e) => patch({ name: e.target.value })}
            />
            <label className="flex flex-col gap-1 text-xs text-muted">
              الأصل
              <select
                className="kiln-field"
                disabled={locked}
                value={node.parentId ?? ""}
                onChange={(e) => updateNode(node.id, { parentId: e.target.value || null })}
              >
                <option value="">بدون</option>
                {scene.nodes
                  .filter((n) => n.id !== node.id && !descendants(scene.nodes, node.id).has(n.id))
                  .map((n) => (
                    <option key={n.id} value={n.id}>
                      {n.name}
                    </option>
                  ))}
              </select>
            </label>
          </Section>
          <Section title="التحويل">
            <Row3 labels={["X", "Y", "Z"]} value={node.position} onChange={(position) => patch({ position })} />
            <Row3 labels={["د X", "د Y", "د Z"]} value={node.rotation} onChange={(rotation) => patch({ rotation })} />
            <Row3 labels={["ح X", "ح Y", "ح Z"]} value={node.scale} onChange={(scale) => patch({ scale })} />
          </Section>
          {node.kind === "mesh" || node.kind === "character" || node.kind === "model" ? (
            <Section title="الخامة">
              <div className="grid grid-cols-2 gap-2">
                <label className="flex flex-col gap-1 text-xs text-muted">
                  اللون
                  <input className="kiln-field" type="color" value={safeHex(node.color)} disabled={locked} onChange={(e) => updateNode(node.id, { color: e.target.value })} />
                </label>
                <label className="flex flex-col gap-1 text-xs text-muted">
                  التوهج
                  <input className="kiln-field" type="color" value={safeHex(node.emissive)} disabled={locked} onChange={(e) => updateNode(node.id, { emissive: e.target.value })} />
                </label>
              </div>
              <Slider label="الشفافية" min={0.05} max={1} step={0.01} value={node.opacity} disabled={locked} onChange={(opacity) => patch({ opacity })} />
              {node.kind !== "model" ? (
                <>
                  <Slider label="المعدن" min={0} max={1} step={0.01} value={node.metalness} disabled={locked} onChange={(metalness) => patch({ metalness })} />
                  <Slider label="الخشونة" min={0} max={1} step={0.01} value={node.roughness} disabled={locked} onChange={(roughness) => patch({ roughness })} />
                  <Slider label="قوة التوهج" min={0} max={3} step={0.05} value={node.emissiveIntensity} disabled={locked} onChange={(emissiveIntensity) => patch({ emissiveIntensity })} />
                </>
              ) : (
                <p className="text-xs text-muted">لون المجسم المستورد يصبغ الخامة. الأبيض يُبقي الملمس كما هو.</p>
              )}
            </Section>
          ) : null}
          {node.kind === "light" ? (
            <Section title="الإضاءة">
              <label className="flex flex-col gap-1 text-xs text-muted">
                اللون
                <input className="kiln-field" type="color" value={safeHex(node.color)} disabled={locked} onChange={(e) => updateNode(node.id, { color: e.target.value })} />
              </label>
              <Slider label="الشدة" min={0} max={node.light === "point" || node.light === "spot" ? 80 : 8} step={0.05} value={node.intensity ?? 1} disabled={locked} onChange={(intensity) => patch({ intensity })} />
              {node.light === "directional" ? <p className="text-xs text-muted">الضوء الموجه يضيء مركز المشهد. حرّكه ليغيّر زاوية الشمس.</p> : null}
            </Section>
          ) : null}
          {node.kind === "camera" ? (
            <Section title="الكاميرا">
              <Slider label="مجال الرؤية" min={20} max={90} step={1} value={node.fov ?? 50} disabled={locked} onChange={(fov) => patch({ fov })} />
            </Section>
          ) : null}
          {node.kind === "mesh" || node.kind === "character" || node.kind === "model" ? (
            <Section title="الفيزياء">
              <select className="kiln-field" disabled={locked} value={node.physics} onChange={(e) => updateNode(node.id, { physics: e.target.value as SceneNode["physics"] })}>
                <option value="none">بدون</option>
                <option value="static">ثابت</option>
                <option value="dynamic">ديناميكي</option>
              </select>
              <div className="grid grid-cols-3 gap-2">
                <Num label="كتلة" value={node.mass} onChange={(mass) => patch({ mass })} />
                <Num label="ارتداد" value={node.restitution} onChange={(restitution) => patch({ restitution })} />
                <Num label="احتكاك" value={node.friction} onChange={(friction) => patch({ friction })} />
              </div>
              <p className="text-xs text-muted">تصادم صناديق محورها العالم، والجاذبية من إعدادات المشهد. الأرضية مستوى أفقي.</p>
            </Section>
          ) : null}
          <Section title="السكربت">
            <textarea
              className="kiln-field h-36 py-2 font-mono leading-relaxed"
              dir="ltr"
              disabled={locked}
              value={node.script}
              spellCheck={false}
              onFocus={() => useEditor.getState().beginGesture()}
              onBlur={() => useEditor.getState().endGesture()}
              onChange={(e) => patch({ script: e.target.value })}
            />
            <ScriptErrors source={node.script} />
            <div className="flex flex-wrap gap-1">
              <Preset label="تحكم" source={PRESET_PLAYER} current={node.script} onApply={(script) => updateNode(node.id, { script })} />
              <Preset label="دوران" source={PRESET_SPIN} current={node.script} onApply={(script) => updateNode(node.id, { script })} />
              <Preset label="تمايل" source={PRESET_BOB} current={node.script} onApply={(script) => updateNode(node.id, { script })} />
              <Preset label="دوران ومشي" source={PRESET_PATROL} current={node.script} onApply={(script) => updateNode(node.id, { script })} />
            </div>
            <p className="text-xs leading-relaxed text-muted" dir="ltr">
              عند w: تحرك أمام 6 · انعطف يسار 140 · دوران y 40 · تمايل 0.3 2 · قفز 7 · لون #e09a45
            </p>
          </Section>
          <Section title="إجراءات">
            <div className="flex gap-2">
              <button type="button" className="kiln-icon-btn bg-elevated" disabled={locked} onClick={duplicateSelected}>
                <Copy className="size-4" />
                تكرار
              </button>
              <button type="button" className="kiln-icon-btn bg-elevated" disabled={locked} onClick={deleteSelected}>
                <Trash2 className="size-4" />
                حذف
              </button>
            </div>
          </Section>
        </>
      )}
    </div>
  );
}

function safeHex(value: string) {
  return /^#([0-9a-f]{6})$/i.test(value) ? value : "#d9d3c7";
}

function ScriptErrors({ source }: { source: string }) {
  const { errors } = parseScript(source);
  if (!errors.length) return null;
  return (
    <ul className="text-xs text-danger">
      {errors.map((e) => (
        <li key={e}>{e}</li>
      ))}
    </ul>
  );
}

function Preset({ label, source, current, onApply }: { label: string; source: string; current: string; onApply: (s: string) => void }) {
  return (
    <button
      type="button"
      className="h-9 rounded-md bg-elevated px-2 text-xs"
      onClick={() => onApply(current.trim() ? `${current.trim()}\n${source}` : source)}
    >
      {label}
    </button>
  );
}

function Slider({
  label,
  value,
  min,
  max,
  step,
  onChange,
  disabled,
}: {
  label: string;
  value: number;
  min: number;
  max: number;
  step: number;
  onChange: (n: number) => void;
  disabled?: boolean;
}) {
  return (
    <label className="flex flex-col gap-1 text-xs text-muted">
      <span className="flex justify-between">
        {label}
        <span className="font-mono text-fg" dir="ltr">
          {trimNum(value)}
        </span>
      </span>
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        disabled={disabled}
        onPointerDown={() => useEditor.getState().beginGesture()}
        onPointerUp={() => useEditor.getState().endGesture()}
        onChange={(e) => onChange(Number(e.target.value))}
      />
    </label>
  );
}

function SceneFields({
  sceneName,
  sky,
  gravity,
  fog,
  canDelete,
  onDelete,
}: {
  sceneName: string;
  sky: string;
  gravity: number;
  fog: number;
  canDelete: boolean;
  onDelete: () => void;
}) {
  const updateScene = useEditor((s) => s.updateScene);
  return (
    <>
      <p className="px-3 pt-3 text-sm text-muted">لم يُحدد عنصر. هذه إعدادات المشهد الحالي.</p>
      <Section title="المشهد">
        <input className="kiln-field" aria-label="اسم المشهد" value={sceneName} onChange={(e) => updateScene({ name: e.target.value })} />
        <label className="flex flex-col gap-1 text-xs text-muted">
          لون السماء
          <input className="kiln-field" type="color" value={safeHex(sky)} onChange={(e) => updateScene({ sky: e.target.value })} />
        </label>
        <Num label="الجاذبية" value={gravity} onChange={(g) => updateScene({ gravity: g })} />
        <Num label="الضباب (0 لإيقافه)" value={fog} onChange={(f) => updateScene({ fog: f })} />
        <button type="button" className="kiln-icon-btn bg-elevated" disabled={!canDelete} onClick={onDelete}>
          <Trash2 className="size-4" />
          حذف المشهد
        </button>
      </Section>
    </>
  );
}

export function Dock() {
  const dock = useEditor((s) => s.dock);
  const setDock = useEditor((s) => s.setDock);
  const assets = useEditor((s) => s.assets);
  const logs = useEditor((s) => s.logs);
  const instantiate = useEditor((s) => s.instantiateAsset);
  const remove = useEditor((s) => s.removeAsset);
  const copyScene = useEditor((s) => s.copyScene);
  const input = useRef<HTMLInputElement>(null);
  return (
    <div className="flex h-full min-h-0 flex-col bg-surface">
      <div className="flex h-11 items-center gap-1 border-b border-border px-2">
        <button type="button" className="kiln-icon-btn" data-active={dock === "assets" ? "true" : "false"} onClick={() => setDock("assets")}>
          الأصول
        </button>
        <button type="button" className="kiln-icon-btn" data-active={dock === "console" ? "true" : "false"} onClick={() => setDock("console")}>
          السجل
        </button>
        <button type="button" className="kiln-icon-btn ms-auto" onClick={() => void copyScene()}>
          نسخ المشهد
        </button>
      </div>
      {dock === "assets" ? (
        <div
          className="scroll-thin flex min-h-0 flex-1 gap-2 overflow-auto p-2"
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            if (e.dataTransfer.files?.length) void useEditor.getState().importAssets(e.dataTransfer.files);
          }}
        >
          <button type="button" className="flex h-24 w-28 shrink-0 flex-col items-center justify-center gap-1 rounded-lg border border-dashed border-border text-xs text-muted" onClick={() => input.current?.click()}>
            <Upload className="size-4" />
            GLB / OBJ
          </button>
          {assets.length === 0 ? <p className="self-center text-xs text-muted">أسقط ملف GLB أو GLTF أو OBJ هنا ليظهر في المشهد.</p> : null}
          {assets.map((asset) => (
            <div key={asset.id} className="flex h-24 w-36 shrink-0 flex-col justify-between rounded-lg border border-border bg-bg p-2">
              <p className="truncate text-xs">{asset.name}</p>
              <div className="flex gap-1">
                <button type="button" className="h-9 flex-1 rounded bg-elevated text-xs" onClick={() => instantiate(asset.id)}>
                  إضافة
                </button>
                <button type="button" className="grid size-9 place-items-center rounded bg-elevated" aria-label="حذف الأصل" onClick={() => void remove(asset.id)}>
                  <Trash2 className="size-3.5" />
                </button>
              </div>
            </div>
          ))}
          <input
            ref={input}
            className="hidden"
            type="file"
            accept=".glb,.gltf,.obj"
            multiple
            onChange={(e) => {
              if (e.target.files?.length) void useEditor.getState().importAssets(e.target.files);
              e.target.value = "";
            }}
          />
        </div>
      ) : (
        <ul className="scroll-thin min-h-0 flex-1 overflow-auto px-3 py-2 font-mono text-xs" dir="ltr">
          {logs.length === 0 ? <li className="text-muted">لا رسائل.</li> : null}
          {logs.map((line) => (
            <li key={line.id} className={line.level === "error" ? "text-danger" : "text-fg"}>
              {line.text}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

export function ToolRail() {
  const tool = useEditor((s) => s.tool);
  const setTool = useEditor((s) => s.setTool);
  const snap = useEditor((s) => s.snap);
  const grid = useEditor((s) => s.grid);
  const mode = useEditor((s) => s.mode);
  return (
    <div className="absolute top-3 left-3 z-10 flex flex-col gap-1" dir="ltr">
      {TOOLS.map((item) => (
        <button
          key={item.id}
          type="button"
          className="kiln-icon-btn bg-surface/90 border border-border"
          data-active={tool === item.id ? "true" : "false"}
          aria-label={item.label}
          title={`${item.label} (${item.key})`}
          disabled={mode !== "edit"}
          onClick={() => setTool(item.id)}
        >
          <item.icon className="size-4" />
        </button>
      ))}
      <button type="button" className="kiln-icon-btn border border-border bg-surface" data-active={snap ? "true" : "false"} aria-label="الالتصاق بالشبكة" onClick={() => useEditor.getState().toggleSnap()}>
        <span className="text-xs font-medium">½</span>
      </button>
      <button type="button" className="kiln-icon-btn border border-border bg-surface" data-active={grid ? "true" : "false"} aria-label="إظهار الشبكة" onClick={() => useEditor.getState().toggleGrid()}>
        <Grid3x3 className="size-4" />
      </button>
    </div>
  );
}

export function ModeBadge() {
  const mode = useEditor((s) => s.mode);
  const status = useEditor((s) => s.status);
  const label = mode === "play" ? "تشغيل" : mode === "pause" ? "إيقاف مؤقت" : "تعديل";
  return (
    <>
      <div className="pointer-events-none absolute top-3 left-1/2 z-10 -translate-x-1/2 rounded-full border border-border bg-surface px-3 py-1 text-xs">
        {label}
      </div>
      <div className="pointer-events-none absolute bottom-3 right-3 z-10 rounded-md bg-surface/90 px-2 py-1 text-xs text-muted">{status}</div>
      {mode !== "edit" ? (
        <p className="pointer-events-none absolute bottom-3 left-3 z-10 hidden rounded-md bg-surface/90 px-2 py-1 text-xs text-muted lg:block" dir="ltr">
          WASD تحرك · Space قفز · A يسار · D يمين
        </p>
      ) : null}
    </>
  );
}

export function TouchHud() {
  const mode = useEditor((s) => s.mode);
  const pad = useRef<HTMLDivElement>(null);
  const [knob, setKnob] = useState({ x: 0, y: 0 });
  if (mode === "edit") return null;
  const move = (clientX: number, clientY: number) => {
    const rect = pad.current?.getBoundingClientRect();
    if (!rect) return;
    const max = rect.width / 2 - 10;
    let dx = clientX - (rect.left + rect.width / 2);
    let dy = clientY - (rect.top + rect.height / 2);
    const mag = Math.hypot(dx, dy) || 1;
    const clamped = Math.min(mag, max);
    dx = (dx / mag) * clamped;
    dy = (dy / mag) * clamped;
    setKnob({ x: dx, y: dy });
    const nx = dx / max;
    const ny = dy / max;
    const z = { x: -nx, y: -ny };
    const m = Math.hypot(z.x, z.y);
    if (m < 0.18) useEditor.getState().setStick(0, 0);
    else {
      const scale = (m - 0.18) / 0.82 / m;
      useEditor.getState().setStick(z.x * scale, z.y * scale);
    }
  };
  return (
    <div className="pointer-events-none absolute inset-0 z-20 lg:hidden" dir="ltr">
      <div
        ref={pad}
        className="pointer-events-auto absolute bottom-4 left-4 size-28 touch-none rounded-full border border-border bg-surface/80"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          move(e.clientX, e.clientY);
        }}
        onPointerMove={(e) => {
          if (e.currentTarget.hasPointerCapture(e.pointerId)) move(e.clientX, e.clientY);
        }}
        onPointerUp={(e) => {
          setKnob({ x: 0, y: 0 });
          useEditor.getState().setStick(0, 0);
          e.currentTarget.releasePointerCapture(e.pointerId);
        }}
        onPointerCancel={() => {
          setKnob({ x: 0, y: 0 });
          useEditor.getState().setStick(0, 0);
        }}
      >
        <span className="absolute top-1/2 left-1/2 size-11 -translate-x-1/2 -translate-y-1/2 rounded-full bg-primary" style={{ marginLeft: knob.x, marginTop: knob.y }} />
      </div>
      <button
        type="button"
        className="pointer-events-auto absolute right-4 bottom-6 size-16 touch-none rounded-full bg-primary text-sm font-semibold text-primary-fg"
        onPointerDown={(e) => {
          e.currentTarget.setPointerCapture(e.pointerId);
          useEditor.getState().setJumpHeld(true);
        }}
        onPointerUp={() => useEditor.getState().setJumpHeld(false)}
        onPointerCancel={() => useEditor.getState().setJumpHeld(false)}
      >
        قفز
      </button>
    </div>
  );
}

export function Help() {
  const help = useEditor((s) => s.help);
  if (!help) return null;
  return (
    <div className="absolute inset-0 z-40 grid place-items-center bg-bg/80 p-4" onClick={() => useEditor.getState().setHelp(false)}>
      <div className="w-full max-w-md rounded-lg border border-border bg-surface p-4" onClick={(e) => e.stopPropagation()}>
        <h2 className="text-lg font-semibold">Kiln</h2>
        <p className="mt-1 text-sm text-muted">محرر مشاهد ثلاثية الأبعاد. حرّك العناصر، اضبط الخامة والفيزياء، ثم شغّل المعاينة.</p>
        <ul className="mt-3 space-y-1 text-sm">
          <li>Q تحديد · W تحريك · E تدوير · R تحجيم</li>
          <li>Delete حذف · Ctrl+D تكرار · F تركيز · Ctrl+Z تراجع</li>
          <li>Ctrl+Enter تشغيل أو إيقاف</li>
          <li>أثناء التشغيل: WASD للحركة والدوران، والمسافة للقفز. على الهاتف عصا وعزر قفز.</li>
          <li>التصدير ينزّل ملف .kiln.json فيه المشاهد والأصول.</li>
        </ul>
        <button type="button" className="kiln-icon-btn mt-3 bg-primary text-primary-fg" onClick={() => useEditor.getState().setHelp(false)}>
          إغلاق
        </button>
      </div>
    </div>
  );
}

export function Hub() {
  const metas = useEditor((s) => s.metas);
  const openProject = useEditor((s) => s.openProject);
  const newProject = useEditor((s) => s.newProject);
  const deleteProject = useEditor((s) => s.deleteProject);
  const input = useRef<HTMLInputElement>(null);
  return (
    <main className="mx-auto flex h-dvh w-full max-w-5xl flex-col gap-6 overflow-auto px-4 py-6">
      <header className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <p className="text-sm text-primary">Kiln</p>
          <h1 className="text-3xl font-semibold leading-tight">المشاريع</h1>
          <p className="mt-1 max-w-xl text-sm text-muted">ابنِ مشهدًا ثلاثي الأبعاد، جرّبه من المتصفح، ثم صدّره ملفًا واحدًا يمكنك إعادة فتحه.</p>
        </div>
        <div className="flex gap-2">
          <button type="button" className="kiln-icon-btn bg-primary text-primary-fg" onClick={() => void newProject()}>
            <Plus className="size-4" />
            مشروع جديد
          </button>
          <button type="button" className="kiln-icon-btn bg-elevated" onClick={() => input.current?.click()}>
            <FolderOpen className="size-4" />
            استيراد
          </button>
        </div>
      </header>
      <div className="grid gap-3 sm:grid-cols-2">
        {metas.map((meta) => (
          <article key={meta.id} className="flex flex-col gap-3 rounded-lg border border-border bg-surface p-4">
            <h2 className="text-lg font-medium">{meta.name}</h2>
            <p className="text-xs text-muted">{new Intl.DateTimeFormat("ar", { dateStyle: "medium", timeStyle: "short" }).format(meta.updatedAt)}</p>
            <div className="flex gap-2">
              <button type="button" className="kiln-icon-btn bg-primary text-primary-fg" onClick={() => void openProject(meta.id)}>
                فتح
              </button>
              <button type="button" className="kiln-icon-btn bg-elevated" onClick={() => void deleteProject(meta.id)}>
                <Trash2 className="size-4" />
                حذف
              </button>
            </div>
          </article>
        ))}
      </div>
      <input
        ref={input}
        className="hidden"
        type="file"
        accept=".json,application/json"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) void useEditor.getState().importProjectFile(file);
          e.target.value = "";
        }}
      />
    </main>
  );
}

export function Loading() {
  return (
    <main className="grid h-dvh place-items-center bg-bg text-fg">
      <div className="text-center">
        <p className="text-sm text-primary">Kiln</p>
        <h1 className="mt-1 text-2xl font-semibold">يُجهَّز المشهد</h1>
        <p className="mt-2 text-sm text-muted">محرك ثلاثي الأبعاد داخل المتصفح</p>
      </div>
    </main>
  );
}

void Sun;
void type LightKind;
