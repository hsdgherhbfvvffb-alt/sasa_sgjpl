import { getAsset } from "@/lib/editor/db";
import { blip, unlockAudio } from "@/lib/editor/audio";
import { setBridge } from "@/lib/editor/bridge";
import { setInjectedKeys, setSteerOverride, readInput } from "@/lib/editor/input";
import { createRuntime, playerProbe, stepSim, type Runtime } from "@/lib/editor/sim";
import { useEditor } from "@/lib/editor/store";
import { activeScene, type LightKind, type ObjectType, type SceneObject } from "@/lib/editor/types";
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { GLTFExporter } from "three/addons/exporters/GLTFExporter.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";

const PIP = { top: 12, right: 12, width: 288, height: 160 };

const deg = (n: number) => (n * Math.PI) / 180;

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys?: (codes: string[]) => void;
      setSteer?: (v: number) => void;
    };
  }
}

type Entry = {
  id: string;
  type: ObjectType;
  assetId: string | null;
  lightKind: LightKind;
  root: THREE.Group;
  update: (obj: SceneObject, simulating: boolean) => void;
  dispose: () => void;
  marker?: THREE.Object3D;
  helper?: { update: () => void };
  light?: THREE.Light;
  target?: THREE.Object3D;
  token: number;
};

const GEOS = {
  box: new THREE.BoxGeometry(1, 1, 1),
  sphere: new THREE.SphereGeometry(0.5, 28, 18),
  cylinder: new THREE.CylinderGeometry(0.5, 0.5, 1, 24),
  cone: new THREE.ConeGeometry(0.5, 1, 24),
  torus: new THREE.TorusGeometry(0.36, 0.12, 12, 24),
  plane: new THREE.PlaneGeometry(1, 1),
  capsule: new THREE.CapsuleGeometry(0.32, 0.96, 6, 16),
  head: new THREE.SphereGeometry(0.22, 20, 14),
  eye: new THREE.SphereGeometry(0.045, 10, 8),
  back: new THREE.BoxGeometry(0.36, 0.46, 0.08),
  nose: new THREE.ConeGeometry(0.055, 0.14, 8),
  marker: new THREE.OctahedronGeometry(0.28, 0),
  cam: new THREE.BoxGeometry(0.46, 0.3, 0.62),
};

const SHARED = new Set<THREE.BufferGeometry>(Object.values(GEOS));

function disposeTree(root: THREE.Object3D) {
  const seen = new Set<THREE.BufferGeometry>();
  root.traverse((obj) => {
    if (!(obj instanceof THREE.Mesh)) return;
    const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
    for (const mat of mats) mat.dispose();
    if (!SHARED.has(obj.geometry) && !seen.has(obj.geometry)) {
      seen.add(obj.geometry);
      obj.geometry.dispose();
    }
  });
}

function stamp(root: THREE.Object3D, id: string) {
  root.userData.pickId = id;
  root.traverse((obj) => {
    obj.userData.pickId = id;
    if (obj instanceof THREE.Mesh) {
      obj.castShadow = true;
      obj.receiveShadow = true;
    }
  });
}

function applyStandard(mat: THREE.MeshStandardMaterial, obj: SceneObject, map: THREE.Texture | null) {
  mat.color.set(obj.color);
  mat.metalness = obj.metalness;
  mat.roughness = obj.roughness;
  mat.opacity = obj.opacity;
  mat.transparent = obj.opacity < 0.999;
  mat.emissive.set(obj.emissive);
  mat.emissiveIntensity = obj.emissiveIntensity;
  mat.depthWrite = obj.opacity > 0.35;
  mat.map = map;
  mat.needsUpdate = true;
}

function normalizeImport(object: THREE.Object3D) {
  const box = new THREE.Box3().setFromObject(object);
  const size = box.getSize(new THREE.Vector3());
  const center = box.getCenter(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z, 1e-4);
  object.position.sub(center);
  const wrapper = new THREE.Group();
  wrapper.add(object);
  wrapper.scale.setScalar(2 / maxDim);
  return wrapper;
}

export function mountEngine(host: HTMLElement) {
  const engine = new ViewportEngine(host);
  return () => engine.dispose();
}

class ViewportEngine {
  private renderer: THREE.WebGLRenderer;
  private scene = new THREE.Scene();
  private world = new THREE.Group();
  private editorLayer = new THREE.Group();
  private editorCam = new THREE.PerspectiveCamera(48, 1, 0.08, 250);
  private followCam = new THREE.PerspectiveCamera(52, 1, 0.08, 250);
  private previewCam = new THREE.PerspectiveCamera(48, 1, 0.08, 250);
  private orbit: OrbitControls;
  private transform: TransformControls;
  private grid: THREE.GridHelper;
  private outline: THREE.BoxHelper;
  private timer = new THREE.Timer();
  private entries = new Map<string, Entry>();
  private modelCache = new Map<string, THREE.Group>();
  private textureCache = new Map<string, THREE.Texture>();
  private loading = new Set<string>();
  private runtime: Runtime | null = null;
  private prevMode = "edit";
  private draggingId: string | null = null;
  private projectId = "";
  private revision = -1;
  private yaw = 0;
  private speed = 0;
  private snapFollow = false;
  private matSig = new Map<string, string>();
  private hudAt = 0;
  private fps = 0;
  private tokens = 0;
  private disposed = false;
  private pointer = new THREE.Vector2();
  private ray = new THREE.Raycaster();
  private readonly v1 = new THREE.Vector3();
  private readonly v2 = new THREE.Vector3();
  private readonly v3 = new THREE.Vector3();
  private downX = 0;
  private downY = 0;
  private resizeObs: ResizeObserver;
  private unsub: () => void;

  constructor(private host: HTMLElement) {
    this.scene.add(this.world, this.editorLayer);
    this.editorCam.position.set(10, 7.5, 12);
    this.editorCam.lookAt(0, 0.6, 0);
    this.grid = new THREE.GridHelper(40, 40, 0xc4844a, 0x2c3548);
    this.grid.position.y = 0.001;
    this.editorLayer.add(this.grid);
    this.outline = new THREE.BoxHelper(new THREE.Object3D(), 0xe09a4b);
    this.outline.visible = false;
    this.editorLayer.add(this.outline);

    const canvas = document.createElement("canvas");
    canvas.className = "h-full w-full touch-none";
    canvas.style.display = "block";
    this.host.appendChild(canvas);
    this.renderer = new THREE.WebGLRenderer({
      canvas,
      antialias: true,
      alpha: false,
      powerPreference: "high-performance",
      failIfMajorPerformanceCaveat: false,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.NeutralToneMapping;
    this.renderer.toneMappingExposure = 1.08;
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.autoClear = false;
    this.renderer.setClearColor(0x1a2030, 1);

    this.orbit = new OrbitControls(this.editorCam, canvas);
    this.orbit.target.set(0, 0.7, 0);
    this.orbit.enableDamping = true;
    this.orbit.dampingFactor = 0.08;
    this.orbit.maxPolarAngle = Math.PI * 0.49;
    this.orbit.minDistance = 1.2;
    this.orbit.maxDistance = 80;
    this.orbit.mouseButtons = {
      LEFT: THREE.MOUSE.ROTATE,
      MIDDLE: THREE.MOUSE.DOLLY,
      RIGHT: THREE.MOUSE.PAN,
    };
    this.orbit.touches = { ONE: THREE.TOUCH.ROTATE, TWO: THREE.TOUCH.DOLLY_PAN };

    this.transform = new TransformControls(this.editorCam, canvas);
    this.transform.setMode("translate");
    this.scene.add(this.transform.getHelper());
    this.transform.addEventListener("dragging-changed", (event) => {
      const dragging = Boolean(event.value);
      this.orbit.enabled = !dragging;
      if (!dragging) this.draggingId = null;
    });
    this.transform.addEventListener("objectChange", () => this.onGizmo());

    canvas.addEventListener("pointerdown", this.onPointerDown);
    canvas.addEventListener("pointerup", this.onPointerUp);

    this.timer.connect(document);
    this.resizeObs = new ResizeObserver(() => this.resize());
    this.resizeObs.observe(this.host);
    this.resize();

    window.__controlsTest = {
      getYaw: () => this.yaw,
      getSpeed: () => this.speed,
      setKeys: (codes) => setInjectedKeys(codes),
      setSteer: (v) => setSteerOverride(v),
    };
    setBridge({
      exportGlb: () => this.exportGlb(),
      frameSelection: () => this.frameSelection(),
    });

    this.unsub = useEditor.subscribe((state) => {
      if (state.revision !== this.revision) this.reconcile(state.revision);
    });
    this.reconcile(useEditor.getState().revision);
    this.renderer.setAnimationLoop(() => this.frame());
  }

  private resize() {
    const w = Math.max(1, this.host.clientWidth);
    const h = Math.max(1, this.host.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, w < 800 ? 1.25 : 1.5));
    this.renderer.setSize(w, h, false);
    this.editorCam.aspect = w / h;
    this.editorCam.updateProjectionMatrix();
  }

  private onPointerDown = (event: PointerEvent) => {
    this.downX = event.clientX;
    this.downY = event.clientY;
    if (this.transform.axis) {
      this.orbit.enabled = false;
      const id = useEditor.getState().selectedId;
      if (id) this.draggingId = id;
      useEditor.getState().beginTransform();
    }
  };

  private onPointerUp = (event: PointerEvent) => {
    const state = useEditor.getState();
    this.orbit.enabled = state.mode === "edit" && state.view === "scene";
    useEditor.getState().commitTransform();
    this.draggingId = null;
    if (state.mode !== "edit" || state.view !== "scene") return;
    const dx = event.clientX - this.downX;
    const dy = event.clientY - this.downY;
    if (dx * dx + dy * dy > 16) return;
    if (this.transform.dragging) return;
    this.selectAt(event);
  };

  private selectAt(event: PointerEvent) {
    const rect = this.renderer.domElement.getBoundingClientRect();
    this.pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    this.pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    this.ray.setFromCamera(this.pointer, this.editorCam);
    const roots = [...this.entries.values()].map((entry) => entry.root);
    const markers = [...this.entries.values()].map((entry) => entry.marker).filter(Boolean) as THREE.Object3D[];
    const hits = this.ray.intersectObjects([...roots, ...markers], true);
    for (const hit of hits) {
      let cur: THREE.Object3D | null = hit.object;
      while (cur) {
        const id = cur.userData.pickId;
        if (typeof id === "string") {
          useEditor.getState().select(id);
          return;
        }
        cur = cur.parent;
      }
    }
    useEditor.getState().select(null);
  }

  private onGizmo() {
    const id = this.draggingId ?? useEditor.getState().selectedId;
    const entry = id ? this.entries.get(id) : undefined;
    if (!entry) return;
    const euler = new THREE.Euler().setFromQuaternion(entry.root.quaternion, "XYZ");
    useEditor.getState().setTransform(entry.id, {
      position: { x: entry.root.position.x, y: entry.root.position.y, z: entry.root.position.z },
      rotation: { x: (euler.x * 180) / Math.PI, y: (euler.y * 180) / Math.PI, z: (euler.z * 180) / Math.PI },
      scale: { x: entry.root.scale.x, y: entry.root.scale.y, z: entry.root.scale.z },
    });
  }

  private reconcile(revision: number) {
    this.revision = revision;
    const state = useEditor.getState();
    if (state.project.id !== this.projectId) {
      this.projectId = state.project.id;
      this.modelCache.clear();
      this.textureCache.clear();
      for (const id of [...this.entries.keys()]) this.removeEntry(id);
      this.runtime = null;
      this.prevMode = "edit";
    }
    const sceneData = activeScene(state.project);
    this.renderer.setClearColor(sceneData.background);
    this.scene.background = new THREE.Color(sceneData.background);
    if (sceneData.fog) {
      const fog = this.scene.fog instanceof THREE.Fog ? this.scene.fog : new THREE.Fog(sceneData.background, sceneData.fogNear, sceneData.fogFar);
      fog.color.set(sceneData.background);
      fog.near = sceneData.fogNear;
      fog.far = sceneData.fogFar;
      this.scene.fog = fog;
    } else this.scene.fog = null;

    const ids = new Set(sceneData.objects.map((obj) => obj.id));
    for (const id of [...this.entries.keys()]) {
      if (!ids.has(id)) this.removeEntry(id);
    }
    const simulating = state.mode !== "edit" && this.runtime != null;
    for (const obj of sceneData.objects) {
      let entry = this.entries.get(obj.id);
      if (!entry || entry.type !== obj.type || entry.assetId !== obj.assetId || entry.lightKind !== obj.lightKind) {
        if (entry) this.removeEntry(obj.id);
        entry = this.createEntry(obj);
      }
      const body = simulating ? this.runtime?.bodies.find((item) => item.id === obj.id) : undefined;
      entry.update(obj, Boolean(body));
    }
    this.syncGizmo(state.tool, state.selectedId, state.mode, state.view);
  }

  private syncGizmo(tool: string, selectedId: string | null, mode: string, view: string) {
    const entry = selectedId ? this.entries.get(selectedId) : undefined;
    const show = mode === "edit" && view === "scene" && tool !== "select" && entry;
    if (!show || !entry) {
      this.transform.detach();
      this.transform.getHelper().visible = false;
      return;
    }
    const modeName = tool === "rotate" ? "rotate" : tool === "scale" ? "scale" : "translate";
    this.transform.setMode(modeName);
    this.transform.enabled = true;
    this.transform.getHelper().visible = true;
    if (this.transform.object !== entry.root) this.transform.attach(entry.root);
    const snap = useEditor.getState().snap;
    this.transform.setTranslationSnap(snap ? 0.5 : null);
    this.transform.setRotationSnap(snap ? Math.PI / 12 : null);
    this.transform.setScaleSnap(snap ? 0.1 : null);
  }

  private createEntry(obj: SceneObject): Entry {
    const root = new THREE.Group();
    root.userData.pickId = obj.id;
    this.world.add(root);
    const entry: Entry = {
      id: obj.id,
      type: obj.type,
      assetId: obj.assetId,
      lightKind: obj.lightKind,
      root,
      token: ++this.tokens,
      update: () => {},
      dispose: () => disposeTree(root),
    };
    if (obj.type === "light") this.buildLight(entry, obj);
    else if (obj.type === "camera") this.buildCamera(entry, obj);
    else if (obj.type === "character") this.buildCharacter(entry, obj);
    else if (obj.type === "model") this.buildModel(entry, obj);
    else this.buildPrimitive(entry, obj);
    this.entries.set(obj.id, entry);
    entry.update(obj, false);
    return entry;
  }

  private buildPrimitive(entry: Entry, obj: SceneObject) {
    const geo =
      obj.type === "sphere"
        ? GEOS.sphere
        : obj.type === "cylinder"
          ? GEOS.cylinder
          : obj.type === "cone"
            ? GEOS.cone
            : obj.type === "torus"
              ? GEOS.torus
              : obj.type === "plane"
                ? GEOS.plane
                : obj.type === "capsule"
                  ? GEOS.capsule
                  : GEOS.box;
    const mat = new THREE.MeshStandardMaterial();
    if (obj.type === "plane") mat.side = THREE.DoubleSide;
    const mesh = new THREE.Mesh(geo, mat);
    if (obj.type === "floor") mesh.castShadow = false;
    entry.root.add(mesh);
    stamp(entry.root, obj.id);
    entry.update = (next, simulating) => {
      this.place(entry, next, simulating);
      void this.paint(mat, next);
      mesh.castShadow = next.castShadow && next.type !== "floor";
      mesh.receiveShadow = next.receiveShadow;
    };
  }

  private buildCharacter(entry: Entry, obj: SceneObject) {
    const bodyMat = new THREE.MeshStandardMaterial();
    const headMat = new THREE.MeshStandardMaterial();
    const backMat = new THREE.MeshStandardMaterial();
    const noseMat = new THREE.MeshStandardMaterial();
    const eyeMat = new THREE.MeshStandardMaterial({ color: "#1a120c", roughness: 0.4 });
    const body = new THREE.Mesh(GEOS.capsule, bodyMat);
    const head = new THREE.Mesh(GEOS.head, headMat);
    head.position.set(0, 0.86, 0);
    const eyeL = new THREE.Mesh(GEOS.eye, eyeMat);
    const eyeR = new THREE.Mesh(GEOS.eye, eyeMat);
    eyeL.position.set(-0.08, 0.92, -0.16);
    eyeR.position.set(0.08, 0.92, -0.16);
    const nose = new THREE.Mesh(GEOS.nose, noseMat);
    nose.position.set(0, 0.84, -0.28);
    nose.rotation.x = -Math.PI / 2;
    const back = new THREE.Mesh(GEOS.back, backMat);
    back.position.set(0, 0.18, 0.24);
    entry.root.add(body, head, eyeL, eyeR, nose, back);
    stamp(entry.root, obj.id);
    entry.update = (next, simulating) => {
      this.place(entry, next, simulating);
      bodyMat.color.set(next.color);
      bodyMat.roughness = next.roughness;
      bodyMat.metalness = next.metalness;
      bodyMat.emissive.set(next.emissive);
      bodyMat.emissiveIntensity = next.emissiveIntensity;
      headMat.color.set(next.color).offsetHSL(0.02, 0.05, 0.08);
      headMat.roughness = next.roughness;
      backMat.color.set(next.color).offsetHSL(0, 0.02, -0.22);
      noseMat.color.set(next.color).offsetHSL(0.01, 0.08, -0.08);
    };
  }

  private buildModel(entry: Entry, obj: SceneObject) {
    const placeholder = new THREE.Mesh(
      GEOS.box,
      new THREE.MeshStandardMaterial({ color: obj.color, wireframe: true }),
    );
    entry.root.add(placeholder);
    stamp(entry.root, obj.id);
    const token = entry.token;
    entry.update = (next, simulating) => {
      this.place(entry, next, simulating);
      entry.root.visible = next.visible && !(simulating && this.bodyHidden(next.id));
      if (next.materialOverride) {
        entry.root.traverse((child) => {
          if (!(child instanceof THREE.Mesh)) return;
          if (!(child.material instanceof THREE.MeshStandardMaterial) || child.userData.placeholder) return;
          void this.paint(child.material, next);
        });
      }
    };
    placeholder.userData.placeholder = true;
    if (obj.assetId) void this.fillModel(entry, obj.assetId, token, placeholder);
  }

  private async fillModel(entry: Entry, assetId: string, token: number, placeholder: THREE.Mesh) {
    const template = await this.loadModel(assetId);
    if (this.disposed || entry.token !== token || !template) return;
    const clone = template.clone(true);
    clone.traverse((child) => {
      if (child instanceof THREE.Mesh) {
        const mats = Array.isArray(child.material) ? child.material : [child.material];
        child.material = mats.map((mat) => mat.clone());
        child.castShadow = true;
        child.receiveShadow = true;
        child.userData.pickId = entry.id;
      }
    });
    entry.root.remove(placeholder);
    placeholder.geometry = GEOS.box;
    (placeholder.material as THREE.Material).dispose();
    entry.root.add(clone);
    const obj = activeScene(useEditor.getState().project).objects.find((item) => item.id === entry.id);
    if (obj) entry.update(obj, false);
  }

  private async loadModel(assetId: string): Promise<THREE.Group | null> {
    const cached = this.modelCache.get(assetId);
    if (cached) return cached;
    if (this.loading.has(assetId)) {
      await new Promise((resolve) => setTimeout(resolve, 40));
      return this.modelCache.get(assetId) ?? null;
    }
    this.loading.add(assetId);
    try {
      const row = await getAsset(useEditor.getState().project.id, assetId);
      if (!row) return null;
      let object: THREE.Object3D;
      if (row.format === "obj") {
        object = new OBJLoader().parse(new TextDecoder().decode(row.data));
      } else {
        const gltf = await new Promise<import("three/addons/loaders/GLTFLoader.js").GLTF>((resolve, reject) => {
          new GLTFLoader().parse(row.data, "", resolve, (err) => reject(err ?? new Error("Could not read that model")));
        });
        object = gltf.scene;
      }
      const wrapped = normalizeImport(object);
      this.modelCache.set(assetId, wrapped);
      return wrapped;
    } catch (error) {
      useEditor.getState().setNotice(error instanceof Error ? error.message : "Could not read that model.");
      return null;
    } finally {
      this.loading.delete(assetId);
    }
  }

  private buildLight(entry: Entry, obj: SceneObject) {
    let light: THREE.Light;
    if (obj.lightKind === "ambient") light = new THREE.AmbientLight(obj.color, obj.intensity);
    else if (obj.lightKind === "directional") {
      const dir = new THREE.DirectionalLight(obj.color, obj.intensity);
      dir.castShadow = true;
      dir.shadow.mapSize.set(1024, 1024);
      dir.shadow.camera.near = 0.5;
      dir.shadow.camera.far = 48;
      dir.shadow.camera.left = -18;
      dir.shadow.camera.right = 18;
      dir.shadow.camera.top = 18;
      dir.shadow.camera.bottom = -18;
      dir.shadow.bias = -0.0004;
      dir.shadow.normalBias = 0.04;
      dir.target.position.set(0, 0, 0);
      this.world.add(dir.target);
      entry.target = dir.target;
      light = dir;
    } else if (obj.lightKind === "spot") {
      const spot = new THREE.SpotLight(obj.color, obj.intensity, 40, Math.PI / 7, 0.4, 1);
      spot.castShadow = true;
      spot.target.position.set(0, 0, -4);
      this.world.add(spot.target);
      entry.target = spot.target;
      const helper = new THREE.SpotLightHelper(spot);
      this.editorLayer.add(helper);
      entry.helper = helper;
      light = spot;
    } else {
      light = new THREE.PointLight(obj.color, obj.intensity, 0, 2);
    }
    entry.light = light;
    entry.root.add(light);
    const marker = new THREE.Mesh(
      obj.lightKind === "ambient" ? GEOS.sphere : GEOS.marker,
      new THREE.MeshBasicMaterial({ color: 0xe09a4b, wireframe: true }),
    );
    marker.scale.setScalar(obj.lightKind === "ambient" ? 0.45 : 1);
    marker.userData.pickId = obj.id;
    this.editorLayer.add(marker);
    entry.marker = marker;
    entry.update = (next) => {
      this.place(entry, next, false);
      light.color.set(next.color);
      light.intensity = next.intensity;
      marker.position.copy(entry.root.position);
      if (light instanceof THREE.SpotLight) {
        this.v1.set(0, 0, -1).applyQuaternion(entry.root.quaternion);
        light.target.position.copy(entry.root.position).addScaledVector(this.v1, 5);
        light.target.updateMatrixWorld();
      }
      entry.helper?.update();
    };
    entry.dispose = () => {
      disposeTree(entry.root);
      if (entry.target) entry.target.parent?.remove(entry.target);
      if (entry.helper && entry.helper instanceof THREE.Object3D) {
        entry.helper.parent?.remove(entry.helper);
      }
      marker.parent?.remove(marker);
      (marker.material as THREE.Material).dispose();
    };
  }

  private buildCamera(entry: Entry, obj: SceneObject) {
    const cam = new THREE.PerspectiveCamera(obj.fov, 1, 0.1, 80);
    entry.root.add(cam);
    const marker = new THREE.Mesh(GEOS.cam, new THREE.MeshBasicMaterial({ color: 0xe09a4b, wireframe: true }));
    marker.userData.pickId = obj.id;
    this.editorLayer.add(marker);
    entry.marker = marker;
    const helper = new THREE.CameraHelper(cam);
    this.editorLayer.add(helper);
    entry.helper = helper;
    entry.update = (next) => {
      this.place(entry, next, false);
      cam.fov = next.fov;
      cam.updateProjectionMatrix();
      marker.position.copy(entry.root.position);
      marker.quaternion.copy(entry.root.quaternion);
      helper.update();
    };
    entry.dispose = () => {
      helper.parent?.remove(helper);
      helper.dispose();
      marker.parent?.remove(marker);
      (marker.material as THREE.Material).dispose();
    };
  }

  private place(entry: Entry, obj: SceneObject, simulating: boolean) {
    entry.root.scale.set(obj.scale.x, obj.scale.y, obj.scale.z);
    const body = simulating ? this.runtime?.bodies.find((item) => item.id === obj.id) : undefined;
    if (body) {
      entry.root.position.set(body.px, body.py, body.pz);
      entry.root.rotation.set(deg(body.rx), deg(body.ry), deg(body.rz));
      entry.root.visible = obj.visible && !body.hidden;
      return;
    }
    if (this.draggingId === obj.id) {
      entry.root.visible = obj.visible;
      return;
    }
    entry.root.position.set(obj.position.x, obj.position.y, obj.position.z);
    entry.root.rotation.set(deg(obj.rotation.x), deg(obj.rotation.y), deg(obj.rotation.z));
    entry.root.visible = obj.visible;
  }

  private paintIfNeeded(key: string, mat: THREE.MeshStandardMaterial, obj: SceneObject) {
    const sig = [
      obj.color,
      obj.metalness,
      obj.roughness,
      obj.opacity,
      obj.emissive,
      obj.emissiveIntensity,
      obj.textureId ?? "",
    ].join("|");
    if (this.matSig.get(key) === sig) return;
    this.matSig.set(key, sig);
    void this.paint(mat, obj);
  }
    const map = obj.textureId ? await this.loadTexture(obj.textureId) : null;
    if (this.disposed) return;
    applyStandard(mat, obj, map);
  }

  private async loadTexture(id: string): Promise<THREE.Texture | null> {
    const cached = this.textureCache.get(id);
    if (cached) return cached;
    const row = await getAsset(useEditor.getState().project.id, id);
    if (!row) return null;
    const mime = row.format === "png" ? "image/png" : row.format === "webp" ? "image/webp" : "image/jpeg";
    const url = URL.createObjectURL(new Blob([row.data], { type: mime }));
    const texture = await new Promise<THREE.Texture>((resolve, reject) => {
      new THREE.TextureLoader().load(url, resolve, undefined, () => reject(new Error("Could not read that image")));
    }).catch(() => null);
    URL.revokeObjectURL(url);
    if (!texture) return null;
    texture.colorSpace = THREE.SRGBColorSpace;
    this.textureCache.set(id, texture);
    return texture;
  }

  private bodyHidden(id: string) {
    return Boolean(this.runtime?.bodies.find((body) => body.id === id)?.hidden);
  }

  private removeEntry(id: string) {
    const entry = this.entries.get(id);
    if (!entry) return;
    if (this.transform.object === entry.root) this.transform.detach();
    entry.dispose();
    entry.root.parent?.remove(entry.root);
    entry.marker?.parent?.remove(entry.marker);
    this.entries.delete(id);
  }

  private frame() {
    if (this.disposed) return;
    this.timer.update();
    const dt = Math.min(this.timer.getDelta(), 0.1);
    this.fps = this.fps * 0.85 + (dt > 0 ? 1 / dt : 60) * 0.15;
    const state = useEditor.getState();
    if (state.mode === "play" && this.prevMode !== "play" && this.prevMode !== "pause") {
      this.runtime = createRuntime(activeScene(state.project).objects);
      this.snapFollow = true;
      unlockAudio();
    }
    if (state.mode === "edit" && this.prevMode !== "edit") {
      this.runtime = null;
      this.shake = 0;
      for (const obj of activeScene(state.project).objects) {
        const entry = this.entries.get(obj.id);
        entry?.update(obj, false);
      }
      state.setHud({ score: 0, hp: 3, note: "" });
    }
    if (state.mode === "play" && this.runtime) {
      const sceneData = activeScene(state.project);
      stepSim(this.runtime, readInput(), dt, sceneData.gravity);
      for (const obj of sceneData.objects) this.entries.get(obj.id)?.update(obj, true);
      for (const event of this.runtime.events.splice(0)) {
        if (event.type === "collect") blip(880, 0.1);
        if (event.type === "hurt") {
          blip(130, 0.16);
          this.shake = 0.28;
        }
        if (event.type === "jump") blip(540, 0.05);
        if (event.type === "clear") blip(1040, 0.18);
      }
    }
    const probe = playerProbe(state.mode === "edit" ? null : this.runtime);
    this.yaw = probe.yaw;
    this.speed = probe.speed;
    this.prevMode = state.mode;

    const sceneView = state.mode === "edit" && state.view === "scene";
    this.orbit.enabled = sceneView && !this.transform.dragging;
    if (this.orbit.enabled) this.orbit.update();
    this.editorLayer.visible = sceneView;
    this.grid.visible = sceneView;
    const selected = state.selectedId ? this.entries.get(state.selectedId) : undefined;
    if (sceneView && selected) {
      this.outline.setFromObject(selected.root);
      this.outline.visible = true;
    } else this.outline.visible = false;
    for (const entry of this.entries.values()) entry.helper?.update();

    this.render(state.mode, state.view, sceneView);
    const now = performance.now();
    if (now - this.hudAt > 200) {
      this.hudAt = now;
      const rt = state.mode === "edit" ? null : this.runtime;
      state.setHud({
        fps: Math.round(this.fps),
        tris: this.renderer.info.render.triangles,
        score: rt?.score ?? 0,
        hp: rt?.hp ?? 3,
        note: rt?.note ?? "",
      });
    }
  }

  private render(mode: string, view: string, sceneView: boolean) {
    const canvas = this.renderer.domElement;
    const w = canvas.width;
    const h = canvas.height;
    const cssW = Math.max(1, canvas.clientWidth);
    const cssH = Math.max(1, canvas.clientHeight);
    this.updateGameCamera(mode);
    const main = sceneView ? this.editorCam : mode !== "edit" && this.runtime?.playerId ? this.followCam : this.previewCam;
    if (main === this.followCam) {
      this.followCam.aspect = cssW / cssH;
      this.followCam.updateProjectionMatrix();
    }
    if (main === this.previewCam) {
      this.previewCam.aspect = cssW / cssH;
      this.previewCam.updateProjectionMatrix();
    }
    this.renderer.setScissorTest(false);
    this.renderer.setViewport(0, 0, w, h);
    this.renderer.clear();
    this.renderer.render(this.scene, main);

    const pip = sceneView && cssW >= 1024;
    if (!pip) return;
    const pr = this.renderer.getPixelRatio();
    const pw = Math.floor(PIP.width * pr);
    const ph = Math.floor(PIP.height * pr);
    const px = Math.floor(w - (PIP.right + PIP.width) * pr);
    const py = Math.floor(h - (PIP.top + PIP.height) * pr);
    const helper = this.transform.getHelper();
    const helperWas = helper.visible;
    this.editorLayer.visible = false;
    this.grid.visible = false;
    this.outline.visible = false;
    helper.visible = false;
    this.previewCam.aspect = PIP.width / PIP.height;
    this.previewCam.updateProjectionMatrix();
    this.renderer.setScissorTest(true);
    this.renderer.setViewport(px, py, pw, ph);
    this.renderer.setScissor(px, py, pw, ph);
    this.renderer.clear();
    this.renderer.render(this.scene, this.previewCam);
    this.renderer.setScissorTest(false);
    this.editorLayer.visible = true;
    this.grid.visible = true;
    helper.visible = helperWas;
    const selected = useEditor.getState().selectedId;
    this.outline.visible = Boolean(selected);
  }

  private updateGameCamera(mode: string) {
    const state = useEditor.getState();
    const objects = activeScene(state.project).objects;
    const cams = objects.filter((obj) => obj.type === "camera" && obj.visible);
    const chosen = cams.find((obj) => obj.id === state.selectedId) ?? cams[0];
    const entry = chosen ? this.entries.get(chosen.id) : undefined;
    if (entry) {
      entry.root.updateWorldMatrix(true, true);
      this.previewCam.position.setFromMatrixPosition(entry.root.matrixWorld);
      this.previewCam.quaternion.setFromRotationMatrix(entry.root.matrixWorld);
      this.previewCam.fov = chosen?.fov ?? 50;
    } else {
      this.previewCam.position.set(7, 4.5, 9);
      this.previewCam.lookAt(0, 0.6, 0);
      this.previewCam.fov = 48;
    }
    if (mode === "edit" || !this.runtime?.playerId) return;
    const player = this.runtime.bodies.find((body) => body.id === this.runtime?.playerId);
    if (!player) return;
    const yaw = (player.ry * Math.PI) / 180;
    const fx = -Math.sin(yaw);
    const fz = -Math.cos(yaw);
    this.v1.set(player.px - fx * 6.4, player.py + 2.35, player.pz - fz * 6.4);
    if (this.snapFollow) {
      this.followCam.position.copy(this.v1);
      this.snapFollow = false;
    } else {
      const k = 1 - Math.exp(-5 * Math.min(this.timer.getDelta(), 0.1));
      this.followCam.position.lerp(this.v1, k > 0 ? k : 1);
    }
    if (this.shake > 0) {
      this.shake = Math.max(0, this.shake - 0.016);
      this.followCam.position.x += (Math.random() - 0.5) * this.shake;
      this.followCam.position.y += (Math.random() - 0.5) * this.shake * 0.6;
    }
    this.v2.set(player.px + fx * 0.6, player.py + 0.75, player.pz + fz * 0.6);
    this.followCam.lookAt(this.v2);
  }

  private frameSelection() {
    const state = useEditor.getState();
    const entry = state.selectedId ? this.entries.get(state.selectedId) : undefined;
    const box = new THREE.Box3();
    if (entry) box.setFromObject(entry.root);
    else box.setFromObject(this.world);
    if (box.isEmpty()) return;
    box.getCenter(this.v1);
    box.getSize(this.v2);
    const dist = Math.max(this.v2.length(), 1.2) * 1.35 + 1.2;
    this.v3.set(0.7, 0.48, 1).normalize();
    this.editorCam.position.copy(this.v1).addScaledVector(this.v3, dist);
    this.orbit.target.copy(this.v1);
    this.orbit.update();
  }

  private async exportGlb(): Promise<Uint8Array | null> {
    const group = new THREE.Group();
    const objects = activeScene(useEditor.getState().project).objects;
    for (const obj of objects) {
      if (!obj.visible) continue;
      const entry = this.entries.get(obj.id);
      if (!entry) continue;
      if (obj.type === "light" && entry.light) {
        const clone = entry.light.clone();
        clone.position.copy(entry.root.position);
        if (clone instanceof THREE.DirectionalLight || clone instanceof THREE.SpotLight) {
          clone.target = entry.light instanceof THREE.DirectionalLight || entry.light instanceof THREE.SpotLight
            ? entry.light.target.clone()
            : clone.target;
          group.add(clone.target);
        }
        group.add(clone);
        continue;
      }
      if (obj.type === "camera") {
        const cam = new THREE.PerspectiveCamera(obj.fov, 16 / 9, 0.1, 200);
        cam.position.copy(entry.root.position);
        cam.rotation.copy(entry.root.rotation);
        group.add(cam);
        continue;
      }
      const visual = entry.root.clone(true);
      group.add(visual);
    }
    const exporter = new GLTFExporter();
    const result = await exporter.parseAsync(group, { binary: true });
    return result instanceof ArrayBuffer ? new Uint8Array(result) : null;
  }

  dispose() {
    this.disposed = true;
    this.renderer.setAnimationLoop(null);
    this.unsub();
    this.resizeObs.disconnect();
    this.timer.dispose();
    this.orbit.dispose();
    this.transform.detach();
    this.transform.dispose();
    for (const id of [...this.entries.keys()]) this.removeEntry(id);
    for (const texture of this.textureCache.values()) texture.dispose();
    this.renderer.dispose();
    this.renderer.domElement.remove();
    if (window.__controlsTest?.getYaw) delete window.__controlsTest;
    setBridge(null);
  }
}
