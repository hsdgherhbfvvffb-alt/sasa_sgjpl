import { create } from "zustand";
import {
  activeScene,
  ADD_LIGHTS,
  createBlankProject,
  createDemoProject,
  defaultLift,
  makeNode,
  uid,
} from "./defaults";
import {
  base64ToBuf,
  bufToBase64,
  deleteAssetRecord,
  deleteProjectRecord,
  getAsset,
  guessKind,
  listAssets,
  listProjects,
  loadProject,
  putAsset,
  saveProject,
} from "./persist";
import type {
  AssetKind,
  AssetMeta,
  DockTab,
  LightKind,
  LogLine,
  MobilePanel,
  Mode,
  Prim,
  Project,
  ProjectMeta,
  SceneNode,
  Tool,
} from "./types";

type AddRequest =
  | { kind: "mesh"; primitive: Prim; name: string }
  | { kind: "character" }
  | { kind: "group" }
  | { kind: "camera" }
  | { kind: "light"; light: LightKind; name: string }
  | { kind: "model"; assetId: string; name: string };

type EditorState = {
  ready: boolean;
  screen: "hub" | "editor";
  metas: ProjectMeta[];
  project: Project | null;
  mode: Mode;
  selectedId: string | null;
  tool: Tool;
  snap: boolean;
  grid: boolean;
  panel: MobilePanel;
  dock: DockTab;
  status: string;
  logs: LogLine[];
  assets: AssetMeta[];
  stick: { x: number; y: number };
  jumpHeld: boolean;
  focusTick: number;
  help: boolean;
  savedAt: number;
  boot: () => Promise<void>;
  openHub: () => void;
  openProject: (id: string) => Promise<void>;
  newProject: () => Promise<void>;
  deleteProject: (id: string) => Promise<void>;
  renameProject: (name: string) => void;
  importProjectFile: (file: File) => Promise<void>;
  exportProjectFile: () => Promise<void>;
  copyScene: () => Promise<void>;
  play: () => void;
  pause: () => void;
  stop: () => void;
  select: (id: string | null) => void;
  setTool: (tool: Tool) => void;
  toggleSnap: () => void;
  toggleGrid: () => void;
  setPanel: (panel: MobilePanel) => void;
  setDock: (dock: DockTab) => void;
  setStick: (x: number, y: number) => void;
  setJumpHeld: (held: boolean) => void;
  requestFocus: () => void;
  setHelp: (help: boolean) => void;
  addNode: (req: AddRequest) => void;
  updateNode: (id: string, patch: Partial<SceneNode>, opts?: { history?: boolean }) => void;
  deleteSelected: () => void;
  duplicateSelected: () => void;
  toggleVisible: (id: string) => void;
  updateScene: (patch: Partial<{ name: string; sky: string; gravity: number; fog: number }>) => void;
  addScene: () => void;
  deleteScene: (id: string) => void;
  setScene: (id: string) => void;
  importAssets: (files: FileList | File[]) => Promise<void>;
  removeAsset: (id: string) => Promise<void>;
  instantiateAsset: (id: string) => void;
  undo: () => void;
  redo: () => void;
  beginGesture: () => void;
  endGesture: () => void;
  log: (level: LogLine["level"], text: string) => void;
  saveNow: () => Promise<void>;
};

let gesture = false;
const history: string[] = [];
const future: string[] = [];

function pushHistory(project: Project | null) {
  if (!project) return;
  history.push(JSON.stringify(project));
  if (history.length > 30) history.shift();
  future.length = 0;
}

function editing(mode: Mode) {
  return mode === "edit";
}

async function refreshAssets(projectId: string) {
  return listAssets(projectId);
}

export const useEditor = create<EditorState>((set, get) => ({
  ready: false,
  screen: "editor",
  metas: [],
  project: null,
  mode: "edit",
  selectedId: null,
  tool: "translate",
  snap: false,
  grid: true,
  panel: null,
  dock: "assets",
  status: "جاهز",
  logs: [],
  assets: [],
  stick: { x: 0, y: 0 },
  jumpHeld: false,
  focusTick: 0,
  help: false,
  savedAt: 0,

  boot: async () => {
    try {
      let metas = await listProjects();
      const last = localStorage.getItem("kiln-last");
      let project = last ? await loadProject(last) : null;
      if (!project && metas[0]) project = await loadProject(metas[0].id);
      if (!project) {
        project = createDemoProject();
        await saveProject(project);
        metas = await listProjects();
      }
      const assets = await refreshAssets(project.id);
      set({
        ready: true,
        project,
        metas,
        assets,
        screen: "editor",
        mode: "edit",
        status: project.name,
      });
    } catch (err) {
      const project = createDemoProject();
      set({
        ready: true,
        project,
        screen: "editor",
        status: "تعمل النسخة في الذاكرة فقط",
      });
      get().log("error", err instanceof Error ? err.message : "تعذر فتح الحفظ المحلي");
    }
  },

  openHub: () => {
    if (get().mode !== "edit") get().stop();
    set({ screen: "hub", panel: null });
  },

  openProject: async (id) => {
    const project = await loadProject(id);
    if (!project) return;
    const assets = await refreshAssets(id);
    history.length = 0;
    future.length = 0;
    localStorage.setItem("kiln-last", id);
    set({
      project,
      assets,
      screen: "editor",
      mode: "edit",
      selectedId: null,
      status: project.name,
    });
  },

  newProject: async () => {
    const project = createBlankProject();
    await saveProject(project);
    const metas = await listProjects();
    history.length = 0;
    future.length = 0;
    set({
      project,
      metas,
      assets: [],
      screen: "editor",
      mode: "edit",
      selectedId: null,
      status: "مشروع جديد",
    });
  },

  deleteProject: async (id) => {
    await deleteProjectRecord(id);
    const metas = await listProjects();
    const current = get().project;
    if (current?.id === id) {
      if (metas[0]) {
        await get().openProject(metas[0].id);
        set({ metas });
        return;
      }
      const project = createBlankProject();
      await saveProject(project);
      set({
        project,
        metas: await listProjects(),
        assets: [],
        screen: "editor",
        selectedId: null,
      });
      return;
    }
    set({ metas });
  },

  renameProject: (name) => {
    const project = get().project;
    if (!project || !editing(get().mode)) return;
    const next = { ...project, name: name.trim() || project.name, updatedAt: Date.now() };
    set({ project: next });
  },

  importProjectFile: async (file) => {
    const text = await file.text();
    const data = JSON.parse(text) as {
      format?: string;
      project?: Project;
      assets?: { id: string; name: string; kind: AssetKind; base64: string }[];
    };
    if (data.format !== "kiln-project" || !data.project) {
      get().log("error", "الملف ليس مشروع كيلن");
      return;
    }
    const project = structuredClone(data.project);
    project.id = uid("project");
    project.updatedAt = Date.now();
    const idMap = new Map<string, string>();
    for (const asset of data.assets ?? []) {
      const nid = uid("asset");
      idMap.set(asset.id, nid);
      await putAsset({
        id: nid,
        projectId: project.id,
        name: asset.name,
        kind: asset.kind,
        data: base64ToBuf(asset.base64),
      });
    }
    for (const scene of project.scenes) {
      for (const node of scene.nodes) {
        if (node.assetId && idMap.has(node.assetId)) node.assetId = idMap.get(node.assetId);
      }
    }
    await saveProject(project);
    const metas = await listProjects();
    const assets = await refreshAssets(project.id);
    history.length = 0;
    future.length = 0;
    set({ project, metas, assets, screen: "editor", mode: "edit", selectedId: null, status: "تم الاستيراد" });
    get().log("info", `استُورد المشروع ${project.name}`);
  },

  exportProjectFile: async () => {
    const project = get().project;
    if (!project) return;
    const records = await Promise.all(
      get().assets.map(async (meta) => {
        const full = await getAsset(meta.id);
        if (!full) return null;
        return { id: full.id, name: full.name, kind: full.kind, base64: bufToBase64(full.data) };
      }),
    );
    const payload = {
      format: "kiln-project",
      version: 1,
      exportedAt: new Date().toISOString(),
      notes:
        "ملف مشروع Kiln. أعد استيراده من المحرر، أو اقرأ scenes للعقد و assets لملفات GLB/OBJ بصيغة base64.",
      project,
      assets: records.filter(Boolean),
    };
    const blob = new Blob([JSON.stringify(payload)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${project.name.replace(/\s+/g, "-")}.kiln.json`;
    a.click();
    URL.revokeObjectURL(a.href);
    get().log("info", "تم تنزيل ملف المشروع");
    set({ status: "تم التصدير" });
  },

  copyScene: async () => {
    const project = get().project;
    if (!project) return;
    const scene = activeScene(project);
    await navigator.clipboard.writeText(JSON.stringify(scene, null, 2));
    set({ status: "نُسخ المشهد" });
  },

  play: () => {
    const mode = get().mode;
    if (mode === "play") return;
    set({ mode: "play", panel: null, help: false, status: "تشغيل" });
  },

  pause: () => {
    if (get().mode !== "play") return;
    set({ mode: "pause", status: "إيقاف مؤقت" });
  },

  stop: () => {
    set({
      mode: "edit",
      stick: { x: 0, y: 0 },
      jumpHeld: false,
      status: "تعديل",
    });
  },

  select: (id) => set({ selectedId: id, panel: id ? get().panel : get().panel }),

  setTool: (tool) => set({ tool }),
  toggleSnap: () => set({ snap: !get().snap }),
  toggleGrid: () => set({ grid: !get().grid }),
  setPanel: (panel) => set({ panel: get().panel === panel ? null : panel }),
  setDock: (dock) => set({ dock }),
  setStick: (x, y) => set({ stick: { x, y } }),
  setJumpHeld: (jumpHeld) => set({ jumpHeld }),
  requestFocus: () => set({ focusTick: get().focusTick + 1 }),
  setHelp: (help) => set({ help }),

  addNode: (req) => {
    const { project, mode } = get();
    if (!project || !editing(mode)) return;
    pushHistory(project);
    const scene = activeScene(project);
    const index = scene.nodes.length;
    const x = ((index % 5) - 2) * 1.5;
    let node: SceneNode;
    if (req.kind === "mesh") {
      const lift = defaultLift("mesh", req.primitive);
      node = makeNode({
        id: uid("mesh"),
        name: req.name,
        kind: "mesh",
        primitive: req.primitive,
        position: [x, lift, 0],
        rotation: req.primitive === "plane" ? [-90, 0, 0] : [0, 0, 0],
        scale: req.primitive === "plane" ? [8, 8, 1] : [1, 1, 1],
        physics: req.primitive === "plane" ? "static" : "dynamic",
        color: req.primitive === "plane" ? "#3e463c" : "#d9d3c7",
        restitution: 0.25,
      });
    } else if (req.kind === "character") {
      node = makeNode({
        id: uid("hero"),
        name: "شخصية",
        kind: "character",
        position: [x, 0, 0],
        color: "#efe8dc",
        physics: "dynamic",
        restitution: 0,
        friction: 1,
        script: [
          "عند w: تحرك أمام 6",
          "عند s: تحرك خلف 4",
          "عند a: انعطف يسار 160",
          "عند d: انعطف يمين 160",
          "عند space: قفز 7.5",
        ].join("\n"),
      });
    } else if (req.kind === "group") {
      node = makeNode({ id: uid("group"), name: "مجموعة", kind: "group", position: [x, 0, 0] });
    } else if (req.kind === "camera") {
      node = makeNode({ id: uid("cam"), name: "كاميرا", kind: "camera", position: [x, 2, 6], fov: 50 });
    } else if (req.kind === "light") {
      const found = ADD_LIGHTS.find((l) => l.light === req.light);
      node = makeNode({
        id: uid("light"),
        name: req.name || found?.name || "ضوء",
        kind: "light",
        light: req.light,
        position: [x, req.light === "ambient" ? 2 : 4, 2],
        color: "#fff4e4",
        intensity: req.light === "point" || req.light === "spot" ? 20 : req.light === "ambient" ? 0.5 : 2.5,
      });
    } else {
      node = makeNode({
        id: uid("model"),
        name: req.name,
        kind: "model",
        assetId: req.assetId,
        position: [x, 0, 0],
        color: "#ffffff",
        physics: "static",
      });
    }
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      scenes: project.scenes.map((s) => (s.id === scene.id ? { ...s, nodes: [...s.nodes, node] } : s)),
    };
    set({ project: next, selectedId: node.id, status: `أُضيف ${node.name}` });
  },

  updateNode: (id, patch, opts) => {
    const { project, mode } = get();
    if (!project || !editing(mode)) return;
    if (opts?.history !== false && !gesture) pushHistory(project);
    const scene = activeScene(project);
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      scenes: project.scenes.map((s) =>
        s.id !== scene.id
          ? s
          : {
              ...s,
              nodes: s.nodes.map((n) => (n.id === id ? { ...n, ...patch } : n)),
            },
      ),
    };
    set({ project: next });
  },

  deleteSelected: () => {
    const { project, selectedId, mode } = get();
    if (!project || !selectedId || !editing(mode)) return;
    pushHistory(project);
    const scene = activeScene(project);
    const drop = new Set<string>([selectedId]);
    let grew = true;
    while (grew) {
      grew = false;
      for (const n of scene.nodes) {
        if (n.parentId && drop.has(n.parentId) && !drop.has(n.id)) {
          drop.add(n.id);
          grew = true;
        }
      }
    }
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      scenes: project.scenes.map((s) =>
        s.id !== scene.id ? s : { ...s, nodes: s.nodes.filter((n) => !drop.has(n.id)) },
      ),
    };
    set({ project: next, selectedId: null, status: "حُذف العنصر" });
  },

  duplicateSelected: () => {
    const { project, selectedId, mode } = get();
    if (!project || !selectedId || !editing(mode)) return;
    pushHistory(project);
    const scene = activeScene(project);
    const map = new Map<string, string>();
    const clones: SceneNode[] = [];
    const queue = [selectedId];
    while (queue.length) {
      const id = queue.shift()!;
      if (map.has(id)) continue;
      const src = scene.nodes.find((n) => n.id === id);
      if (!src) continue;
      const nid = uid("copy");
      map.set(id, nid);
      const parentId = src.parentId && map.has(src.parentId) ? map.get(src.parentId)! : src.parentId;
      const shifted = id === selectedId;
      clones.push({
        ...structuredClone(src),
        id: nid,
        name: shifted ? `${src.name} نسخة` : src.name,
        parentId: parentId ?? null,
        position: shifted ? [src.position[0] + 0.8, src.position[1], src.position[2]] : src.position,
      });
      for (const child of scene.nodes) if (child.parentId === id) queue.push(child.id);
    }
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      scenes: project.scenes.map((s) => (s.id === scene.id ? { ...s, nodes: [...s.nodes, ...clones] } : s)),
    };
    set({ project: next, selectedId: map.get(selectedId) ?? null });
  },

  toggleVisible: (id) => {
    const node = activeScene(get().project!).nodes.find((n) => n.id === id);
    if (!node) return;
    get().updateNode(id, { visible: !node.visible });
  },

  updateScene: (patch) => {
    const { project, mode } = get();
    if (!project || !editing(mode)) return;
    pushHistory(project);
    const scene = activeScene(project);
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      scenes: project.scenes.map((s) => (s.id === scene.id ? { ...s, ...patch } : s)),
    };
    set({ project: next });
  },

  addScene: () => {
    const { project, mode } = get();
    if (!project || !editing(mode)) return;
    pushHistory(project);
    const scene = createBlankProject().scenes[0]!;
    scene.name = `مشهد ${project.scenes.length + 1}`;
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      activeSceneId: scene.id,
      scenes: [...project.scenes, scene],
    };
    set({ project: next, selectedId: null, status: scene.name });
  },

  deleteScene: (id) => {
    const { project, mode } = get();
    if (!project || project.scenes.length < 2 || !editing(mode)) return;
    pushHistory(project);
    const scenes = project.scenes.filter((s) => s.id !== id);
    const next: Project = {
      ...project,
      updatedAt: Date.now(),
      scenes,
      activeSceneId: project.activeSceneId === id ? scenes[0]!.id : project.activeSceneId,
    };
    set({ project: next, selectedId: null });
  },

  setScene: (id) => {
    const { project, mode } = get();
    if (!project) return;
    if (mode !== "edit") get().stop();
    set({
      project: { ...get().project!, activeSceneId: id },
      selectedId: null,
    });
  },

  importAssets: async (files) => {
    const project = get().project;
    if (!project) return;
    const list = [...files];
    for (const file of list) {
      const kind = guessKind(file.name);
      if (!kind) {
        get().log("error", `${file.name}: الصيغ المدعومة GLB وGLTF وOBJ`);
        continue;
      }
      try {
        const data = await file.arrayBuffer();
        await validateAsset(kind, data);
        const id = uid("asset");
        await putAsset({ id, projectId: project.id, name: file.name, kind, data });
        get().addNode({ kind: "model", assetId: id, name: file.name.replace(/\.[^.]+$/, "") });
        get().log("info", `استُورد ${file.name}`);
      } catch (err) {
        get().log("error", `${file.name}: ${err instanceof Error ? err.message : "تعذر قراءة الملف"}`);
      }
    }
    set({ assets: await refreshAssets(project.id), dock: "assets" });
  },

  removeAsset: async (id) => {
    await deleteAssetRecord(id);
    const project = get().project;
    if (!project) return;
    set({ assets: await refreshAssets(project.id) });
    get().log("info", "حُذف الأصل. العناصر التي كانت تستخدمه تبقى كعنصر ناقص.");
  },

  instantiateAsset: (id) => {
    const asset = get().assets.find((a) => a.id === id);
    if (!asset) return;
    get().addNode({ kind: "model", assetId: id, name: asset.name.replace(/\.[^.]+$/, "") });
  },

  undo: () => {
    const project = get().project;
    if (!project || !history.length || !editing(get().mode)) return;
    future.push(JSON.stringify(project));
    const prev = history.pop()!;
    set({ project: JSON.parse(prev) as Project, selectedId: null, status: "تراجع" });
  },

  redo: () => {
    const project = get().project;
    if (!project || !future.length || !editing(get().mode)) return;
    history.push(JSON.stringify(project));
    const next = future.pop()!;
    set({ project: JSON.parse(next) as Project, selectedId: null, status: "إعادة" });
  },

  beginGesture: () => {
    if (gesture) return;
    gesture = true;
    pushHistory(get().project);
  },

  endGesture: () => {
    gesture = false;
  },

  log: (level, text) => {
    const line: LogLine = { id: uid("log"), level, text };
    set({ logs: [...get().logs, line].slice(-80), dock: level === "error" ? "console" : get().dock });
  },

  saveNow: async () => {
    const project = get().project;
    if (!project) return;
    try {
      await saveProject(project);
      const metas = await listProjects();
      set({ metas, savedAt: Date.now(), status: "تم الحفظ" });
    } catch (err) {
      get().log("error", err instanceof Error ? err.message : "تعذر الحفظ");
    }
  },
}));

async function validateAsset(kind: AssetKind, data: ArrayBuffer) {
  if (kind === "obj") {
    const { OBJLoader } = await import("three/addons/loaders/OBJLoader.js");
    const text = new TextDecoder().decode(data);
    const group = new OBJLoader().parse(text);
    if (!group.children.length) throw new Error("الملف لا يحتوي هندسة");
    return;
  }
  const { GLTFLoader } = await import("three/addons/loaders/GLTFLoader.js");
  await new Promise<void>((resolve, reject) => {
    new GLTFLoader().parse(
      data,
      "",
      () => resolve(),
      (err) => reject(err instanceof Error ? err : new Error("تعذر تحليل GLTF. استخدم ملف GLB واحدًا.")),
    );
  });
}
