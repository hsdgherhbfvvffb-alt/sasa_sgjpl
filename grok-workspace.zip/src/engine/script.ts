export type Dir = "forward" | "back" | "left" | "right" | "up";

export type Stmt =
  | { op: "spin"; axis: "x" | "y" | "z"; speed: number }
  | { op: "bob"; amp: number; speed: number }
  | { op: "move"; dir: Dir; speed: number; when: string | null }
  | { op: "turn"; dir: "left" | "right"; speed: number; when: string | null }
  | { op: "jump"; force: number; when: string | null }
  | { op: "color"; hex: string; when: string | null };

const OPS: Record<string, Stmt["op"]> = {
  spin: "spin",
  دوران: "spin",
  bob: "bob",
  تمايل: "bob",
  move: "move",
  تحرك: "move",
  turn: "turn",
  انعطف: "turn",
  jump: "jump",
  قفز: "jump",
  color: "color",
  لون: "color",
};

const DIRS: Record<string, Dir> = {
  forward: "forward",
  back: "back",
  left: "left",
  right: "right",
  up: "up",
  أمام: "forward",
  امام: "forward",
  خلف: "back",
  يسار: "left",
  يمين: "right",
  أعلى: "up",
  اعلى: "up",
  فوق: "up",
};

const KEYS: Record<string, string> = {
  w: "w",
  a: "a",
  s: "s",
  d: "d",
  space: "space",
  مسافة: "space",
  up: "up",
  down: "down",
  left: "left",
  right: "right",
  shift: "shift",
};

export const PRESET_PLAYER = [
  "عند w: تحرك أمام 6",
  "عند s: تحرك خلف 4",
  "عند a: انعطف يسار 160",
  "عند d: انعطف يمين 160",
  "عند space: قفز 7.5",
].join("\n");

export const PRESET_SPIN = "دوران y 48";
export const PRESET_BOB = "تمايل 0.35 2";
export const PRESET_PATROL = "تحرك أمام 1.6\nدوران y 28";

function strip(line: string): string {
  const slashed = line.split("//")[0] ?? "";
  const trimmed = slashed.trim();
  if (trimmed.startsWith("#")) return "";
  return trimmed;
}

function num(raw: string | undefined): number | null {
  if (raw == null || raw.trim() === "") return null;
  const n = Number(raw);
  return Number.isFinite(n) ? n : null;
}

function parseCommand(body: string, when: string | null, lineNo: number): { stmt?: Stmt; error?: string } {
  const parts = body.trim().split(/\s+/);
  const op = OPS[parts[0] ?? ""];
  if (!op) return { error: `سطر ${lineNo}: أمر غير معروف` };
  if (op === "spin") {
    const axis = parts[1];
    const speed = num(parts[2]);
    if ((axis !== "x" && axis !== "y" && axis !== "z") || speed == null) {
      return { error: `سطر ${lineNo}: دوران <x|y|z> <سرعة>` };
    }
    return { stmt: { op, axis, speed } };
  }
  if (op === "bob") {
    const amp = num(parts[1]);
    const speed = num(parts[2]);
    if (amp == null || speed == null) return { error: `سطر ${lineNo}: تمايل <مدى> <سرعة>` };
    return { stmt: { op, amp, speed } };
  }
  if (op === "move") {
    const dir = DIRS[parts[1] ?? ""];
    const speed = num(parts[2]);
    if (!dir || speed == null) return { error: `سطر ${lineNo}: تحرك <اتجاه> <سرعة>` };
    return { stmt: { op, dir, speed, when } };
  }
  if (op === "turn") {
    const dir = parts[1] === "left" || parts[1] === "يسار" ? "left" : parts[1] === "right" || parts[1] === "يمين" ? "right" : null;
    const speed = num(parts[2]);
    if (!dir || speed == null) return { error: `سطر ${lineNo}: انعطف <يسار|يمين> <درجة/ث>` };
    return { stmt: { op, dir, speed, when } };
  }
  if (op === "jump") {
    const force = num(parts[1]);
    if (force == null) return { error: `سطر ${lineNo}: قفز <قوة>` };
    return { stmt: { op, force, when } };
  }
  const hex = (parts[1] ?? "").toLowerCase();
  if (!/^#([0-9a-f]{3}|[0-9a-f]{6})$/.test(hex)) return { error: `سطر ${lineNo}: لون <#hex>` };
  return { stmt: { op: "color", hex, when } };
}

export function parseScript(source: string): { statements: Stmt[]; errors: string[] } {
  const statements: Stmt[] = [];
  const errors: string[] = [];
  const lines = source.split(/\r?\n/);
  for (let i = 0; i < lines.length; i++) {
    const raw = strip(lines[i] ?? "");
    if (!raw) continue;
    const whenMatch = /^(?:عند|when)\s+(\S+)\s*:\s*(.*)$/i.exec(raw);
    let when: string | null = null;
    let body = raw;
    if (whenMatch) {
      const key = KEYS[whenMatch[1]!.toLowerCase()] ?? KEYS[whenMatch[1]!];
      if (!key) {
        errors.push(`سطر ${i + 1}: مفتاح غير معروف`);
        continue;
      }
      when = key;
      body = whenMatch[2] ?? "";
    }
    const parsed = parseCommand(body, when, i + 1);
    if (parsed.error) errors.push(parsed.error);
    else if (parsed.stmt) statements.push(parsed.stmt);
  }
  return { statements, errors };
}

export type Analog = { throttle: number; steer: number; jump: boolean };

export function gateOpen(when: string | null, analog: Analog): boolean {
  if (!when) return true;
  if (when === "w") return analog.throttle > 0.12;
  if (when === "s") return analog.throttle < -0.12;
  if (when === "a") return analog.steer > 0.12;
  if (when === "d") return analog.steer < -0.12;
  if (when === "space") return analog.jump;
  return false;
}

export function analogScale(when: string | null, analog: Analog): number {
  if (when === "w") return Math.max(analog.throttle, 0);
  if (when === "s") return Math.max(-analog.throttle, 0);
  if (when === "a") return Math.max(analog.steer, 0);
  if (when === "d") return Math.max(-analog.steer, 0);
  return 1;
}
