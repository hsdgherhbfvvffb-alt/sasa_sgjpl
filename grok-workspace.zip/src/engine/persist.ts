import type { AssetKind, AssetMeta, Project, ProjectMeta } from "./types";

const DB_NAME = "kiln";
const DB_VERSION = 1;

export type AssetRecord = AssetMeta & { data: ArrayBuffer };

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("projects")) db.createObjectStore("projects", { keyPath: "id" });
      if (!db.objectStoreNames.contains("assets")) db.createObjectStore("assets", { keyPath: "id" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

let dbPromise: Promise<IDBDatabase> | null = null;

function db(): Promise<IDBDatabase> {
  if (!dbPromise) dbPromise = openDb();
  return dbPromise;
}

function request<T>(req: IDBRequest<T>): Promise<T> {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}

export async function saveProject(project: Project): Promise<void> {
  const database = await db();
  const tx = database.transaction("projects", "readwrite");
  tx.objectStore("projects").put(project);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
  localStorage.setItem("kiln-last", project.id);
}

export async function loadProject(id: string): Promise<Project | null> {
  const database = await db();
  const row = await request(database.transaction("projects").objectStore("projects").get(id));
  return (row as Project | undefined) ?? null;
}

export async function listProjects(): Promise<ProjectMeta[]> {
  const database = await db();
  const rows = (await request(database.transaction("projects").objectStore("projects").getAll())) as Project[];
  return rows
    .map((p) => ({ id: p.id, name: p.name, updatedAt: p.updatedAt }))
    .sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function deleteProjectRecord(id: string): Promise<void> {
  const database = await db();
  await new Promise<void>((resolve, reject) => {
    const tx = database.transaction(["projects", "assets"], "readwrite");
    tx.objectStore("projects").delete(id);
    const cursorReq = tx.objectStore("assets").openCursor();
    cursorReq.onsuccess = () => {
      const cursor = cursorReq.result;
      if (!cursor) return;
      const value = cursor.value as AssetRecord;
      if (value.projectId === id) cursor.delete();
      cursor.continue();
    };
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function putAsset(record: AssetRecord): Promise<void> {
  const database = await db();
  const tx = database.transaction("assets", "readwrite");
  tx.objectStore("assets").put(record);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export async function getAsset(id: string): Promise<AssetRecord | null> {
  const database = await db();
  const row = await request(database.transaction("assets").objectStore("assets").get(id));
  return (row as AssetRecord | undefined) ?? null;
}

export async function listAssets(projectId: string): Promise<AssetMeta[]> {
  const database = await db();
  const rows = (await request(database.transaction("assets").objectStore("assets").getAll())) as AssetRecord[];
  return rows
    .filter((r) => r.projectId === projectId)
    .map(({ id, projectId: pid, name, kind }) => ({ id, projectId: pid, name, kind }));
}

export async function deleteAssetRecord(id: string): Promise<void> {
  const database = await db();
  const tx = database.transaction("assets", "readwrite");
  tx.objectStore("assets").delete(id);
  await new Promise<void>((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error);
  });
}

export function guessKind(name: string): AssetKind | null {
  const ext = name.split(".").pop()?.toLowerCase();
  if (ext === "glb" || ext === "gltf" || ext === "obj") return ext;
  return null;
}

export function bufToBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let binary = "";
  const size = 0x8000;
  for (let i = 0; i < bytes.length; i += size) {
    binary += String.fromCharCode(...bytes.subarray(i, i + size));
  }
  return btoa(binary);
}

export function base64ToBuf(b64: string): ArrayBuffer {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}
