import type { LightKind, NodeKind, Prim, Project, SceneData, SceneNode, Vec3 } from "./types";

export function uid(prefix = "n"): string {
  return `${prefix}-${Math.random().toString(36).slice(2, 8)}${Date.now().toString(36).slice(-3)}`;
}

export function makeNode(partial: Partial<SceneNode> & Pick<SceneNode, "id" | "name" | "kind">): SceneNode {
  return {
    parentId: null,
    visible: true,
    position: [0, 0, 0],
    rotation: [0, 0, 0],
    scale: [1, 1, 1],
    color: "#d9d3c7",
    metalness: 0.06,
    roughness: 0.62,
    opacity: 1,
    emissive: "#000000",
    emissiveIntensity: 0,
    physics: "none",
    mass: 1,
    restitution: 0.15,
    friction: 0.7,
    script: "",
    ...partial,
  };
}

const PLAYER_SCRIPT = [
  "عند w: تحرك أمام 6",
  "عند s: تحرك خلف 4",
  "عند a: انعطف يسار 160",
  "عند d: انعطف يمين 160",
  "عند space: قفز 7.5",
].join("\n");

function mesh(
  id: string,
  name: string,
  primitive: Prim,
  position: Vec3,
  opts: Partial<SceneNode> = {},
): SceneNode {
  const y = primitive === "plane" ? 0 : primitive === "sphere" || primitive === "cylinder" || primitive === "cone" || primitive === "box" ? 0.5 : 0;
  return makeNode({
    id,
    name,
    kind: "mesh",
    primitive,
    position: [position[0], position[1] || y, position[2]],
    physics: primitive === "plane" ? "static" : "static",
    ...opts,
  });
}

export function emptyScene(id: string, name: string): SceneData {
  return {
    id,
    name,
    sky: "#171b22",
    gravity: 20,
    fog: 48,
    nodes: [
      mesh(uid("ground"), "أرضية", "plane", [0, 0, 0], {
        scale: [28, 28, 1],
        rotation: [-90, 0, 0],
        color: "#3c4438",
        roughness: 0.9,
        metalness: 0,
        physics: "static",
      }),
      makeNode({
        id: uid("sun"),
        name: "شمس",
        kind: "light",
        light: "directional",
        position: [7, 12, 5],
        color: "#fff4e4",
        intensity: 2.8,
      }),
      makeNode({
        id: uid("amb"),
        name: "إضاءة محيطة",
        kind: "light",
        light: "ambient",
        position: [0, 2, 0],
        color: "#c9d2e0",
        intensity: 0.55,
      }),
      makeNode({
        id: uid("cam"),
        name: "كاميرا",
        kind: "camera",
        position: [0, 2.2, 9],
        fov: 50,
      }),
      makeNode({
        id: uid("hero"),
        name: "البطل",
        kind: "character",
        position: [0, 0, 3.4],
        color: "#e7e1d6",
        physics: "dynamic",
        mass: 1,
        restitution: 0,
        friction: 1,
        script: PLAYER_SCRIPT,
      }),
    ],
  };
}

export function createDemoProject(): Project {
  const main: SceneData = {
    id: "scene-main",
    name: "الميدان",
    sky: "#171b22",
    gravity: 20,
    fog: 42,
    nodes: [
      mesh("ground", "أرضية", "plane", [0, 0, 0], {
        position: [0, 0, 0],
        scale: [32, 32, 1],
        rotation: [-90, 0, 0],
        color: "#3e463c",
        roughness: 0.92,
        metalness: 0,
        physics: "static",
      }),
      makeNode({
        id: "sun",
        name: "شمس",
        kind: "light",
        light: "directional",
        position: [8, 12, 6],
        color: "#fff1dc",
        intensity: 3,
      }),
      makeNode({
        id: "amb",
        name: "إضاءة محيطة",
        kind: "light",
        light: "ambient",
        position: [0, 3, 0],
        color: "#d5dbe6",
        intensity: 0.62,
      }),
      makeNode({
        id: "cam",
        name: "كاميرا",
        kind: "camera",
        position: [0, 2.4, 10],
        fov: 48,
      }),
      mesh("crate-a", "صندوق", "box", [-2.2, 0.5, -1.1], {
        position: [-2.2, 0.5, -1.1],
        color: "#b08968",
        roughness: 0.78,
        physics: "static",
      }),
      mesh("crate-b", "صندوق علوي", "box", [-2.2, 1.5, -1.1], {
        position: [-2.2, 1.5, -1.1],
        color: "#c4a27a",
        roughness: 0.74,
        physics: "static",
      }),
      mesh("crate-c", "صندوق جانبي", "box", [2.1, 0.5, -2.2], {
        position: [2.1, 0.5, -2.2],
        scale: [1.2, 1, 1.2],
        color: "#8d6b4a",
        physics: "static",
      }),
      mesh("platform", "منصة", "box", [0, 0.3, -5.2], {
        position: [0, 0.3, -5.2],
        scale: [4.5, 0.6, 3],
        color: "#4c5562",
        metalness: 0.2,
        roughness: 0.45,
        physics: "static",
      }),
      mesh("ball", "كرة", "sphere", [0.2, 3.4, -5.2], {
        position: [0.2, 3.4, -5.2],
        color: "#e09a45",
        metalness: 0.45,
        roughness: 0.28,
        physics: "dynamic",
        mass: 0.6,
        restitution: 0.62,
        friction: 0.4,
      }),
      mesh("pillar", "عمود", "cylinder", [3.4, 1, 0.6], {
        position: [3.4, 1, 0.6],
        scale: [0.7, 2, 0.7],
        color: "#6d675e",
        roughness: 0.8,
        physics: "static",
      }),
      makeNode({
        id: "hero",
        name: "البطل",
        kind: "character",
        position: [0, 0, 3.5],
        color: "#efe8dc",
        physics: "dynamic",
        mass: 1,
        restitution: 0,
        friction: 1,
        script: PLAYER_SCRIPT,
      }),
    ],
  };

  const studio = emptyScene("scene-studio", "الاستوديو");
  studio.sky = "#14110e";
  studio.fog = 28;
  studio.nodes.push(
    mesh("torus", "حلقة", "torus", [-1.4, 1.2, -1], {
      position: [-1.4, 1.2, -1],
      color: "#e09a45",
      metalness: 0.7,
      roughness: 0.25,
      physics: "none",
      script: "دوران y 40\nدوران x 12",
    }),
    mesh("gem", "مخروط", "cone", [1.5, 0.8, -0.4], {
      position: [1.5, 0.8, -0.4],
      color: "#d7c4a4",
      metalness: 0.15,
      roughness: 0.4,
      physics: "static",
      script: "تمايل 0.25 1.6",
    }),
    makeNode({
      id: "point",
      name: "ضوء نقطي",
      kind: "light",
      light: "point",
      position: [-2, 2.4, 1],
      color: "#ffd7a8",
      intensity: 18,
    }),
  );

  return {
    id: "project-demo",
    name: "ملعب كيلن",
    version: 1,
    updatedAt: Date.now(),
    activeSceneId: main.id,
    scenes: [main, studio],
  };
}

export function createBlankProject(name = "مشروع جديد"): Project {
  const scene = emptyScene(uid("scene"), "المشهد الأول");
  return {
    id: uid("project"),
    name,
    version: 1,
    updatedAt: Date.now(),
    activeSceneId: scene.id,
    scenes: [scene],
  };
}

export function activeScene(project: Project): SceneData {
  return project.scenes.find((s) => s.id === project.activeSceneId) ?? project.scenes[0]!;
}

export function defaultLift(kind: NodeKind, primitive?: Prim): number {
  if (kind === "character") return 0;
  if (primitive === "plane") return 0;
  if (primitive === "torus") return 0.5;
  if (kind === "mesh") return 0.5;
  if (kind === "model") return 0;
  return 0;
}

export const ADD_LIGHTS: { light: LightKind; name: string }[] = [
  { light: "directional", name: "ضوء موجه" },
  { light: "point", name: "ضوء نقطي" },
  { light: "spot", name: "ضوء كاشف" },
  { light: "ambient", name: "إضاءة محيطة" },
];

export const ADD_PRIMS: { primitive: Prim; name: string }[] = [
  { primitive: "box", name: "مكعب" },
  { primitive: "sphere", name: "كرة" },
  { primitive: "cylinder", name: "أسطوانة" },
  { primitive: "cone", name: "مخروط" },
  { primitive: "torus", name: "حلقة" },
  { primitive: "plane", name: "أرضية" },
];
