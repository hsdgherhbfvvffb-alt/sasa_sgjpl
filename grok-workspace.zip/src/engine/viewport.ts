import {
  ACESFilmicToneMapping,
  AmbientLight,
  AnimationMixer,
  Box3,
  BoxGeometry,
  BoxHelper,
  BufferGeometry,
  CapsuleGeometry,
  Clock,
  Color,
  ConeGeometry,
  CylinderGeometry,
  DirectionalLight,
  Fog,
  GridHelper,
  Group,
  HemisphereLight,
  Mesh,
  MeshBasicMaterial,
  MeshStandardMaterial,
  Object3D,
  OctahedronGeometry,
  PerspectiveCamera,
  PlaneGeometry,
  PointLight,
  Quaternion,
  Raycaster,
  Scene,
  SphereGeometry,
  SpotLight,
  SRGBColorSpace,
  TorusGeometry,
  Vector2,
  Vector3,
  WebGLRenderer,
  type Light,
  type Material,
} from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";
import { TransformControls } from "three/addons/controls/TransformControls.js";
import { GLTFLoader } from "three/addons/loaders/GLTFLoader.js";
import { OBJLoader } from "three/addons/loaders/OBJLoader.js";
import { clone as cloneSkinned } from "three/addons/utils/SkeletonUtils.js";
import type { GLTF } from "three/addons/loaders/GLTFLoader.js";
import { activeScene } from "./defaults";
import { getAsset } from "./persist";
import type { Body } from "./physics";
import { simulate } from "./physics";
import { analogScale, gateOpen, parseScript, type Analog, type Stmt } from "./script";
import { useEditor } from "./store";
import type { AssetKind, Mode, SceneNode } from "./types";

type SimItem = {
  id: string;
  dynamic: boolean;
  collider: boolean;
  yaw: number;
  yaw0: number;
  spinX: number;
  spinY: number;
  spinZ: number;
  ox: number;
  oy: number;
  oz: number;
  offX: number;
  offY: number;
  offZ: number;
  hx: number;
  hy: number;
  hz: number;
  vx: number;
  vy: number;
  vz: number;
  restitution: number;
  invMass: number;
  grounded: boolean;
  coyote: number;
  baseRotX: number;
  baseRotZ: number;
  statements: Stmt[];
  bobAmp: number;
  bobSpeed: number;
  spawnX: number;
  spawnY: number;
  spawnZ: number;
  spawnYaw: number;
  player: boolean;
};

type Entry = {
  id: string;
  sig: string;
  obj: Object3D;
  mats: MeshStandardMaterial[];
  light: Light | null;
  target: Object3D | null;
};

const DEG = Math.PI / 180;
const tmp = new Vector3();
const tmp2 = new Vector3();
const tmpQ = new Quaternion();

const geo = {
  box: new BoxGeometry(1, 1, 1),
  sphere: new SphereGeometry(0.5, 24, 16),
  cylinder: new CylinderGeometry(0.5, 0.5, 1, 24),
  cone: new ConeGeometry(0.5, 1, 20),
  torus: new TorusGeometry(0.38, 0.14, 12, 28),
  plane: new PlaneGeometry(1, 1),
  capsule: new CapsuleGeometry(0.28, 0.74, 4, 10),
  nose: new BoxGeometry(0.12, 0.1, 0.28),
  marker: new SphereGeometry(0.12, 10, 8),
  cam: new BoxGeometry(0.34, 0.22, 0.42),
  lens: new ConeGeometry(0.1, 0.26, 8),
  oct: new OctahedronGeometry(0.22, 0),
};

const templateCache = new Map<string, Promise<Object3D>>();

function clamp(n: number, a: number, b: number) {
  return Math.max(a, Math.min(b, n));
}

function deadzone(x: number, y: number, dz = 0.18) {
  const m = Math.hypot(x, y);
  if (m < dz) return { x: 0, y: 0 };
  const scale = (m - dz) / (1 - dz) / m;
  return { x: x * scale, y: y * scale };
}

function signature(node: SceneNode) {
  return [node.kind, node.primitive ?? "", node.light ?? "", node.assetId ?? ""].join("|");
}

function setOrigin(obj: Object3D, x: number, y: number, z: number) {
  tmp.set(x, y, z);
  if (obj.parent) obj.parent.worldToLocal(tmp);
  obj.position.copy(tmp);
}

function collectStandard(obj: Object3D) {
  const mats: MeshStandardMaterial[] = [];
  obj.traverse((child) => {
    const mesh = child as Mesh;
    if (!mesh.isMesh) return;
    const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
    for (const mat of list) {
      if (mat instanceof MeshStandardMaterial && !mats.includes(mat)) mats.push(mat);
    }
  });
  return mats;
}

async function loadTemplate(kind: AssetKind, data: ArrayBuffer) {
  if (kind === "obj") {
    const text = new TextDecoder().decode(data);
    const parsed = new OBJLoader().parse(text);
    parsed.traverse((child) => {
      const mesh = child as Mesh;
      if (!mesh.isMesh) return;
      mesh.castShadow = true;
      mesh.receiveShadow = true;
      const current = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
      const color = (current as { color?: Color } | undefined)?.color?.clone() ?? new Color("#dddddd");
      mesh.material = new MeshStandardMaterial({ color, roughness: 0.62, metalness: 0.04 });
    });
    const wrap = new Group();
    wrap.add(parsed);
    fitWrap(wrap);
    return wrap;
  }
  const gltf = await new Promise<GLTF>((resolve, reject) => {
    new GLTFLoader().parse(
      data,
      "",
      (result) => resolve(result),
      (err) => reject(err instanceof Error ? err : new Error("GLTF")),
    );
  });
  gltf.scene.traverse((child) => {
    const mesh = child as Mesh;
    if (!mesh.isMesh) return;
    mesh.castShadow = true;
    mesh.receiveShadow = true;
  });
  const wrap = new Group();
  wrap.add(gltf.scene);
  wrap.userData.clips = gltf.animations;
  fitWrap(wrap);
  return wrap;
}

function fitWrap(wrap: Object3D) {
  const box = new Box3().setFromObject(wrap);
  const size = box.getSize(new Vector3());
  const maxDim = Math.max(size.x, size.y, size.z, 0.001);
  wrap.scale.multiplyScalar(2 / maxDim);
  const fitted = new Box3().setFromObject(wrap);
  const center = fitted.getCenter(new Vector3());
  wrap.position.sub(center);
}

function templateFor(assetId: string): Promise<Object3D> {
  let pending = templateCache.get(assetId);
  if (!pending) {
    pending = (async () => {
      const rec = await getAsset(assetId);
      if (!rec) throw new Error("الأصل غير موجود");
      const built = await loadTemplate(rec.kind, rec.data);
      return built;
    })();
    templateCache.set(assetId, pending);
  }
  return pending;
}

function offsetAt(item: SimItem) {
  const cos = Math.cos(item.yaw - item.yaw0);
  const sin = Math.sin(item.yaw - item.yaw0);
  return {
    x: item.offX * cos + item.offZ * sin,
    y: item.offY,
    z: -item.offX * sin + item.offZ * cos,
  };
}

export function createViewport(canvas: HTMLCanvasElement) {
  const renderer = new WebGLRenderer({
    canvas,
    antialias: window.devicePixelRatio < 2,
    alpha: false,
    powerPreference: "high-performance",
  });
  renderer.outputColorSpace = SRGBColorSpace;
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.05;
  renderer.shadowMap.enabled = true;
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, window.matchMedia("(pointer: coarse)").matches ? 1.25 : 1.75));
  renderer.setClearColor(0x171b22, 1);

  const scene = new Scene();
  const camera = new PerspectiveCamera(50, 1, 0.08, 200);
  camera.position.set(7.2, 5.6, 8.6);

  const orbit = new OrbitControls(camera, canvas);
  orbit.target.set(0, 0.8, 0);
  orbit.enableDamping = true;
  orbit.dampingFactor = 0.12;
  orbit.maxPolarAngle = Math.PI - 0.04;
  orbit.minDistance = 1.2;
  orbit.maxDistance = 80;

  const transform = new TransformControls(camera, canvas);
  const helper = transform.getHelper();
  scene.add(helper);

  const content = new Group();
  const rig = new Group();
  scene.add(content, rig);
  scene.add(new HemisphereLight(0xe7e0d4, 0x1c201c, 0.38));

  const grid = new GridHelper(40, 40, 0x6a563c, 0x2c3340);
  grid.position.y = 0.02;
  scene.add(grid);

  const boxHelper = new BoxHelper(new Object3D(), 0xe09a45);
  scene.add(boxHelper);
  boxHelper.visible = false;

  const clock = new Clock();
  const raycaster = new Raycaster();
  const pointer = new Vector2();
  const entries = new Map<string, Entry>();
  const savedPos = new Vector3();
  const savedTarget = new Vector3(0, 0.8, 0);
  const realKeys = new Set<string>();
  let probeKeys = new Set<string>();
  let steerOverride: number | null = null;
  let sim: SimItem[] | null = null;
  let player: SimItem | null = null;
  let prevMode: Mode = "edit";
  let draggingId: string | null = null;
  let pointerMoved = false;
  let downX = 0;
  let downY = 0;
  let lastFocus = -1;
  let elapsed = 0;
  let jumpPrev = false;
  let jumpBuffer = 0;
  let camFov = 50;
  let syncing = false;

  const home = () => {
    orbit.target.set(0, 0.8, 0);
    camera.position.set(7.2, 5.6, 8.6);
  };

  const resize = () => {
    const w = canvas.clientWidth || 1;
    const h = canvas.clientHeight || 1;
    camera.aspect = w / Math.max(1, h);
    camera.updateProjectionMatrix();
    renderer.setSize(w, h, false);
  };
  const observer = new ResizeObserver(resize);
  observer.observe(canvas.parentElement ?? canvas);
  resize();

  function applyLook(entry: Entry, node: SceneNode) {
    const model = node.kind === "model";
    for (const mat of entry.mats) {
      if (!model || node.color.toLowerCase() !== "#ffffff") mat.color.set(node.color);
      if (!model) {
        mat.metalness = node.metalness;
        mat.roughness = node.roughness;
        mat.emissive.set(node.emissive || "#000000");
        mat.emissiveIntensity = node.emissiveIntensity;
      }
      if (!model || node.opacity < 0.999) {
        mat.opacity = node.opacity;
        mat.transparent = node.opacity < 0.999;
        mat.depthWrite = node.opacity > 0.45;
      }
    }
    if (entry.light) {
      entry.light.color.set(node.color);
      entry.light.intensity = node.intensity ?? 1;
    }
  }

  function disposeEntry(entry: Entry) {
    entry.obj.userData.dead = true;
    entry.obj.removeFromParent();
    entry.target?.removeFromParent();
    entry.obj.traverse((child) => {
      const mesh = child as Mesh;
      if (!mesh.isMesh) return;
      const list = Array.isArray(mesh.material) ? mesh.material : [mesh.material];
      for (const mat of list) {
        if (!mat.userData.keep) mat.dispose();
      }
    });
  }

  function makeStandard(node: SceneNode) {
    return new MeshStandardMaterial({
      color: node.color,
      metalness: node.metalness,
      roughness: node.roughness,
      opacity: node.opacity,
      transparent: node.opacity < 0.999,
      emissive: node.emissive,
      emissiveIntensity: node.emissiveIntensity,
    });
  }

  function buildObject(node: SceneNode): Entry {
    const root = new Group();
    root.userData.nodeId = node.id;
    let light: Light | null = null;
    let target: Object3D | null = null;

    if (node.kind === "mesh" && node.primitive) {
      const mat = makeStandard(node);
      const mesh = new Mesh(geo[node.primitive] as BufferGeometry, mat);
      mesh.castShadow = node.primitive !== "plane";
      mesh.receiveShadow = true;
      root.add(mesh);
    } else if (node.kind === "character") {
      const mat = makeStandard(node);
      const body = new Mesh(geo.capsule, mat);
      body.position.y = 0.65;
      body.castShadow = true;
      body.receiveShadow = true;
      const nose = new Mesh(geo.nose, mat);
      nose.position.set(0, 1.08, -0.34);
      nose.castShadow = true;
      root.add(body, nose);
    } else if (node.kind === "light") {
      const color = new Color(node.color);
      const intensity = node.intensity ?? 1;
      if (node.light === "ambient") light = new AmbientLight(color, intensity);
      else if (node.light === "point") light = new PointLight(color, intensity, 36, 2);
      else if (node.light === "spot") {
        const spot = new SpotLight(color, intensity, 28, Math.PI / 7, 0.5, 2);
        spot.castShadow = true;
        light = spot;
        target = spot.target;
      } else {
        const dir = new DirectionalLight(color, intensity);
        dir.castShadow = true;
        dir.shadow.mapSize.set(1024, 1024);
        dir.shadow.camera.near = 0.4;
        dir.shadow.camera.far = 48;
        dir.shadow.camera.left = -18;
        dir.shadow.camera.right = 18;
        dir.shadow.camera.top = 18;
        dir.shadow.camera.bottom = -18;
        dir.shadow.bias = -0.00035;
        light = dir;
        target = dir.target;
      }
      root.add(light);
      if (target) rig.add(target);
      const marker = new Mesh(geo.marker, new MeshBasicMaterial({ color }));
      marker.userData.marker = true;
      root.add(marker);
    } else if (node.kind === "camera") {
      const mat = new MeshBasicMaterial({ color: 0xe09a45 });
      const body = new Mesh(geo.cam, mat);
      const lens = new Mesh(geo.lens, mat);
      lens.rotation.x = -Math.PI / 2;
      lens.position.z = -0.32;
      body.add(lens);
      body.userData.marker = true;
      root.add(body);
    } else if (node.kind === "model" && node.assetId) {
      const mat = makeStandard({ ...node, color: "#8a8178", roughness: 0.7, metalness: 0 });
      const placeholder = new Mesh(geo.box, mat);
      placeholder.position.y = 0.5;
      placeholder.castShadow = true;
      placeholder.name = "placeholder";
      root.add(placeholder);
      const assetId = node.assetId;
      void templateFor(assetId)
        .then((template) => {
          if (root.userData.dead) return;
          root.remove(placeholder);
          mat.dispose();
          const model = cloneSkinned(template);
          root.add(model);
          const clips = template.userData.clips as import("three").AnimationClip[] | undefined;
          if (clips?.length) {
            const mixer = new AnimationMixer(model);
            for (const clip of clips) mixer.clipAction(clip).play();
            root.userData.mixer = mixer;
          }
          const entry = entries.get(node.id);
          if (entry) entry.mats = collectStandard(root);
          scheduleSync();
        })
        .catch((err: unknown) => {
          mat.color.set("#d4654a");
          useEditor.getState().log("error", err instanceof Error ? err.message : "تعذر عرض المجسم");
        });
    } else {
      const marker = new Mesh(geo.oct, new MeshBasicMaterial({ color: 0x8e95a3, wireframe: true }));
      marker.userData.marker = true;
      root.add(marker);
    }

    content.add(root);
    const entry: Entry = { id: node.id, sig: signature(node), obj: root, mats: collectStandard(root), light, target };
    applyLook(entry, node);
    return entry;
  }

  function aimLights(node: SceneNode, entry: Entry) {
    if (!entry.light || !entry.target) return;
    if (node.light === "directional") {
      entry.target.position.set(0, 0.6, 0);
      return;
    }
    entry.obj.getWorldPosition(tmp);
    entry.obj.getWorldQuaternion(tmpQ);
    tmp2.set(0, 0, -1).applyQuaternion(tmpQ);
    entry.target.position.copy(tmp).add(tmp2.multiplyScalar(8));
  }

  function captureSim(nodes: SceneNode[]) {
    const items: SimItem[] = [];
    const logged: string[] = [];
    for (const node of nodes) {
      if (node.kind !== "mesh" && node.kind !== "character" && node.kind !== "model") continue;
      const entry = entries.get(node.id);
      if (!entry) continue;
      const parsed = parseScript(node.script);
      logged.push(...parsed.errors.map((e) => `${node.name}: ${e}`));
      const obj = entry.obj;
      obj.getWorldPosition(tmp);
      const sx = Math.abs(node.scale[0]) || 0.001;
      const sy = Math.abs(node.scale[1]) || 0.001;
      const sz = Math.abs(node.scale[2]) || 0.001;
      let hx = 0.5 * sx;
      let hy = 0.5 * sy;
      let hz = 0.5 * sz;
      let offX = 0;
      let offY = 0;
      let offZ = 0;
      if (node.kind === "character") {
        hx = 0.3 * sx;
        hy = 0.65 * sy;
        hz = 0.3 * sz;
        offY = 0.65 * sy;
      } else if (node.primitive === "plane") {
        hx = 0.5 * sx;
        hz = 0.5 * sy;
        hy = 0.2;
        offY = -0.2;
      } else if (node.kind === "model") {
        obj.updateWorldMatrix(true, true);
        const box = new Box3().setFromObject(obj);
        if (!box.isEmpty()) {
          const size = box.getSize(new Vector3());
          const center = box.getCenter(new Vector3());
          hx = Math.max(0.08, size.x / 2);
          hy = Math.max(0.08, size.y / 2);
          hz = Math.max(0.08, size.z / 2);
          offX = center.x - tmp.x;
          offY = center.y - tmp.y;
          offZ = center.z - tmp.z;
        }
      }
      const bob = parsed.statements.find((s) => s.op === "bob");
      items.push({
        id: node.id,
        dynamic: node.physics === "dynamic",
        collider: node.physics !== "none",
        yaw: obj.rotation.y,
        yaw0: obj.rotation.y,
        spinX: 0,
        spinY: 0,
        spinZ: 0,
        ox: tmp.x,
        oy: tmp.y,
        oz: tmp.z,
        offX,
        offY,
        offZ,
        hx,
        hy,
        hz,
        vx: 0,
        vy: 0,
        vz: 0,
        restitution: node.restitution,
        invMass: node.mass > 0 ? 1 / node.mass : 1,
        grounded: false,
        coyote: 0,
        baseRotX: obj.rotation.x,
        baseRotZ: obj.rotation.z,
        statements: parsed.statements,
        bobAmp: bob && bob.op === "bob" ? bob.amp : 0,
        bobSpeed: bob && bob.op === "bob" ? bob.speed : 0,
        spawnX: tmp.x,
        spawnY: tmp.y,
        spawnZ: tmp.z,
        spawnYaw: obj.rotation.y,
        player: false,
      });
    }
    player =
      items.find((item) => {
        const node = nodes.find((n) => n.id === item.id);
        return node?.kind === "character" && item.statements.some((s) => s.op === "turn" || s.op === "move");
      }) ??
      items.find((item) => item.statements.some((s) => s.op === "turn")) ??
      null;
    if (player) player.player = true;
    sim = items;
    elapsed = 0;
    jumpBuffer = 0;
    jumpPrev = false;
    if (logged.length) {
      for (const line of logged.slice(0, 6)) useEditor.getState().log("error", line);
    }
  }

  function scheduleSync() {
    requestAnimationFrame(() => sync());
  }

  function sync() {
    if (syncing) return;
    syncing = true;
    try {
      const state = useEditor.getState();
      const project = state.project;
      const mode = state.mode;
      const sceneData = project ? activeScene(project) : null;
      const nodes = sceneData?.nodes ?? [];
      const keep = new Set(nodes.map((n) => n.id));
      for (const [id, entry] of entries) {
        if (!keep.has(id)) {
          disposeEntry(entry);
          entries.delete(id);
        }
      }
      for (const node of nodes) {
        let entry = entries.get(node.id);
        const sig = signature(node);
        if (!entry || entry.sig !== sig) {
          if (entry) disposeEntry(entry);
          entry = buildObject(node);
          entry.sig = sig;
          entries.set(node.id, entry);
        }
        entry.mats = collectStandard(entry.obj);
        applyLook(entry, node);
        entry.obj.visible = node.visible;
        entry.obj.traverse((child) => {
          if (child.userData.marker) child.visible = mode === "edit";
        });
        if (mode === "edit" && node.id !== draggingId) {
          entry.obj.position.set(node.position[0], node.position[1], node.position[2]);
          entry.obj.rotation.set(node.rotation[0] * DEG, node.rotation[1] * DEG, node.rotation[2] * DEG);
          entry.obj.scale.set(node.scale[0], node.scale[1], node.scale[2]);
        }
        if (node.kind === "camera") {
          const persp = camera;
          if (mode !== "edit" && !player) {
            persp.fov = node.fov ?? 50;
          }
        }
        aimLights(node, entry);
      }
      for (const node of nodes) {
        const entry = entries.get(node.id);
        if (!entry) continue;
        const parent = node.parentId ? entries.get(node.parentId)?.obj : content;
        if (parent && entry.obj.parent !== parent) parent.add(entry.obj);
      }

      const enteringPlay = prevMode === "edit" && mode !== "edit";
      const backToEdit = mode === "edit" && prevMode !== "edit";
      if (enteringPlay) {
        savedPos.copy(camera.position);
        savedTarget.copy(orbit.target);
        captureSim(nodes);
        const camNode = nodes.find((n) => n.kind === "camera");
        if (!player && camNode) {
          const obj = entries.get(camNode.id)?.obj;
          if (obj) {
            obj.updateWorldMatrix(true, true);
            obj.getWorldPosition(camera.position);
            obj.getWorldQuaternion(camera.quaternion);
            camera.fov = camNode.fov ?? 50;
            camera.updateProjectionMatrix();
          }
        }
      }
      if (backToEdit) {
        sim = null;
        player = null;
        camera.fov = camFov;
        camera.updateProjectionMatrix();
        camera.position.copy(savedPos);
        orbit.target.copy(savedTarget);
        for (const node of nodes) {
          const entry = entries.get(node.id);
          if (!entry) continue;
          entry.obj.position.set(node.position[0], node.position[1], node.position[2]);
          entry.obj.rotation.set(node.rotation[0] * DEG, node.rotation[1] * DEG, node.rotation[2] * DEG);
          entry.obj.scale.set(node.scale[0], node.scale[1], node.scale[2]);
        }
      }
      prevMode = mode;

      scene.background = new Color(sceneData?.sky ?? "#171b22");
      renderer.setClearColor(sceneData?.sky ?? "#171b22");
      scene.fog = sceneData && sceneData.fog > 0 ? new Fog(sceneData.sky, sceneData.fog * 0.35, sceneData.fog) : null;
      grid.visible = state.grid && mode === "edit";

      const selected = state.selectedId ? entries.get(state.selectedId) : undefined;
      if (mode === "edit" && selected && state.tool !== "select") {
        transform.attach(selected.obj);
        transform.setMode(state.tool);
        transform.enabled = true;
        helper.visible = true;
      } else {
        transform.detach();
        helper.visible = false;
      }
      transform.translationSnap = state.snap ? 0.5 : null;
      transform.rotationSnap = state.snap ? 15 * DEG : null;
      transform.scaleSnap = state.snap ? 0.1 : null;
      orbit.enabled = mode === "edit" && !draggingId;

      if (selected && mode === "edit") {
        boxHelper.setFromObject(selected.obj);
        boxHelper.visible = true;
      } else boxHelper.visible = false;

      if (state.focusTick !== lastFocus) {
        lastFocus = state.focusTick;
        if (selected) {
          selected.obj.getWorldPosition(orbit.target);
          camera.position.copy(orbit.target).add(new Vector3(3.6, 2.6, 3.6));
        } else home();
      }
    } finally {
      syncing = false;
    }
  }

  function flushDrag() {
    if (!draggingId) return;
    const entry = entries.get(draggingId);
    if (!entry) return;
    const obj = entry.obj;
    useEditor.getState().updateNode(
      draggingId,
      {
        position: [obj.position.x, obj.position.y, obj.position.z],
        rotation: [obj.rotation.x / DEG, obj.rotation.y / DEG, obj.rotation.z / DEG],
        scale: [obj.scale.x, obj.scale.y, obj.scale.z],
      },
      { history: false },
    );
  }

  function readAnalog(): Analog {
    const state = useEditor.getState();
    let throttle = 0;
    let steer = 0;
    const down = (code: string) => realKeys.has(code) || probeKeys.has(code);
    if (down("KeyW") || down("ArrowUp")) throttle += 1;
    if (down("KeyS") || down("ArrowDown")) throttle -= 1;
    if (down("KeyA") || down("ArrowLeft")) steer += 1;
    if (down("KeyD") || down("ArrowRight")) steer -= 1;
    const stick = deadzone(state.stick.x, state.stick.y, 0.12);
    throttle += stick.y;
    steer += stick.x;
    const pads = navigator.getGamepads?.() ?? [];
    for (const pad of pads) {
      if (!pad) continue;
      const z = deadzone(pad.axes[0] ?? 0, pad.axes[1] ?? 0);
      steer += -z.x;
      throttle += -z.y;
    }
    if (steerOverride != null) steer = steerOverride;
    const jump = down("Space") || state.jumpHeld || [...pads].some((pad) => pad?.buttons[0]?.pressed);
    return { throttle: clamp(throttle, -1, 1), steer: clamp(steer, -1, 1), jump };
  }

  function step(dt: number) {
    if (!sim) return;
    const gravity = useEditor.getState().project ? activeScene(useEditor.getState().project!).gravity : 20;
    const analog = readAnalog();
    if (analog.jump && !jumpPrev) jumpBuffer = 0.14;
    jumpPrev = analog.jump;
    jumpBuffer = Math.max(0, jumpBuffer - dt);
    elapsed += dt;

    for (const item of sim) {
      const entry = entries.get(item.id);
      if (!entry) continue;
      let yawRate = 0;
      let mx = 0;
      let my = 0;
      let mz = 0;
      let moved = false;
      const fx = -Math.sin(item.yaw);
      const fz = -Math.cos(item.yaw);
      const rx = Math.cos(item.yaw);
      const rz = -Math.sin(item.yaw);
      for (const stmt of item.statements) {
        if (!gateOpen(stmt.when, analog)) continue;
        const scale = analogScale(stmt.when, analog);
        if (stmt.op === "spin") {
          const add = stmt.speed * DEG * dt;
          if (stmt.axis === "x") item.spinX += add;
          if (stmt.axis === "y") item.spinY += add;
          if (stmt.axis === "z") item.spinZ += add;
        } else if (stmt.op === "turn") {
          yawRate += (stmt.dir === "left" ? 1 : -1) * stmt.speed * scale;
        } else if (stmt.op === "move") {
          const spd = stmt.speed * scale;
          if (stmt.dir === "forward") {
            mx += fx * spd;
            mz += fz * spd;
          } else if (stmt.dir === "back") {
            mx -= fx * spd;
            mz -= fz * spd;
          } else if (stmt.dir === "left") {
            mx -= rx * spd;
            mz -= rz * spd;
          } else if (stmt.dir === "right") {
            mx += rx * spd;
            mz += rz * spd;
          } else my += spd;
          moved = true;
        } else if (stmt.op === "jump" && item.dynamic && jumpBuffer > 0 && (item.grounded || item.coyote > 0)) {
          item.vy = stmt.force;
          item.grounded = false;
          item.coyote = 0;
          jumpBuffer = 0;
        } else if (stmt.op === "color") {
          for (const mat of entry.mats) mat.color.set(stmt.hex);
        }
      }
      item.yaw += yawRate * DEG * dt;
      if (item.dynamic) {
        if (moved && (mx !== 0 || mz !== 0)) {
          item.vx = mx;
          item.vz = mz;
        } else if (!moved) {
          const damp = Math.exp(-12 * dt);
          item.vx *= damp;
          item.vz *= damp;
        }
        if (my) item.vy = my;
      } else {
        item.ox += mx * dt;
        item.oy += my * dt;
        item.oz += mz * dt;
      }
    }

    const bodies: Body[] = [];
    const linked: SimItem[] = [];
    for (const item of sim) {
      if (!item.collider) continue;
      const o = offsetAt(item);
      bodies.push({
        id: item.id,
        dynamic: item.dynamic,
        cx: item.ox + o.x,
        cy: item.oy + o.y,
        cz: item.oz + o.z,
        hx: item.hx,
        hy: item.hy,
        hz: item.hz,
        vx: item.vx,
        vy: item.vy,
        vz: item.vz,
        restitution: item.restitution,
        invMass: item.dynamic ? item.invMass : 0,
        grounded: false,
      });
      linked.push(item);
    }
    simulate(bodies, dt, gravity);
    for (let i = 0; i < linked.length; i++) {
      const item = linked[i]!;
      const body = bodies[i]!;
      if (!item.dynamic) continue;
      const o = offsetAt(item);
      item.ox = body.cx - o.x;
      item.oy = body.cy - o.y;
      item.oz = body.cz - o.z;
      item.vx = body.vx;
      item.vy = body.vy;
      item.vz = body.vz;
      item.grounded = body.grounded;
      item.coyote = body.grounded ? 0.12 : Math.max(0, item.coyote - dt);
      if (item.oy < -12) {
        item.ox = item.spawnX;
        item.oy = item.spawnY;
        item.oz = item.spawnZ;
        item.vx = 0;
        item.vy = 0;
        item.vz = 0;
        item.yaw = item.spawnYaw;
      }
    }

    for (const item of sim) {
      const entry = entries.get(item.id);
      if (!entry) continue;
      let y = item.oy;
      if (!item.dynamic && item.bobAmp) y += Math.sin(elapsed * item.bobSpeed) * item.bobAmp;
      setOrigin(entry.obj, item.ox, y, item.oz);
      entry.obj.rotation.set(item.baseRotX + item.spinX, item.yaw + item.spinY, item.baseRotZ + item.spinZ);
    }

    if (player) {
      const fx = -Math.sin(player.yaw);
      const fz = -Math.cos(player.yaw);
      const destX = player.ox - fx * 5.5;
      const destY = player.oy + 2.4;
      const destZ = player.oz - fz * 5.5;
      const k = 1 - Math.pow(0.0015, dt);
      camera.position.x += (destX - camera.position.x) * k;
      camera.position.y += (destY - camera.position.y) * k;
      camera.position.z += (destZ - camera.position.z) * k;
      camera.lookAt(player.ox, player.oy + 1.15, player.oz);
    }
  }

  function frameScene(dt: number) {
    const mode = useEditor.getState().mode;
    if (draggingId) flushDrag();
    if (mode === "play") step(dt);
    for (const entry of entries.values()) {
      const mixer = entry.obj.userData.mixer as AnimationMixer | undefined;
      if (mixer && mode === "play") mixer.update(dt);
      const nodeId = entry.id;
      const project = useEditor.getState().project;
      if (!project) continue;
      const node = activeScene(project).nodes.find((n) => n.id === nodeId);
      if (node) aimLights(node, entry);
    }
    if (mode === "edit") orbit.update();
    if (boxHelper.visible) boxHelper.update();
    renderer.render(scene, camera);
  }

  let raf = 0;
  const loop = () => {
    raf = requestAnimationFrame(loop);
    const dt = Math.min(clock.getDelta(), 0.05);
    frameScene(dt);
    if (!window.__kilnReady) {
      window.__kilnReady = true;
      canvas.dataset.ready = "1";
    }
    frame++;
  };
  raf = requestAnimationFrame(loop);

  const onDrag = (event: { value?: boolean }) => {
    const on = Boolean(event.value);
    if (on) {
      draggingId = useEditor.getState().selectedId;
      useEditor.getState().beginGesture();
      orbit.enabled = false;
    } else {
      flushDrag();
      draggingId = null;
      useEditor.getState().endGesture();
      orbit.enabled = useEditor.getState().mode === "edit";
    }
  };
  transform.addEventListener("dragging-changed", onDrag as never);

  const onPointerDown = (event: PointerEvent) => {
    if (event.button !== 0) return;
    pointerMoved = false;
    downX = event.clientX;
    downY = event.clientY;
  };
  const onPointerMove = (event: PointerEvent) => {
    if (Math.hypot(event.clientX - downX, event.clientY - downY) > 5) pointerMoved = true;
  };
  const onPointerUp = (event: PointerEvent) => {
    if (event.button !== 0 || pointerMoved || draggingId) return;
    if (useEditor.getState().mode !== "edit") return;
    const rect = canvas.getBoundingClientRect();
    pointer.x = ((event.clientX - rect.left) / rect.width) * 2 - 1;
    pointer.y = -((event.clientY - rect.top) / rect.height) * 2 + 1;
    raycaster.setFromCamera(pointer, camera);
    const hits = raycaster.intersectObjects(content.children, true);
    let id: string | null = null;
    for (const hit of hits) {
      let obj: Object3D | null = hit.object;
      while (obj) {
        if (typeof obj.userData.nodeId === "string") {
          id = obj.userData.nodeId;
          break;
        }
        obj = obj.parent;
      }
      if (id) break;
    }
    useEditor.getState().select(id);
    if (id && window.innerWidth < 1024) useEditor.setState({ panel: "inspector" });
  };

  const typing = (target: EventTarget | null) => {
    if (!(target instanceof HTMLElement)) return false;
    return target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable;
  };
  const onKeyDown = (event: KeyboardEvent) => {
    if (typing(event.target)) return;
    realKeys.add(event.code);
    if (useEditor.getState().mode !== "edit" && (event.code === "Space" || event.code.startsWith("Arrow"))) {
      event.preventDefault();
    }
  };
  const onKeyUp = (event: KeyboardEvent) => realKeys.delete(event.code);
  const onBlur = () => realKeys.clear();

  canvas.addEventListener("pointerdown", onPointerDown);
  canvas.addEventListener("pointermove", onPointerMove);
  window.addEventListener("pointerup", onPointerUp);
  window.addEventListener("keydown", onKeyDown);
  window.addEventListener("keyup", onKeyUp);
  window.addEventListener("blur", onBlur);
  canvas.addEventListener("contextmenu", (event) => event.preventDefault());

  window.__controlsTest = {
    getYaw: () => player?.yaw ?? 0,
    getSpeed: () => (player ? Math.hypot(player.vx, player.vz) : 0),
    setKeys: (codes) => {
      probeKeys = new Set(codes);
    },
    setSteer: (v) => {
      steerOverride = v;
    },
  };

  const unsub = useEditor.subscribe(() => sync());
  sync();
  home();

  return {
    dispose() {
      cancelAnimationFrame(raf);
      unsub();
      observer.disconnect();
      transform.removeEventListener("dragging-changed", onDrag as never);
      transform.detach();
      transform.dispose();
      orbit.dispose();
      canvas.removeEventListener("pointerdown", onPointerDown);
      canvas.removeEventListener("pointermove", onPointerMove);
      window.removeEventListener("pointerup", onPointerUp);
      window.removeEventListener("keydown", onKeyDown);
      window.removeEventListener("keyup", onKeyUp);
      window.removeEventListener("blur", onBlur);
      for (const entry of entries.values()) disposeEntry(entry);
      renderer.dispose();
      scene.remove(helper);
      if (window.__controlsTest) delete window.__controlsTest;
      window.__kilnReady = false;
    },
  };
}

declare global {
  interface Window {
    __controlsTest?: {
      getYaw: () => number;
      getSpeed: () => number;
      setKeys: (codes: string[]) => void;
      setSteer: (v: number) => void;
    };
    __kilnReady?: boolean;
  }
}
