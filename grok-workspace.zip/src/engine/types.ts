export type Vec3 = [number, number, number];

export type Prim = "box" | "sphere" | "cylinder" | "cone" | "torus" | "plane";

export type NodeKind = "mesh" | "light" | "camera" | "group" | "model" | "character";

export type LightKind = "ambient" | "directional" | "point" | "spot";

export type PhysicsKind = "none" | "static" | "dynamic";

export type SceneNode = {
  id: string;
  name: string;
  kind: NodeKind;
  parentId: string | null;
  visible: boolean;
  position: Vec3;
  rotation: Vec3;
  scale: Vec3;
  primitive?: Prim;
  color: string;
  metalness: number;
  roughness: number;
  opacity: number;
  emissive: string;
  emissiveIntensity: number;
  light?: LightKind;
  intensity?: number;
  fov?: number;
  assetId?: string;
  physics: PhysicsKind;
  mass: number;
  restitution: number;
  friction: number;
  script: string;
};

export type SceneData = {
  id: string;
  name: string;
  sky: string;
  gravity: number;
  fog: number;
  nodes: SceneNode[];
};

export type Project = {
  id: string;
  name: string;
  version: 1;
  updatedAt: number;
  activeSceneId: string;
  scenes: SceneData[];
};

export type AssetKind = "glb" | "gltf" | "obj";

export type AssetMeta = {
  id: string;
  projectId: string;
  name: string;
  kind: AssetKind;
};

export type ProjectMeta = {
  id: string;
  name: string;
  updatedAt: number;
};

export type Tool = "select" | "translate" | "rotate" | "scale";
export type Mode = "edit" | "play" | "pause";
export type DockTab = "assets" | "console";
export type MobilePanel = "hierarchy" | "inspector" | "assets" | null;

export type LogLine = {
  id: string;
  level: "info" | "error";
  text: string;
};
