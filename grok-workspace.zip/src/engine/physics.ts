export type Body = {
  id: string;
  dynamic: boolean;
  cx: number;
  cy: number;
  cz: number;
  hx: number;
  hy: number;
  hz: number;
  vx: number;
  vy: number;
  vz: number;
  restitution: number;
  invMass: number;
  grounded: boolean;
};

function land(b: Body) {
  if (b.vy < -2.2 && b.restitution > 0.08) {
    b.vy = -b.vy * Math.min(0.85, b.restitution);
    b.grounded = false;
    return;
  }
  b.vy = 0;
  b.grounded = true;
}

function separate(a: Body, b: Body) {
  const dx = b.cx - a.cx;
  const dy = b.cy - a.cy;
  const dz = b.cz - a.cz;
  const px = a.hx + b.hx - Math.abs(dx);
  const py = a.hy + b.hy - Math.abs(dy);
  const pz = a.hz + b.hz - Math.abs(dz);
  if (px <= 0 || py <= 0 || pz <= 0) return;

  let axis: "x" | "y" | "z" = "x";
  let pen = px;
  if (py < pen) {
    axis = "y";
    pen = py;
  }
  if (pz < pen) {
    axis = "z";
    pen = pz;
  }

  const delta = axis === "x" ? dx : axis === "y" ? dy : dz;
  const dir = delta === 0 ? 1 : Math.sign(delta);
  const total = (a.dynamic ? a.invMass : 0) + (b.dynamic ? b.invMass : 0);
  const inv = total > 0 ? total : 1;
  const shareA = a.dynamic ? a.invMass / inv : 0;
  const shareB = b.dynamic ? b.invMass / inv : 0;
  const pushA = dir * pen * shareA;
  const pushB = dir * pen * shareB;

  if (axis === "x") {
    a.cx -= pushA;
    b.cx += pushB;
    if (a.dynamic) a.vx = 0;
    if (b.dynamic) b.vx = 0;
    return;
  }
  if (axis === "z") {
    a.cz -= pushA;
    b.cz += pushB;
    if (a.dynamic) a.vz = 0;
    if (b.dynamic) b.vz = 0;
    return;
  }

  a.cy -= pushA;
  b.cy += pushB;
  if (dir > 0) {
    if (b.dynamic && b.vy <= 0) land(b);
    if (a.dynamic && a.vy > 0) a.vy = 0;
  } else {
    if (a.dynamic && a.vy <= 0) land(a);
    if (b.dynamic && b.vy > 0) b.vy = 0;
  }
}

export function simulate(bodies: Body[], dt: number, gravity: number) {
  const step = Math.min(Math.max(dt, 0), 0.033);
  if (step <= 0) return;
  for (const b of bodies) {
    if (!b.dynamic) continue;
    b.vy -= gravity * step;
    b.cx += b.vx * step;
    b.cy += b.vy * step;
    b.cz += b.vz * step;
    b.grounded = false;
  }
  for (let iter = 0; iter < 4; iter++) {
    for (let i = 0; i < bodies.length; i++) {
      for (let j = i + 1; j < bodies.length; j++) {
        const a = bodies[i]!;
        const b = bodies[j]!;
        if (!a.dynamic && !b.dynamic) continue;
        separate(a, b);
      }
    }
  }
}
