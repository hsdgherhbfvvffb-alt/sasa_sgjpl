import { createFileRoute } from "@tanstack/react-router";
import { EditorApp } from "@/components/editor/Editor";

export const Route = createFileRoute("/")({ component: EditorApp });
