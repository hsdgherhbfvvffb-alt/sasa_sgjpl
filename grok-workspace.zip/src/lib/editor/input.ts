const physical = new Set<string>();
let injected: Set<string> | null = null;
let stickX = 0;
let stickY = 0;
let jumpQueued = false;
let steerOverride: number | null = null;

export function setStick(x: number, y: number) {
  stickX = Math.max(-1, Math.min(1, x));
  stickY = Math.max(-1, Math.min(1, y));
}

export function queueJump() {
  jumpQueued = true;
}

export function physicalDown(code: string) {
  physical.add(code);
}

export function physicalUp(code: string) {
  physical.delete(code);
}

export function clearPhysical() {
  physical.clear();
}

/** Held codes replace the keyboard until the next call. An empty list clears them. */
export function setInjectedKeys(codes: string[]) {
  injected = new Set(codes);
}

export function setSteerOverride(v: number | null) {
  steerOverride = v;
}

export function readInput(): { throttle: number; steer: number; jump: boolean } {
  const keys = injected ?? physical;
  let throttle = 0;
  let steer = 0;
  if (keys.has("KeyW") || keys.has("ArrowUp")) throttle += 1;
  if (keys.has("KeyS") || keys.has("ArrowDown")) throttle -= 1;
  if (keys.has("KeyA") || keys.has("ArrowLeft")) steer += 1;
  if (keys.has("KeyD") || keys.has("ArrowRight")) steer -= 1;
  if (injected == null) {
    steer += -stickX;
    throttle += -stickY;
  }
  if (steerOverride != null) steer = steerOverride;
  throttle = Math.max(-1, Math.min(1, throttle));
  steer = Math.max(-1, Math.min(1, steer));
  const jump = jumpQueued;
  jumpQueued = false;
  return { throttle, steer, jump };
}

export function isTypingTarget(target: EventTarget | null): boolean {
  if (!(target instanceof HTMLElement)) return false;
  const tag = target.tagName;
  return tag === "INPUT" || tag === "TEXTAREA" || tag === "SELECT" || target.isContentEditable;
}
