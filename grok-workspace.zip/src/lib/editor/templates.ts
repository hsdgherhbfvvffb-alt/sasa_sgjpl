import type { Behavior, Project, SceneObject, TemplateId } from "@/lib/editor/types";
import { makeSceneObject } from "@/lib/editor/types";

function beh(partial: Behavior): Behavior {
  return partial;
}

function lightsAndFloor(floorScale = 28): SceneObject[] {
  return [
    makeSceneObject({
      id: "light-key",
      type: "light",
      name: "Key light",
      lightKind: "directional",
      intensity: 3.4,
      color: "#fff4e4",
      position: { x: 8, y: 12, z: 6 },
      physics: false,
    }),
    makeSceneObject({
      id: "light-fill",
      type: "light",
      name: "Fill light",
      lightKind: "ambient",
      intensity: 0.85,
      color: "#c5d0e4",
      position: { x: 0, y: 2, z: 0 },
      physics: false,
    }),
    makeSceneObject({
      id: "floor",
      type: "floor",
      name: "Floor",
      color: "#2c3344",
      roughness: 0.92,
      metalness: 0.02,
      position: { x: 0, y: -0.1, z: 0 },
      scale: { x: floorScale, y: 0.2, z: floorScale },
      body: "static",
      friction: 0.85,
      castShadow: false,
    }),
  ];
}

function camera(id = "cam-main"): SceneObject {
  return makeSceneObject({
    id,
    type: "camera",
    name: "Camera",
    fov: 48,
    position: { x: 0, y: 3.4, z: 10 },
    rotation: { x: -16, y: 0, z: 0 },
    physics: false,
  });
}

function playerBeh(): Behavior {
  return beh({ id: "beh-player", kind: "player", moveSpeed: 5.2, turnSpeed: 150, jumpForce: 7.4 });
}

export function createProject(name: string, template: TemplateId, id: string): Project {
  const objects = template === "stage" ? stageObjects() : template === "physics" ? physicsObjects() : emptyObjects();
  return {
    id,
    name,
    updatedAt: 0,
    assets: [],
    activeSceneId: "scene-main",
    scenes: [
      {
        id: "scene-main",
        name: "Main",
        background: "#1a2030",
        fog: false,
        fogNear: 14,
        fogFar: 42,
        gravity: 22,
        objects,
      },
    ],
  };
}

function stageObjects(): SceneObject[] {
  return [
    ...lightsAndFloor(30),
    makeSceneObject({
      id: "hero",
      type: "character",
      name: "Hero",
      color: "#e09a4b",
      metalness: 0.18,
      roughness: 0.42,
      position: { x: 0, y: 0.8, z: 5 },
      body: "kinematic",
      behaviors: [playerBeh()],
    }),
    camera(),
    makeSceneObject({
      id: "crate-a",
      type: "box",
      name: "Crate",
      color: "#8d5a3c",
      roughness: 0.86,
      position: { x: -2.4, y: 0.5, z: 0.6 },
      scale: { x: 1.3, y: 1, z: 1.2 },
      body: "static",
    }),
    makeSceneObject({
      id: "crate-b",
      type: "box",
      name: "Crate tall",
      color: "#6e4632",
      roughness: 0.88,
      position: { x: 2.6, y: 0.7, z: -1.2 },
      scale: { x: 1.1, y: 1.4, z: 1.1 },
      body: "static",
    }),
    makeSceneObject({
      id: "pillar",
      type: "cylinder",
      name: "Pillar",
      color: "#4e6574",
      metalness: 0.2,
      roughness: 0.55,
      position: { x: 5.2, y: 1, z: 1.4 },
      scale: { x: 0.9, y: 2, z: 0.9 },
      body: "static",
    }),
    makeSceneObject({
      id: "coin-a",
      type: "torus",
      name: "Coin",
      color: "#f0c14e",
      emissive: "#f0c14e",
      emissiveIntensity: 0.35,
      metalness: 0.65,
      roughness: 0.28,
      position: { x: 0, y: 1.15, z: 0.2 },
      physics: false,
      behaviors: [
        beh({ id: "spin-a", kind: "spin", axis: "y", speed: 140 }),
        beh({ id: "bob-a", kind: "bob", amplitude: 0.18, speed: 2.2 }),
        beh({ id: "col-a", kind: "collectible", points: 10 }),
      ],
    }),
    makeSceneObject({
      id: "coin-b",
      type: "torus",
      name: "Coin far",
      color: "#f0c14e",
      emissive: "#f0c14e",
      emissiveIntensity: 0.35,
      metalness: 0.65,
      roughness: 0.28,
      position: { x: -3.6, y: 1.3, z: -2.4 },
      physics: false,
      behaviors: [
        beh({ id: "spin-b", kind: "spin", axis: "y", speed: 120 }),
        beh({ id: "bob-b", kind: "bob", amplitude: 0.16, speed: 2.6 }),
        beh({ id: "col-b", kind: "collectible", points: 10 }),
      ],
    }),
    makeSceneObject({
      id: "coin-c",
      type: "torus",
      name: "Coin right",
      color: "#f0c14e",
      emissive: "#e7a23a",
      emissiveIntensity: 0.3,
      metalness: 0.6,
      roughness: 0.3,
      position: { x: 3.4, y: 1.2, z: -3.4 },
      physics: false,
      behaviors: [
        beh({ id: "spin-c", kind: "spin", axis: "y", speed: 160 }),
        beh({ id: "bob-c", kind: "bob", amplitude: 0.2, speed: 1.8 }),
        beh({ id: "col-c", kind: "collectible", points: 25 }),
      ],
    }),
    makeSceneObject({
      id: "hazard",
      type: "cone",
      name: "Spinner",
      color: "#d25948",
      emissive: "#d25948",
      emissiveIntensity: 0.22,
      roughness: 0.4,
      position: { x: 1.3, y: 0.6, z: -2.1 },
      scale: { x: 0.85, y: 1.2, z: 0.85 },
      physics: false,
      behaviors: [
        beh({ id: "spin-h", kind: "spin", axis: "y", speed: 80 }),
        beh({ id: "haz-h", kind: "hazard", damage: 1 }),
      ],
    }),
    makeSceneObject({
      id: "loose",
      type: "box",
      name: "Loose crate",
      color: "#c4a27a",
      roughness: 0.8,
      position: { x: -1.2, y: 3.4, z: -3.2 },
      body: "dynamic",
      mass: 2,
      restitution: 0.18,
    }),
    makeSceneObject({
      id: "ball",
      type: "sphere",
      name: "Ball",
      color: "#e7e1d6",
      roughness: 0.35,
      metalness: 0.08,
      position: { x: 1.6, y: 4.2, z: -4.2 },
      body: "dynamic",
      mass: 1,
      restitution: 0.55,
    }),
  ];
}

function physicsObjects(): SceneObject[] {
  const boxes: SceneObject[] = [0, 1, 2, 3].map((i) =>
    makeSceneObject({
      id: `stack-${i}`,
      type: "box",
      name: `Stack ${i + 1}`,
      color: i % 2 === 0 ? "#d7d2c8" : "#8d5a3c",
      position: { x: (i - 1.5) * 0.15, y: 2.2 + i * 1.15, z: -1 },
      body: "dynamic",
      mass: 1,
      restitution: 0.12,
      roughness: 0.7,
    }),
  );
  const balls: SceneObject[] = [-2, 0, 2].map((x, i) =>
    makeSceneObject({
      id: `orb-${i}`,
      type: "sphere",
      name: `Orb ${i + 1}`,
      color: i === 1 ? "#e09a4b" : "#d7d2c8",
      position: { x, y: 4 + i * 0.4, z: 1.5 },
      body: "dynamic",
      restitution: 0.62,
      metalness: 0.25,
      roughness: 0.28,
    }),
  );
  return [
    ...lightsAndFloor(24),
    makeSceneObject({
      id: "hero",
      type: "character",
      name: "Hero",
      color: "#e09a4b",
      metalness: 0.18,
      roughness: 0.42,
      position: { x: 0, y: 0.8, z: 6 },
      body: "kinematic",
      behaviors: [playerBeh()],
    }),
    camera(),
    ...boxes,
    ...balls,
  ];
}

function emptyObjects(): SceneObject[] {
  return [...lightsAndFloor(20), camera()];
}
