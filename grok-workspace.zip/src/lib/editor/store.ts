import { create } from "zustand";
import { uid } from "@/lib/editor/id";
import { createProject } from "@/lib/editor/templates";
import type {
  AssetMeta,
  Behavior,
  BodyKind,
  Hud,
  LightKind,
  MobilePanel,
  ObjectType,
  PlayMode,
  Project,
  SceneData,
  SceneObject,
  TemplateId,
  Tool,
  Vec3,
  ViewMode,
} from "@/lib/editor/types";
import { activeScene, makeSceneObject } from "@/lib/editor/types";

export type SaveState = "saved" | "saving" | "error" | "idle";

type EditorState = {
  project: Project;
  selectedId: string | null;
  tool: Tool;
  snap: boolean;
  mode: PlayMode;
  view: ViewMode;
  viewBefore: ViewMode;
  mobilePanel: MobilePanel;
  dirty: boolean;
  saveState: SaveState;
  notice: string | null;
  hud: Hud;
  past: Project[];
  future: Project[];
  transformBackup: Project | null;
  revision: number;
  select: (id: string | null) => void;
  setTool: (tool: Tool) => void;
  toggleSnap: () => void;
  setMode: (mode: PlayMode) => void;
  setView: (view: ViewMode) => void;
  setMobilePanel: (panel: MobilePanel) => void;
  setNotice: (notice: string | null) => void;
  setHud: (hud: Partial<Hud>) => void;
  setSaveState: (saveState: SaveState) => void;
  commitSaved: (project: Project) => void;
  renameProject: (name: string) => void;
  newProject: (name: string, template: TemplateId) => void;
  replaceProject: (project: Project) => void;
  addScene: () => void;
  renameScene: (name: string) => void;
  deleteScene: () => void;
  setActiveScene: (id: string) => void;
  patchScene: (patch: Partial<Pick<SceneData, "background" | "fog" | "fogNear" | "fogFar" | "gravity" | "name">>) => void;
  addObject: (type: ObjectType, extra?: Partial<SceneObject>) => string | null;
  removeSelected: () => void;
  duplicateSelected: () => void;
  patchObject: (id: string, patch: Partial<SceneObject>, history?: boolean) => void;
  setTransform: (id: string, transform: { position?: Vec3; rotation?: Vec3; scale?: Vec3 }) => void;
  beginTransform: () => void;
  commitTransform: () => void;
  addBehavior: (objectId: string, behavior: Behavior) => void;
  updateBehavior: (objectId: string, behavior: Behavior) => void;
  removeBehavior: (objectId: string, behaviorId: string) => void;
  addAssetMeta: (asset: AssetMeta) => void;
  removeAsset: (id: string) => void;
  undo: () => void;
  redo: () => void;
};

const starter = createProject("Starter Stage", "stage", "project-starter");

const emptyHud = (): Hud => ({ score: 0, hp: 3, fps: 0, note: "", tris: 0 });

function cloneProject(project: Project): Project {
  return structuredClone(project);
}

function sceneOf(project: Project): SceneData {
  return activeScene(project);
}

function pickSelection(project: Project): string | null {
  const objects = sceneOf(project).objects;
  return (
    objects.find((obj) => obj.behaviors.some((b) => b.kind === "player"))?.id ??
    objects.find((obj) => obj.type === "floor")?.id ??
    objects[0]?.id ??
    null
  );
}

function finiteVec(v: Vec3 | undefined): Vec3 | undefined {
  if (!v) return undefined;
  if (![v.x, v.y, v.z].every((n) => Number.isFinite(n))) return undefined;
  return { x: v.x, y: v.y, z: v.z };
}

function nextName(objects: SceneObject[], base: string) {
  const names = new Set(objects.map((obj) => obj.name));
  if (!names.has(base)) return base;
  let i = 2;
  while (names.has(`${base} ${i}`)) i += 1;
  return `${base} ${i}`;
}

const LABELS: Record<ObjectType, string> = {
  box: "Box",
  sphere: "Sphere",
  cylinder: "Cylinder",
  cone: "Cone",
  torus: "Torus",
  plane: "Plane",
  capsule: "Capsule",
  floor: "Floor",
  character: "Character",
  camera: "Camera",
  light: "Light",
  model: "Model",
};

function editing(mode: PlayMode) {
  return mode === "edit";
}

export const useEditor = create<EditorState>((set, get) => {
  function commit(next: Project, extra: Partial<EditorState> = {}, history = true) {
    const cur = get();
    set({
      project: next,
      past: history ? [...cur.past, cloneProject(cur.project)].slice(-40) : cur.past,
      future: history ? [] : cur.future,
      dirty: true,
      transformBackup: history ? null : cur.transformBackup,
      revision: cur.revision + 1,
      ...extra,
    });
  }

  function mapObjects(project: Project, fn: (objects: SceneObject[]) => SceneObject[]): Project {
    const next = cloneProject(project);
    const scene = sceneOf(next);
    scene.objects = fn(scene.objects);
    return next;
  }

  return {
    project: starter,
    selectedId: "hero",
    tool: "move",
    snap: false,
    mode: "edit",
    view: "scene",
    viewBefore: "scene",
    mobilePanel: null,
    dirty: false,
    saveState: "idle",
    notice: null,
    hud: emptyHud(),
    past: [],
    future: [],
    transformBackup: null,
    revision: 1,

    select: (id) => set({ selectedId: id, revision: get().revision + 1 }),
    setTool: (tool) => set({ tool, revision: get().revision + 1 }),
    toggleSnap: () => set({ snap: !get().snap, revision: get().revision + 1 }),
    setMode: (mode) => {
      const cur = get();
      if (mode === cur.mode) return;
      if (mode === "play") {
        set({
          mode: "play",
          viewBefore: cur.mode === "edit" ? cur.view : cur.viewBefore,
          view: "game",
          mobilePanel: null,
          revision: cur.revision + 1,
        });
        return;
      }
      if (mode === "pause") {
        if (cur.mode !== "play") return;
        set({ mode: "pause", revision: cur.revision + 1 });
        return;
      }
      set({ mode: "edit", view: cur.viewBefore, revision: cur.revision + 1 });
    },
    setView: (view) => {
      if (get().mode !== "edit") return;
      set({ view, revision: get().revision + 1 });
    },
    setMobilePanel: (mobilePanel) => set({ mobilePanel }),
    setNotice: (notice) => set({ notice }),
    setHud: (hud) => set({ hud: { ...get().hud, ...hud } }),
    setSaveState: (saveState) => set({ saveState }),
    commitSaved: (project) => set({ project, dirty: false, saveState: "saved" }),
    renameProject: (name) => {
      const trimmed = name.trim();
      if (!trimmed || !editing(get().mode)) return;
      const next = cloneProject(get().project);
      next.name = trimmed.slice(0, 48);
      commit(next);
    },
    newProject: (name, template) => {
      const project = createProject(name.trim() || "Untitled", template, uid("project"));
      set({
        project,
        selectedId: pickSelection(project),
        mode: "edit",
        view: "scene",
        viewBefore: "scene",
        past: [],
        future: [],
        transformBackup: null,
        dirty: true,
        mobilePanel: null,
        revision: get().revision + 1,
        hud: emptyHud(),
      });
    },
    replaceProject: (project) => {
      set({
        project,
        selectedId: pickSelection(project),
        mode: "edit",
        view: "scene",
        viewBefore: "scene",
        past: [],
        future: [],
        transformBackup: null,
        dirty: false,
        saveState: "saved",
        mobilePanel: null,
        revision: get().revision + 1,
        hud: emptyHud(),
      });
    },
    addScene: () => {
      if (!editing(get().mode)) return;
      const next = cloneProject(get().project);
      const id = uid("scene");
      const n = next.scenes.length + 1;
      next.scenes.push({
        id,
        name: `Scene ${n}`,
        background: "#1a2030",
        fog: false,
        fogNear: 14,
        fogFar: 42,
        gravity: 22,
        objects: [
          makeSceneObject({
            id: uid("light"),
            type: "light",
            name: "Key light",
            lightKind: "directional",
            intensity: 3.4,
            color: "#fff4e4",
            position: { x: 6, y: 10, z: 4 },
            physics: false,
          }),
          makeSceneObject({
            id: uid("light"),
            type: "light",
            name: "Fill light",
            lightKind: "ambient",
            intensity: 0.85,
            color: "#c5d0e4",
            physics: false,
          }),
          makeSceneObject({
            id: uid("floor"),
            type: "floor",
            name: "Floor",
            color: "#2c3344",
            position: { x: 0, y: -0.1, z: 0 },
            scale: { x: 20, y: 0.2, z: 20 },
            castShadow: false,
          }),
          makeSceneObject({
            id: uid("cam"),
            type: "camera",
            name: "Camera",
            position: { x: 0, y: 3, z: 8 },
            rotation: { x: -14, y: 0, z: 0 },
            physics: false,
          }),
        ],
      });
      next.activeSceneId = id;
      commit(next, { selectedId: null });
    },
    renameScene: (name) => {
      if (!editing(get().mode)) return;
      const trimmed = name.trim();
      if (!trimmed) return;
      const next = cloneProject(get().project);
      sceneOf(next).name = trimmed.slice(0, 40);
      commit(next);
    },
    deleteScene: () => {
      if (!editing(get().mode)) return;
      if (get().project.scenes.length < 2) {
        set({ notice: "A project needs at least one scene." });
        return;
      }
      const next = cloneProject(get().project);
      const id = next.activeSceneId;
      next.scenes = next.scenes.filter((scene) => scene.id !== id);
      next.activeSceneId = next.scenes[0].id;
      commit(next, { selectedId: pickSelection(next) });
    },
    setActiveScene: (id) => {
      if (!editing(get().mode)) {
        set({ notice: "Stop play before switching scenes." });
        return;
      }
      if (!get().project.scenes.some((scene) => scene.id === id)) return;
      const next = cloneProject(get().project);
      next.activeSceneId = id;
      commit(next, { selectedId: pickSelection(next) });
    },
    patchScene: (patch) => {
      if (!editing(get().mode)) return;
      const next = cloneProject(get().project);
      Object.assign(sceneOf(next), patch);
      commit(next);
    },
    addObject: (type, extra) => {
      if (!editing(get().mode)) {
        set({ notice: "Stop play before adding objects." });
        return null;
      }
      const id = uid(type);
      const objects = sceneOf(get().project).objects;
      const jitter = (objects.length % 6) * 0.35;
      let position: Vec3 = { x: jitter, y: type === "character" ? 0.8 : 0.5, z: jitter };
      let rotation: Vec3 = { x: 0, y: 0, z: 0 };
      let scale: Vec3 = { x: 1, y: 1, z: 1 };
      let body: BodyKind = "static";
      let physics = type !== "light" && type !== "camera" && type !== "plane";
      const behaviors: Behavior[] = [];
      let lightKind: LightKind = extra?.lightKind ?? "point";
      let intensity = 2;
      let color = "#d7d2c8";
      if (type === "floor") {
        position = { x: 0, y: -0.1, z: 0 };
        scale = { x: 16, y: 0.2, z: 16 };
        color = "#2c3344";
      } else if (type === "plane") {
        rotation = { x: -90, y: 0, z: 0 };
        position = { x: jitter, y: 0.02, z: 0 };
        scale = { x: 4, y: 4, z: 4 };
      } else if (type === "character") {
        color = "#e09a4b";
        body = "kinematic";
        behaviors.push({ id: uid("beh"), kind: "player", moveSpeed: 5.2, turnSpeed: 150, jumpForce: 7.4 });
      } else if (type === "camera") {
        position = { x: 4, y: 3, z: 8 };
        rotation = { x: -14, y: 20, z: 0 };
        physics = false;
      } else if (type === "light") {
        physics = false;
        position = { x: 3, y: 4, z: 3 };
        if (lightKind === "ambient") intensity = 0.7;
        if (lightKind === "directional") {
          intensity = 3.2;
          position = { x: 6, y: 10, z: 4 };
        }
        if (lightKind === "point") intensity = 14;
        if (lightKind === "spot") intensity = 22;
        color = "#fff4e4";
      } else if (type === "model") {
        position = { x: jitter, y: 1, z: jitter };
        color = "#ffffff";
      }
      const object = makeSceneObject({
        id,
        type,
        name: nextName(objects, extra?.name ?? LABELS[type]),
        position,
        rotation,
        scale,
        body,
        physics,
        behaviors,
        lightKind,
        intensity,
        color,
        castShadow: type !== "floor" && type !== "light" && type !== "camera",
        ...extra,
        id,
        type,
        position: extra?.position ?? position,
        rotation: extra?.rotation ?? rotation,
        scale: extra?.scale ?? scale,
      });
      const next = mapObjects(get().project, (list) => [...list, object]);
      commit(next, { selectedId: id, mobilePanel: "inspector" });
      return id;
    },
    removeSelected: () => {
      const id = get().selectedId;
      if (!id || !editing(get().mode)) return;
      const next = mapObjects(get().project, (list) => list.filter((obj) => obj.id !== id));
      commit(next, { selectedId: null });
    },
    duplicateSelected: () => {
      const id = get().selectedId;
      if (!id || !editing(get().mode)) return;
      const source = sceneOf(get().project).objects.find((obj) => obj.id === id);
      if (!source) return;
      const copyId = uid(source.type);
      const copy: SceneObject = {
        ...structuredClone(source),
        id: copyId,
        name: nextName(sceneOf(get().project).objects, source.name),
        position: { ...source.position, x: source.position.x + 1 },
        behaviors: source.behaviors.map((b) => ({ ...b, id: uid("beh") })),
      };
      const next = mapObjects(get().project, (list) => [...list, copy]);
      commit(next, { selectedId: copyId });
    },
    patchObject: (id, patch, history = true) => {
      if (!editing(get().mode)) return;
      const apply = (project: Project) =>
        mapObjects(project, (list) =>
          list.map((obj) => {
            if (obj.id !== id) return obj;
            const position = finiteVec(patch.position) ?? obj.position;
            const rotation = finiteVec(patch.rotation) ?? obj.rotation;
            const scale = finiteVec(patch.scale) ?? obj.scale;
            return {
              ...obj,
              ...patch,
              position: patch.position ? position : obj.position,
              rotation: patch.rotation ? rotation : obj.rotation,
              scale: patch.scale ? scale : obj.scale,
            };
          }),
        );
      if (!history) {
        const cur = get();
        set({
          project: apply(cur.project),
          dirty: true,
          revision: cur.revision + 1,
        });
        return;
      }
      commit(apply(get().project));
    },
    setTransform: (id, transform) => {
      if (!editing(get().mode)) return;
      const position = finiteVec(transform.position);
      const rotation = finiteVec(transform.rotation);
      const scale = finiteVec(transform.scale);
      const cur = get();
      const next = mapObjects(cur.project, (list) =>
        list.map((obj) => {
          if (obj.id !== id) return obj;
          return {
            ...obj,
            position: position ?? obj.position,
            rotation: rotation ?? obj.rotation,
            scale: scale
              ? {
                  x: Math.max(0.05, scale.x),
                  y: Math.max(0.05, scale.y),
                  z: Math.max(0.05, scale.z),
                }
              : obj.scale,
          };
        }),
      );
      set({ project: next, dirty: true, revision: cur.revision + 1 });
    },
    beginTransform: () => {
      const cur = get();
      if (!editing(cur.mode) || cur.transformBackup) return;
      set({ transformBackup: cloneProject(cur.project) });
    },
    commitTransform: () => {
      const backup = get().transformBackup;
      if (!backup) return;
      const cur = get();
      if (JSON.stringify(backup) === JSON.stringify(cur.project)) {
        set({ transformBackup: null });
        return;
      }
      set({
        transformBackup: null,
        past: [...cur.past, backup].slice(-40),
        future: [],
        dirty: true,
      });
    },
    addBehavior: (objectId, behavior) => {
      if (!editing(get().mode)) return;
      const next = mapObjects(get().project, (list) =>
        list.map((obj) => (obj.id === objectId ? { ...obj, behaviors: [...obj.behaviors, behavior] } : obj)),
      );
      commit(next);
    },
    updateBehavior: (objectId, behavior) => {
      if (!editing(get().mode)) return;
      const next = mapObjects(get().project, (list) =>
        list.map((obj) =>
          obj.id === objectId
            ? { ...obj, behaviors: obj.behaviors.map((item) => (item.id === behavior.id ? behavior : item)) }
            : obj,
        ),
      );
      commit(next);
    },
    removeBehavior: (objectId, behaviorId) => {
      if (!editing(get().mode)) return;
      const next = mapObjects(get().project, (list) =>
        list.map((obj) =>
          obj.id === objectId ? { ...obj, behaviors: obj.behaviors.filter((item) => item.id !== behaviorId) } : obj,
        ),
      );
      commit(next);
    },
    addAssetMeta: (asset) => {
      const next = cloneProject(get().project);
      next.assets = [...next.assets.filter((item) => item.id !== asset.id), asset];
      commit(next);
    },
    removeAsset: (id) => {
      const next = cloneProject(get().project);
      next.assets = next.assets.filter((asset) => asset.id !== id);
      for (const scene of next.scenes) {
        for (const obj of scene.objects) {
          if (obj.assetId === id) obj.assetId = null;
          if (obj.textureId === id) obj.textureId = null;
        }
      }
      commit(next);
    },
    undo: () => {
      const cur = get();
      if (!editing(cur.mode) || cur.past.length === 0) return;
      const past = [...cur.past];
      const prev = past.pop();
      if (!prev) return;
      const selectedId = prev.scenes.some((scene) => scene.objects.some((obj) => obj.id === cur.selectedId))
        ? cur.selectedId
        : pickSelection(prev);
      set({
        past,
        future: [...cur.future, cloneProject(cur.project)].slice(-40),
        project: prev,
        selectedId,
        dirty: true,
        transformBackup: null,
        revision: cur.revision + 1,
      });
    },
    redo: () => {
      const cur = get();
      if (!editing(cur.mode) || cur.future.length === 0) return;
      const future = [...cur.future];
      const next = future.pop();
      if (!next) return;
      const selectedId = next.scenes.some((scene) => scene.objects.some((obj) => obj.id === cur.selectedId))
        ? cur.selectedId
        : pickSelection(next);
      set({
        future,
        past: [...cur.past, cloneProject(cur.project)].slice(-40),
        project: next,
        selectedId,
        dirty: true,
        transformBackup: null,
        revision: cur.revision + 1,
      });
    },
  };
});

export function selectedObject(): SceneObject | null {
  const { project, selectedId } = useEditor.getState();
  if (!selectedId) return null;
  return sceneOf(project).objects.find((obj) => obj.id === selectedId) ?? null;
}
