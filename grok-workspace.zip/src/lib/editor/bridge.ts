export type EngineBridge = {
  exportGlb: () => Promise<Uint8Array | null>;
  frameSelection: () => void;
};

let bridge: EngineBridge | null = null;

export function setBridge(next: EngineBridge | null) {
  bridge = next;
}

export function getBridge() {
  return bridge;
}
