import { getAsset, putAsset } from "@/lib/editor/db";
import { getBridge } from "@/lib/editor/bridge";
import { uid } from "@/lib/editor/id";
import { persist } from "@/lib/editor/persist";
import { useEditor } from "@/lib/editor/store";
import type { AssetFormat, AssetMeta, ObjectType, Project, SceneObject } from "@/lib/editor/types";
import { activeScene, makeSceneObject } from "@/lib/editor/types";
import { base64ToBuf, bufToBase64, downloadBlob, unzipStore, zipStore } from "@/lib/editor/zip";

type BundleAsset = {
  id: string;
  name: string;
  format: AssetFormat;
  base64?: string;
  file?: string;
};

type Bundle = {
  format: "rivet-project";
  version: 1;
  project: Project;
  assets: BundleAsset[];
};

function extOf(name: string): string {
  const dot = name.lastIndexOf(".");
  return dot >= 0 ? name.slice(dot + 1).toLowerCase() : "";
}

function asFormat(ext: string): AssetFormat | null {
  if (ext === "jpeg") return "jpg";
  if (ext === "glb" || ext === "gltf" || ext === "obj" || ext === "png" || ext === "jpg" || ext === "webp") return ext;
  return null;
}

function safe(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]+/g, "_").slice(0, 80) || "asset";
}

function normalizeProject(input: Project): Project {
  const scenes = (input.scenes ?? []).map((scene) => ({
    id: scene.id || uid("scene"),
    name: scene.name || "Scene",
    background: scene.background || "#1a2030",
    fog: Boolean(scene.fog),
    fogNear: Number.isFinite(scene.fogNear) ? scene.fogNear : 14,
    fogFar: Number.isFinite(scene.fogFar) ? scene.fogFar : 42,
    gravity: Number.isFinite(scene.gravity) ? scene.gravity : 22,
    objects: (scene.objects ?? []).map((raw) => normalizeObject(raw)),
  }));
  if (scenes.length === 0) throw new Error("This project has no scenes.");
  const active = scenes.some((scene) => scene.id === input.activeSceneId) ? input.activeSceneId : scenes[0].id;
  return {
    id: input.id || uid("project"),
    name: input.name || "Imported",
    updatedAt: input.updatedAt || Date.now(),
    assets: input.assets ?? [],
    activeSceneId: active,
    scenes,
  };
}

function normalizeObject(raw: SceneObject): SceneObject {
  const type = (raw.type ?? "box") as ObjectType;
  return makeSceneObject({
    ...raw,
    id: raw.id || uid(type),
    type,
    name: raw.name || type,
    behaviors: raw.behaviors ?? [],
  });
}

export async function importModelFiles(fileList: File[]) {
  const { project, addAssetMeta, addObject, setNotice } = useEditor.getState();
  let imported = 0;
  for (const file of fileList) {
    const format = asFormat(extOf(file.name));
    if (!format) {
      setNotice(`${file.name} is not a GLB, GLTF, OBJ, or image.`);
      continue;
    }
    const data = await file.arrayBuffer();
    const asset: AssetMeta = { id: uid("asset"), name: file.name, format, bytes: data.byteLength };
    await putAsset(project.id, asset.id, file.name, format, data);
    addAssetMeta(asset);
    imported += 1;
    if (format === "glb" || format === "gltf" || format === "obj") {
      addObject("model", {
        name: file.name.replace(/\.[^.]+$/, ""),
        assetId: asset.id,
        color: "#ffffff",
        materialOverride: false,
      });
    } else {
      const selected = useEditor.getState().selectedId;
      const mesh = activeScene(useEditor.getState().project).objects.find((obj) => obj.id === selected);
      if (!mesh || mesh.type === "light" || mesh.type === "camera") {
        setNotice("Texture stored. Select a mesh, then click it in Assets to apply.");
      } else {
        useEditor.getState().patchObject(mesh.id, { textureId: asset.id, materialOverride: true });
        setNotice(`Applied ${file.name}.`);
      }
    }
  }
  if (imported > 0 && !useEditor.getState().notice) setNotice(`Imported ${imported} file${imported === 1 ? "" : "s"}.`);
}

export async function exportProjectJson() {
  const bundle = await buildBundle();
  const blob = new Blob([JSON.stringify(bundle)], { type: "application/json" });
  downloadBlob(blob, `${safe(bundle.project.name)}.rivet.json`);
}

export async function exportProjectZip() {
  const bundle = await buildBundle();
  const files: { name: string; data: Uint8Array }[] = [];
  const enc = new TextEncoder();
  const linked: BundleAsset[] = [];
  for (const asset of bundle.assets) {
    if (!asset.base64) continue;
    const path = `assets/${safe(asset.name)}`;
    files.push({ name: path, data: new Uint8Array(base64ToBuf(asset.base64)) });
    linked.push({ id: asset.id, name: asset.name, format: asset.format, file: path });
  }
  const glb = await getBridge()?.exportGlb();
  if (glb) files.push({ name: "scene.glb", data: glb });
  const jsonBundle: Bundle = { ...bundle, assets: linked };
  files.unshift({ name: "project.json", data: enc.encode(JSON.stringify(jsonBundle)) });
  files.push({
    name: "README.txt",
    data: enc.encode(
      "Rivet project\n\nproject.json — scenes, materials, physics, and behaviors\nassets/ — imported models and textures\nscene.glb — mesh snapshot of the active scene\n\nImport the zip or project.json back into Rivet. scene.glb opens in any glTF tool; behaviors stay in project.json.\n",
    ),
  });
  downloadBlob(zipStore(files), `${safe(bundle.project.name)}.rivet.zip`);
}

export async function exportSceneGlb() {
  const glb = await getBridge()?.exportGlb();
  if (!glb) {
    useEditor.getState().setNotice("The viewport is not ready to export yet.");
    return;
  }
  const name = safe(activeScene(useEditor.getState().project).name);
  downloadBlob(new Blob([glb], { type: "model/gltf-binary" }), `${name}.glb`);
}

async function buildBundle(): Promise<Bundle> {
  const project = useEditor.getState().project;
  const assets: BundleAsset[] = [];
  for (const asset of project.assets) {
    const row = await getAsset(project.id, asset.id);
    assets.push({
      id: asset.id,
      name: asset.name,
      format: asset.format,
      base64: row ? bufToBase64(row.data) : undefined,
    });
  }
  return { format: "rivet-project", version: 1, project, assets };
}

export async function importProjectFile(file: File) {
  const lower = file.name.toLowerCase();
  if (lower.endsWith(".zip")) {
    const packed = unzipStore(await file.arrayBuffer());
    const projectFile = packed.find((entry) => entry.name === "project.json");
    if (!projectFile) throw new Error("Zip has no project.json");
    const bundle = parseBundle(new TextDecoder().decode(projectFile.data));
    await install(bundle, packed);
    return;
  }
  const bundle = parseBundle(await file.text());
  await install(bundle);
}

function parseBundle(text: string): Bundle {
  const data = JSON.parse(text) as Partial<Bundle> & Partial<Project>;
  if (data.format === "rivet-project" && data.project) {
    return { format: "rivet-project", version: 1, project: normalizeProject(data.project), assets: data.assets ?? [] };
  }
  if (Array.isArray((data as Project).scenes)) {
    return { format: "rivet-project", version: 1, project: normalizeProject(data as Project), assets: [] };
  }
  throw new Error("That file is not a Rivet project.");
}

async function install(bundle: Bundle, packed?: { name: string; data: Uint8Array }[]) {
  const project = normalizeProject(bundle.project);
  for (const asset of bundle.assets ?? []) {
    let buffer: ArrayBuffer | null = null;
    if (asset.base64) buffer = base64ToBuf(asset.base64);
    else if (asset.file && packed) {
      const hit = packed.find((entry) => entry.name === asset.file);
      if (hit) buffer = hit.data.buffer.slice(hit.data.byteOffset, hit.data.byteOffset + hit.data.byteLength);
    }
    if (!buffer) continue;
    await putAsset(project.id, asset.id, asset.name, asset.format, buffer);
  }
  useEditor.getState().replaceProject(project);
  await persist(useEditor.getState().project);
  useEditor.getState().setNotice(`Opened ${project.name}.`);
}
