import { loadProjectRecord, saveProjectRecord } from "@/lib/editor/db";
import { useEditor } from "@/lib/editor/store";
import type { Project } from "@/lib/editor/types";

const LAST_KEY = "rivet.last";

export async function persist(project?: Project) {
  const source = project ?? useEditor.getState().project;
  const stamped: Project = { ...source, updatedAt: Date.now() };
  useEditor.getState().setSaveState("saving");
  try {
    await saveProjectRecord(stamped);
    localStorage.setItem(LAST_KEY, stamped.id);
    if (useEditor.getState().project === source) useEditor.getState().commitSaved(stamped);
    else if (!useEditor.getState().dirty) useEditor.getState().commitSaved(stamped);
    else useEditor.getState().setSaveState("idle");
  } catch {
    useEditor.getState().setSaveState("error");
    useEditor.getState().setNotice("Could not save this project in the browser.");
  }
}

export async function bootProject() {
  try {
    const last = localStorage.getItem(LAST_KEY);
    if (!last) {
      await persist(useEditor.getState().project);
      return;
    }
    const saved = await loadProjectRecord(last);
    if (!saved) {
      await persist(useEditor.getState().project);
      return;
    }
    if (useEditor.getState().dirty) return;
    useEditor.getState().replaceProject(saved);
  } catch {
    useEditor.getState().setNotice("Saved projects could not be opened. Starting fresh.");
  }
}
