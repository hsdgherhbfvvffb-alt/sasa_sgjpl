import type { Behavior, SceneObject } from "@/lib/editor/types";

/** Fixed step. Yaw 0 faces world −Z. +yaw turns the nose toward world −X (screen-left from a chase cam). */
const STEP = 1 / 60;

export type SimInput = { throttle: number; steer: number; jump: boolean };

export type SimEvent =
  | { type: "collect"; points: number }
  | { type: "hurt" }
  | { type: "jump" }
  | { type: "respawn" }
  | { type: "clear" };

type Body = {
  id: string;
  px: number;
  py: number;
  pz: number;
  vx: number;
  vy: number;
  vz: number;
  rx: number;
  ry: number;
  rz: number;
  hx: number;
  hy: number;
  hz: number;
  dynamic: boolean;
  solid: boolean;
  useGravity: boolean;
  restitution: number;
  friction: number;
  hidden: boolean;
  isPlayer: boolean;
  collectible: boolean;
  hazard: boolean;
  points: number;
  damage: number;
  moveSpeed: number;
  turnSpeed: number;
  jumpForce: number;
  grounded: boolean;
  jumpBuffer: number;
  spawnX: number;
  spawnY: number;
  spawnZ: number;
  originX: number;
  originY: number;
  originZ: number;
  phase: number;
  behaviors: Behavior[];
};

export type Runtime = {
  bodies: Body[];
  score: number;
  hp: number;
  time: number;
  acc: number;
  note: string;
  coinsLeft: number;
  invuln: number;
  events: SimEvent[];
  playerId: string | null;
};

function extents(obj: SceneObject) {
  const sx = Math.max(0.01, Math.abs(obj.scale.x));
  const sy = Math.max(0.01, Math.abs(obj.scale.y));
  const sz = Math.max(0.01, Math.abs(obj.scale.z));
  if (obj.type === "sphere") {
    const r = 0.5 * Math.max(sx, sy, sz);
    return { hx: r, hy: r, hz: r };
  }
  if (obj.type === "character" || obj.type === "capsule") {
    return { hx: 0.35 * sx, hy: 0.8 * sy, hz: 0.35 * sz };
  }
  if (obj.type === "torus") return { hx: 0.5 * sx, hy: 0.2 * sy, hz: 0.5 * sz };
  if (obj.type === "plane") return { hx: 0.5 * sx, hy: 0.05, hz: 0.5 * sz };
  if (obj.type === "model") return { hx: sx, hy: sy, hz: sz };
  return { hx: 0.5 * sx, hy: 0.5 * sy, hz: 0.5 * sz };
}

export function compileScript(source: string): Behavior[] {
  const out: Behavior[] = [];
  const lines = source.split("\n");
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith("#")) continue;
    const p = line.split(/\s+/);
    const cmd = p[0]?.toLowerCase();
    const num = (i: number, fallback: number) => {
      const n = Number(p[i]);
      return Number.isFinite(n) ? n : fallback;
    };
    const axis = p[1]?.toLowerCase();
    if (cmd === "spin" && (axis === "x" || axis === "y" || axis === "z")) {
      out.push({ id: "script-spin", kind: "spin", axis, speed: num(2, 90) });
    } else if (cmd === "bob") {
      out.push({ id: "script-bob", kind: "bob", amplitude: num(1, 0.3), speed: num(2, 2) });
    } else if (cmd === "patrol" && (axis === "x" || axis === "z")) {
      out.push({
        id: "script-patrol",
        kind: "patrol",
        axis,
        distance: num(2, 2),
        speed: num(3, 1),
      });
    } else if (cmd === "move" && (axis === "x" || axis === "y" || axis === "z")) {
      out.push({ id: "script-drift", kind: "drift", axis, speed: num(2, 1) });
    }
  }
  return out;
}

function expand(behaviors: Behavior[]): Behavior[] {
  const out: Behavior[] = [];
  for (const behavior of behaviors) {
    if (behavior.kind === "script") out.push(...compileScript(behavior.source));
    else out.push(behavior);
  }
  return out;
}

export function createRuntime(objects: SceneObject[]): Runtime {
  const bodies: Body[] = [];
  for (const obj of objects) {
    if (!obj.visible || obj.type === "light" || obj.type === "camera") continue;
    const box = extents(obj);
    const behaviors = expand(obj.behaviors);
    const player = behaviors.find((b) => b.kind === "player");
    const collect = behaviors.find((b) => b.kind === "collectible");
    const hazard = behaviors.find((b) => b.kind === "hazard");
    const isPlayer = Boolean(player);
    const trigger = Boolean(collect || hazard);
    bodies.push({
      id: obj.id,
      px: obj.position.x,
      py: obj.position.y,
      pz: obj.position.z,
      vx: 0,
      vy: 0,
      vz: 0,
      rx: obj.rotation.x,
      ry: obj.rotation.y,
      rz: obj.rotation.z,
      ...box,
      dynamic: obj.physics && obj.body === "dynamic" && !isPlayer && !trigger,
      solid: obj.physics && obj.body === "static" && !trigger,
      useGravity: obj.useGravity,
      restitution: obj.restitution,
      friction: obj.friction,
      hidden: false,
      isPlayer,
      collectible: Boolean(collect),
      hazard: Boolean(hazard),
      points: collect && collect.kind === "collectible" ? collect.points : 0,
      damage: hazard && hazard.kind === "hazard" ? hazard.damage : 1,
      moveSpeed: player && player.kind === "player" ? player.moveSpeed : 5,
      turnSpeed: player && player.kind === "player" ? player.turnSpeed : 140,
      jumpForce: player && player.kind === "player" ? player.jumpForce : 7.2,
      grounded: true,
      jumpBuffer: 0,
      spawnX: obj.position.x,
      spawnY: obj.position.y,
      spawnZ: obj.position.z,
      originX: obj.position.x,
      originY: obj.position.y,
      originZ: obj.position.z,
      phase: 0,
      behaviors,
    });
  }
  const coinsLeft = bodies.filter((b) => b.collectible).length;
  const playerId = bodies.find((b) => b.isPlayer)?.id ?? null;
  return {
    bodies,
    score: 0,
    hp: 3,
    time: 0,
    acc: 0,
    note: coinsLeft > 0 ? `${coinsLeft} coins left` : "Scene running",
    coinsLeft,
    invuln: 0,
    events: [],
    playerId,
  };
}

function resolve(mover: Body, solid: Body): boolean {
  const dx = mover.px - solid.px;
  const dy = mover.py - solid.py;
  const dz = mover.pz - solid.pz;
  const px = mover.hx + solid.hx - Math.abs(dx);
  const py = mover.hy + solid.hy - Math.abs(dy);
  const pz = mover.hz + solid.hz - Math.abs(dz);
  if (px <= 0 || py <= 0 || pz <= 0) return false;
  if (py <= px && py <= pz) {
    const sign = dy >= 0 ? 1 : -1;
    mover.py += sign * py;
    if (sign > 0) {
      mover.grounded = true;
      if (mover.vy < 0) {
        mover.vy = Math.abs(mover.vy) < 1.25 ? 0 : -mover.vy * mover.restitution;
      }
    } else if (mover.vy > 0) mover.vy = 0;
    return true;
  }
  if (px < pz) {
    mover.px += (dx >= 0 ? 1 : -1) * px;
    mover.vx = 0;
  } else {
    mover.pz += (dz >= 0 ? 1 : -1) * pz;
    mover.vz = 0;
  }
  return true;
}

function hits(a: Body, b: Body) {
  return (
    Math.abs(a.px - b.px) < a.hx + b.hx + 0.2 &&
    Math.abs(a.py - b.py) < a.hy + b.hy + 0.2 &&
    Math.abs(a.pz - b.pz) < a.hz + b.hz + 0.2
  );
}

function scriptMotion(body: Body) {
  if (body.dynamic || body.isPlayer) {
    for (const behavior of body.behaviors) {
      if (behavior.kind === "spin" && !(body.isPlayer && behavior.axis === "y")) {
        if (behavior.axis === "x") body.rx += behavior.speed * STEP;
        if (behavior.axis === "y") body.ry += behavior.speed * STEP;
        if (behavior.axis === "z") body.rz += behavior.speed * STEP;
      }
    }
    return;
  }
  for (const behavior of body.behaviors) {
    if (behavior.kind === "spin") {
      if (behavior.axis === "x") body.rx += behavior.speed * STEP;
      if (behavior.axis === "y") body.ry += behavior.speed * STEP;
      if (behavior.axis === "z") body.rz += behavior.speed * STEP;
    } else if (behavior.kind === "bob") {
      body.phase += behavior.speed * STEP;
      body.py = body.originY + Math.sin(body.phase) * behavior.amplitude;
    } else if (behavior.kind === "patrol") {
      body.phase += behavior.speed * STEP;
      const offset = Math.sin(body.phase) * behavior.distance;
      if (behavior.axis === "x") body.px = body.originX + offset;
      else body.pz = body.originZ + offset;
    } else if (behavior.kind === "drift") {
      if (behavior.axis === "x") body.px += behavior.speed * STEP;
      if (behavior.axis === "y") body.py += behavior.speed * STEP;
      if (behavior.axis === "z") body.pz += behavior.speed * STEP;
    }
  }
}

function integrateDynamic(body: Body, gravity: number, solids: Body[], dynamics: Body[]) {
  body.grounded = false;
  if (body.useGravity) body.vy -= gravity * STEP;
  body.px += body.vx * STEP;
  body.py += body.vy * STEP;
  body.pz += body.vz * STEP;
  for (let iter = 0; iter < 2; iter++) {
    for (const solid of solids) resolve(body, solid);
  }
  for (const other of dynamics) {
    if (other !== body) resolve(body, other);
  }
  const damp = Math.exp(-(body.grounded ? 1.4 + body.friction : 0.15) * STEP);
  body.vx *= damp;
  body.vz *= damp;
  if (body.grounded && Math.hypot(body.vx, body.vz) < 0.05 && Math.abs(body.vy) < 0.2) {
    body.vx = 0;
    body.vz = 0;
    body.vy = 0;
  }
  if (body.py < -20) {
    body.px = body.spawnX;
    body.py = body.spawnY;
    body.pz = body.spawnZ;
    body.vx = body.vy = body.vz = 0;
  }
}

function respawn(player: Body, rt: Runtime) {
  player.px = player.spawnX;
  player.py = player.spawnY;
  player.pz = player.spawnZ;
  player.vx = player.vy = player.vz = 0;
  player.grounded = true;
  rt.hp = 3;
  rt.invuln = 0.6;
  rt.note = "Respawned";
  rt.events.push({ type: "respawn" });
}

function integratePlayer(player: Body, input: SimInput, rt: Runtime, gravity: number, blockers: Body[]) {
  // A / steer +1 increases yaw. Chase cam sits behind forward, so the nose goes screen-left.
  player.ry += input.steer * player.turnSpeed * STEP;
  const yaw = (player.ry * Math.PI) / 180;
  const fx = -Math.sin(yaw);
  const fz = -Math.cos(yaw);
  player.vx = fx * player.moveSpeed * input.throttle;
  player.vz = fz * player.moveSpeed * input.throttle;
  if (input.jump) player.jumpBuffer = 0.12;
  else player.jumpBuffer = Math.max(0, player.jumpBuffer - STEP);
  const wasGrounded = player.grounded;
  player.grounded = false;
  if (player.jumpBuffer > 0 && wasGrounded) {
    player.vy = player.jumpForce;
    player.jumpBuffer = 0;
    player.grounded = false;
    rt.events.push({ type: "jump" });
  }
  player.vy -= gravity * STEP;
  player.px += player.vx * STEP;
  player.py += player.vy * STEP;
  player.pz += player.vz * STEP;
  for (let iter = 0; iter < 2; iter++) {
    for (const solid of blockers) {
      if (solid !== player && !solid.hidden) resolve(player, solid);
    }
  }
  if (player.py < -12) respawn(player, rt);
}

function triggers(rt: Runtime, player: Body) {
  rt.invuln = Math.max(0, rt.invuln - STEP);
  for (const body of rt.bodies) {
    if (body === player || body.hidden) continue;
    if (body.collectible && hits(player, body)) {
      body.hidden = true;
      rt.score += body.points;
      rt.coinsLeft = Math.max(0, rt.coinsLeft - 1);
      rt.events.push({ type: "collect", points: body.points });
      if (rt.coinsLeft === 0) {
        rt.note = "Stage clear";
        rt.events.push({ type: "clear" });
      } else {
        rt.note = `${rt.coinsLeft} coin${rt.coinsLeft === 1 ? "" : "s"} left`;
      }
    } else if (body.hazard && rt.invuln <= 0 && hits(player, body)) {
      rt.hp -= body.damage;
      rt.invuln = 1;
      const dx = player.px - body.px;
      const dz = player.pz - body.pz;
      const len = Math.hypot(dx, dz) || 1;
      player.px += (dx / len) * 1.15;
      player.pz += (dz / len) * 1.15;
      player.vy = 4.5;
      player.grounded = false;
      rt.events.push({ type: "hurt" });
      if (rt.hp <= 0) respawn(player, rt);
      else rt.note = "Watch the hazards";
    }
  }
}

function substep(rt: Runtime, input: SimInput, gravity: number) {
  rt.time += STEP;
  const solids = rt.bodies.filter((b) => b.solid && !b.hidden);
  const dynamics = rt.bodies.filter((b) => b.dynamic && !b.hidden);
  const player = rt.bodies.find((b) => b.id === rt.playerId && b.isPlayer && !b.hidden);
  for (const body of rt.bodies) {
    if (!body.hidden) scriptMotion(body);
  }
  for (const body of dynamics) integrateDynamic(body, gravity, solids, dynamics);
  if (player) {
    const blockers = rt.bodies.filter(
      (b) => b !== player && !b.hidden && !b.collectible && !b.hazard && (b.solid || b.dynamic),
    );
    integratePlayer(player, input, rt, gravity, blockers);
    triggers(rt, player);
  }
}

export function stepSim(rt: Runtime, input: SimInput, dt: number, gravity: number) {
  rt.acc += Math.min(Math.max(dt, 0), 0.1);
  let guard = 0;
  while (rt.acc >= STEP && guard < 8) {
    substep(rt, input, gravity);
    rt.acc -= STEP;
    guard += 1;
  }
}

export function playerProbe(rt: Runtime | null): { yaw: number; speed: number } {
  if (!rt?.playerId) return { yaw: 0, speed: 0 };
  const player = rt.bodies.find((b) => b.id === rt.playerId);
  if (!player) return { yaw: 0, speed: 0 };
  return { yaw: (player.ry * Math.PI) / 180, speed: Math.hypot(player.vx, player.vz) };
}
