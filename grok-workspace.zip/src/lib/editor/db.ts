import type { AssetFormat, Project } from "@/lib/editor/types";

export type AssetRecord = {
  key: string;
  id: string;
  projectId: string;
  name: string;
  format: AssetFormat;
  data: ArrayBuffer;
};

export type ProjectRecord = {
  id: string;
  name: string;
  updatedAt: number;
  json: string;
};

const DB_NAME = "rivet";
const DB_VERSION = 1;

function openDb(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(DB_NAME, DB_VERSION);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains("projects")) db.createObjectStore("projects", { keyPath: "id" });
      if (!db.objectStoreNames.contains("assets")) db.createObjectStore("assets", { keyPath: "key" });
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error ?? new Error("Could not open project storage"));
  });
}

function txDone(tx: IDBTransaction): Promise<void> {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error ?? new Error("Storage transaction failed"));
    tx.onabort = () => reject(tx.error ?? new Error("Storage transaction aborted"));
  });
}

export async function saveProjectRecord(project: Project): Promise<void> {
  const db = await openDb();
  const tx = db.transaction("projects", "readwrite");
  tx.objectStore("projects").put({
    id: project.id,
    name: project.name,
    updatedAt: project.updatedAt,
    json: JSON.stringify(project),
  } satisfies ProjectRecord);
  await txDone(tx);
}

export async function loadProjectRecord(id: string): Promise<Project | null> {
  const db = await openDb();
  const tx = db.transaction("projects", "readonly");
  const req = tx.objectStore("projects").get(id);
  const row = await new Promise<ProjectRecord | undefined>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as ProjectRecord | undefined);
    req.onerror = () => reject(req.error);
  });
  await txDone(tx);
  if (!row) return null;
  return JSON.parse(row.json) as Project;
}

export async function listProjectRecords(): Promise<ProjectRecord[]> {
  const db = await openDb();
  const tx = db.transaction("projects", "readonly");
  const req = tx.objectStore("projects").getAll();
  const rows = await new Promise<ProjectRecord[]>((resolve, reject) => {
    req.onsuccess = () => resolve((req.result as ProjectRecord[]) ?? []);
    req.onerror = () => reject(req.error);
  });
  await txDone(tx);
  return rows.sort((a, b) => b.updatedAt - a.updatedAt);
}

export async function deleteProjectRecord(id: string): Promise<void> {
  const db = await openDb();
  const tx = db.transaction(["projects", "assets"], "readwrite");
  tx.objectStore("projects").delete(id);
  const assets = tx.objectStore("assets");
  const req = assets.getAll();
  const rows = await new Promise<AssetRecord[]>((resolve, reject) => {
    req.onsuccess = () => resolve((req.result as AssetRecord[]) ?? []);
    req.onerror = () => reject(req.error);
  });
  for (const row of rows) {
    if (row.projectId === id) assets.delete(row.key);
  }
  await txDone(tx);
}

export async function putAsset(
  projectId: string,
  id: string,
  name: string,
  format: AssetFormat,
  data: ArrayBuffer,
): Promise<void> {
  const db = await openDb();
  const tx = db.transaction("assets", "readwrite");
  const record: AssetRecord = { key: `${projectId}:${id}`, id, projectId, name, format, data };
  tx.objectStore("assets").put(record);
  await txDone(tx);
}

export async function getAsset(projectId: string, id: string): Promise<AssetRecord | null> {
  const db = await openDb();
  const tx = db.transaction("assets", "readonly");
  const req = tx.objectStore("assets").get(`${projectId}:${id}`);
  const row = await new Promise<AssetRecord | undefined>((resolve, reject) => {
    req.onsuccess = () => resolve(req.result as AssetRecord | undefined);
    req.onerror = () => reject(req.error);
  });
  await txDone(tx);
  return row ?? null;
}
