export type Vec3 = { x: number; y: number; z: number };

export type ObjectType =
  | "box"
  | "sphere"
  | "cylinder"
  | "cone"
  | "torus"
  | "plane"
  | "capsule"
  | "floor"
  | "character"
  | "camera"
  | "light"
  | "model";

export type BodyKind = "static" | "dynamic" | "kinematic";
export type LightKind = "ambient" | "directional" | "point" | "spot";
export type AssetFormat = "glb" | "gltf" | "obj" | "png" | "jpg" | "webp";

export type Behavior =
  | { id: string; kind: "spin"; axis: "x" | "y" | "z"; speed: number }
  | { id: string; kind: "bob"; amplitude: number; speed: number }
  | { id: string; kind: "patrol"; axis: "x" | "z"; distance: number; speed: number }
  | { id: string; kind: "drift"; axis: "x" | "y" | "z"; speed: number }
  | { id: string; kind: "player"; moveSpeed: number; turnSpeed: number; jumpForce: number }
  | { id: string; kind: "collectible"; points: number }
  | { id: string; kind: "hazard"; damage: number }
  | { id: string; kind: "script"; source: string };

export type SceneObject = {
  id: string;
  name: string;
  type: ObjectType;
  position: Vec3;
  rotation: Vec3;
  scale: Vec3;
  visible: boolean;
  color: string;
  metalness: number;
  roughness: number;
  opacity: number;
  emissive: string;
  emissiveIntensity: number;
  physics: boolean;
  body: BodyKind;
  mass: number;
  restitution: number;
  friction: number;
  useGravity: boolean;
  behaviors: Behavior[];
  castShadow: boolean;
  receiveShadow: boolean;
  materialOverride: boolean;
  textureId: string | null;
  intensity: number;
  fov: number;
  lightKind: LightKind;
  assetId: string | null;
};

export type SceneData = {
  id: string;
  name: string;
  background: string;
  fog: boolean;
  fogNear: number;
  fogFar: number;
  gravity: number;
  objects: SceneObject[];
};

export type AssetMeta = {
  id: string;
  name: string;
  format: AssetFormat;
  bytes: number;
};

export type Project = {
  id: string;
  name: string;
  scenes: SceneData[];
  activeSceneId: string;
  assets: AssetMeta[];
  updatedAt: number;
};

export type Tool = "select" | "move" | "rotate" | "scale";
export type PlayMode = "edit" | "play" | "pause";
export type ViewMode = "scene" | "game";
export type MobilePanel = "hierarchy" | "assets" | "inspector" | null;
export type TemplateId = "stage" | "physics" | "empty";

export type Hud = {
  score: number;
  hp: number;
  fps: number;
  note: string;
  tris: number;
};

export const zeroVec = (): Vec3 => ({ x: 0, y: 0, z: 0 });
export const oneVec = (): Vec3 => ({ x: 1, y: 1, z: 1 });

export function objectDefaults(type: ObjectType): SceneObject {
  return {
    id: "unset",
    name: type,
    type,
    position: { x: 0, y: 0.5, z: 0 },
    rotation: zeroVec(),
    scale: oneVec(),
    visible: true,
    color: "#d7d2c8",
    metalness: 0.04,
    roughness: 0.72,
    opacity: 1,
    emissive: "#000000",
    emissiveIntensity: 0,
    physics: type !== "light" && type !== "camera" && type !== "plane",
    body: "static",
    mass: 1,
    restitution: 0.2,
    friction: 0.45,
    useGravity: true,
    behaviors: [],
    castShadow: type !== "floor" && type !== "light" && type !== "camera",
    receiveShadow: true,
    materialOverride: type !== "model",
    textureId: null,
    intensity: type === "light" ? 2 : 1,
    fov: 50,
    lightKind: "directional",
    assetId: null,
  };
}

export function makeSceneObject(
  partial: Partial<SceneObject> & Pick<SceneObject, "id" | "type" | "name">,
): SceneObject {
  const base = objectDefaults(partial.type);
  return {
    ...base,
    ...partial,
    position: { ...base.position, ...partial.position },
    rotation: { ...base.rotation, ...partial.rotation },
    scale: { ...base.scale, ...partial.scale },
    behaviors: partial.behaviors ?? [],
  };
}

export function activeScene(project: Project): SceneData {
  return project.scenes.find((scene) => scene.id === project.activeSceneId) ?? project.scenes[0];
}

export function hexColor(value: string, fallback = "#d7d2c8"): string {
  const v = value.trim();
  return /^#[0-9a-fA-F]{6}$/.test(v) ? v.toLowerCase() : fallback;
}
